#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include "resource.h"
#include <sys/stat.h>

enum FileType {MP3, ADF, OTHER};

FILE *inputFile, *outputFile;
FileType openFileType = OTHER;

bool CALLBACK MainDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	//char filename[MAX_PATH];
	OPENFILENAME ofn={0};
	TCHAR filename[MAX_PATH];
	char buffer[512];
	char tempChar;
			long fileSize;
			long counter = 0;
			HWND progressHwnd;
	sprintf(buffer, "%X %X %X", uMsg, wParam, lParam);
	//MessageBox(NULL, buffer, "Test", MB_OK);
	if(uMsg == WM_COMMAND)
	{
		switch(wParam)
		{
		case IDC_OPENBUTTON:
			//MessageBox(NULL, "OPENBUTTON PRESSED", "Test", MB_OK);
			
			//static 
			GetDlgItemText(hwndDlg, IDC_OPENEDIT, filename, MAX_PATH);

			ZeroMemory((void*)&ofn, sizeof(OPENFILENAME));
			ofn.lStructSize       = sizeof(OPENFILENAME);
			ofn.lpstrFilter       = _T("MP3/ADF Files\0*.mp3;*.adf\0All Files\0*\0\0");
			ofn.lpstrFile         = filename;
			ofn.nMaxFile         = MAX_PATH;
			ofn.lpstrTitle        = TEXT("Open File...\0");
			ofn.Flags             = OFN_FILEMUSTEXIST | OFN_READONLY | OFN_PATHMUSTEXIST;
			   
			if(GetOpenFileName((LPOPENFILENAME)&ofn))
			{
				SetDlgItemText(hwndDlg, IDC_OPENEDIT, filename);
				for(int i = 0; i < MAX_PATH; i++)
					if(filename[i] == '\0')
						break;

				if(ofn.nFileExtension < MAX_PATH-3)
				{
					TCHAR ext[4];
					ext[0] = filename[ofn.nFileExtension];
					ext[1] = filename[ofn.nFileExtension+1];
					ext[2] = filename[ofn.nFileExtension+2];
					ext[3] = '\0';
					
					if(_tcsicmp(ext, _T("mp3")) == 0)
					{
						openFileType = MP3;
					}
					else if(_tcsicmp(ext, _T("adf")) == 0)
						openFileType = ADF;
					else
						openFileType = OTHER;
				}
				else
					openFileType = OTHER;
				//MessageBox(NULL, "ping!", "ping!", MB_OK);
			}

   
			break;
		case IDC_SAVEBUTTON:
			GetDlgItemText(hwndDlg, IDC_SAVEEDIT, filename, MAX_PATH);
			if(filename[0] == '\0' && openFileType != OTHER)
			{
				GetDlgItemText(hwndDlg, IDC_OPENEDIT, filename, MAX_PATH);
				for(int i = 0; i < MAX_PATH; i++)
					if(filename[i] == '\0')
						break;
				if(i >=4 && filename[i-4] == '.')
				{
					switch(openFileType)
					{
					case MP3:
						filename[i-3] = _T('a');
						filename[i-2] = 'd';
						filename[i-1] = 'f';
						break;
					case ADF:
						filename[i-3] = _T('m');
						filename[i-2] = 'p';
						filename[i-1] = '3';
						break;
					default:
						break;
					}

				}
			}
			ZeroMemory((void*)&ofn, sizeof(OPENFILENAME));
			ofn.lStructSize       = sizeof(OPENFILENAME);
			//ofn.lpstrFilter       = _T("MP3/ADF Files\0*.mp3;.adf\0All Files\0*.*\0\0");
			ofn.lpstrFile         = filename;
			ofn.nMaxFile         = MAX_PATH;
			ofn.lpstrTitle        = TEXT("Save File...\0");
			//ofn.nFilterIndex=0;
			//ofn.Flags             = OFN_FILEMUSTEXIST | OFN_READONLY | OFN_PATHMUSTEXIST;
			ofn.Flags = OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
  

			switch(openFileType)
			{
			case MP3:
				//MessageBox(NULL, "ping!", "ping!", MB_OK);
				ofn.lpstrDefExt = _T(".adf");
				ofn.lpstrFilter = _T("ADF Files\0*.adf\0\0");
				break;
			case ADF:
				ofn.lpstrDefExt = _T(".mp3");
				ofn.lpstrFilter = _T("MP3 Files\0*.mp3\0\0");
				break;
			case OTHER:
				ofn.lpstrFilter = _T("All Files\0*.*\0\0");
				break;
			default:
				ofn.lpstrFilter = _T("All Files\0*.*\0\0");
				break;
			}
			if(GetSaveFileName((LPOPENFILENAME)&ofn))
			{
				SetDlgItemText(hwndDlg, IDC_SAVEEDIT, filename);
				//MessageBox(NULL, "ping!", "ping!", MB_OK);
			}

   
			break;
		case IDCANCEL:
			EndDialog(hwndDlg, 0);
			break;
		case IDC_CONVERTBUTTON:

			
			TCHAR inputFilename[MAX_PATH], outputFilename[MAX_PATH];
			GetDlgItemText(hwndDlg, IDC_OPENEDIT, inputFilename, MAX_PATH);
			GetDlgItemText(hwndDlg, IDC_SAVEEDIT, outputFilename, MAX_PATH);

			inputFile = fopen(inputFilename, "rb");
			outputFile = fopen(outputFilename, "wb");

			if(inputFile == NULL || outputFile == NULL)
			{
				MessageBox(hwndDlg, "Error opening files", "Error", MB_OK);	
				return false;
			}
			
			while(feof(inputFile) == 0)
			{
				counter++;
				tempChar = fgetc(inputFile);
				fputc(tempChar^0x22, outputFile);
			}			

			fclose(inputFile);
			fclose(outputFile);
			
			MessageBox(hwndDlg, "File successfully converted", "Finished", MB_OK);

			break;
		default:
			break;
		}
	}
	else if(uMsg == WM_CLOSE)
		EndDialog(hwndDlg, 0);
	return false;
}

int WINAPI WinMain (HINSTANCE hInst, HINSTANCE hPrevInst,
            char * cmdParam, int cmdShow)
{
	DialogBox(hInst, MAKEINTRESOURCE(IDD_MAINDIALOG), NULL, (DLGPROC)MainDialogProc);
	/*
	if(dialogHwnd == NULL)
	{
		DWORD error = GetLastError();
		char buffer[255];
		sprintf(buffer, "%X", error);
		MessageBox(NULL, buffer, "test2", MB_OK);
	}
	else
		ShowWindow(dialogHwnd, SW_SHOW);
	//Sleep(5000);
	*/
	/*
OPENFILENAME ofn={0};
   //static 
   filename[0]= '\0';

   
   ZeroMemory((void*)&ofn, sizeof(OPENFILENAME));
   ofn.lStructSize       = sizeof(OPENFILENAME);
   ofn.lpstrFilter       = _T("MP3/ADF Files\0*.mp3;.adf\0All Files\0*.*\0\0");
   ofn.lpstrFile         = filename;
   ofn.nMaxFile         = MAX_PATH;
   ofn.lpstrTitle        = TEXT("Open Media File...\0");
   ofn.Flags             = OFN_FILEMUSTEXIST | OFN_READONLY | OFN_PATHMUSTEXIST;
   
   HRESULT hresult;
   if(GetOpenFileName((LPOPENFILENAME)&ofn))
   {
      MessageBox(NULL, "ping!", "ping!", MB_OK);
   }
   else
   {
		DWORD error = CommDlgExtendedError();
		char string[255];
		sprintf(string,"%i", error);
		MessageBox(NULL, "ping!", string, MB_OK);

   }
   */

   return 0;
}