#include <vector>
#include <set>
#include "ai.h"
#include "DiceGame.h"
#include "brain.h"


extern CDiceGame *g_pGame;
extern CBrain *g_pBrain;

AI::AI(void)
{
	for(int i = 0; i< MAX_PATH_LEN; i++)
		m_path[i] = NONE;

	m_playerNum = 0;

	m_IQ = 0;

	m_numDirRequests = 0;  
	m_numRandResponses = 0;
	m_state = NO_MATCHES;
	m_wantDump = false;
	m_diceValue = 0;
}

AI::~AI(void)
{
	float result = 100.0f*((float)m_numRandResponses/(float)m_numDirRequests);
	printf("AI %i gave a random direction %f percent of the time\n", m_playerNum, result);
	printf("Rand: %i Total: %i\n", m_numRandResponses, m_numDirRequests);
}

Direction AI::GetDirection()
{
	int i;
	int x = g_pGame->m_players[m_playerNum].boardX;
	int y = g_pGame->m_players[m_playerNum].boardY;
	Direction tempDir;
	int maxScore = -1;
	int pathIndex = -1;
	int tempScore;
	set <int>::iterator sIter;

	m_numDirRequests++;

	VerifyDiceSet();

	// If any other players are at the same spot I am, move randomly
	// TODO: Be smarter about this
	for(i = 0; i < g_pGame->m_numPlayers; i++)
	{
		if(i != m_playerNum && x == g_pGame->m_players[i].boardX && y == g_pGame->m_players[i].boardY)
		{		
			m_numRandResponses++;
			return (Direction)(rand()%5);
		}
	}

	if(m_playerNum == 0 && m_wantDump)
	{
		printf("player 0 has %i dice in its list of value %i\n", m_sDice.size(), m_diceValue);
		for(sIter = m_sDice.begin(); sIter != m_sDice.end(); sIter++)
		{
			printf("%i,%i - ", (*sIter >> 8)&0xff, *sIter & 0xFF);
		}
		printf("\n");
	}


	//vector<Path> *pTempVect = g_pBrain->m_gamepaths[x][y];

	if(m_playerNum == 0 && m_wantDump)
	{
		printf("AI %i is following: ", m_playerNum);
		for(i = 0; i < MAX_PATH_LEN; i++)
		{
			switch(m_path[i])
			{
			case UP:
				printf("U");
				break;
			case DOWN:
				printf("D");
				break;
			case RIGHT:
				printf("R");
				break;
			case LEFT:
				printf("L");
				break;
			case NONE:
				printf("N");
				break;
			}
		}
		printf("\n");
	}

	switch(m_state)
	{
	case NO_MATCHES:
		if(m_playerNum == 0 && m_wantDump)
			printf("player 0 is in NO_MATCHES state\n");
		// Find a suitable movable die, by searching from this spot
		// There may be several good die nearby, how do I decide 
		// which has a path that I want? For now, grab nearest movable.
		if(g_pBrain->m_gamepaths[x][y]->size() == 0)
		{
			FindClosestRollerPath(x,y);
			//m_state = BUILDING_MOVING;
		}
		//else
		//m_state = BUILDING_MATCHING; 
		m_state = BUILDING_MOVING;// Put player into "Building_moving" regardless
		break;
	case BUILDING_MOVING:
		if(m_playerNum == 0 && m_wantDump)
			printf("player 0 is in BUILDING_MOVING state\n");
		if(m_path[0] == NONE)
		{
			if(g_pGame->m_gameboard[x][y].state == SINKING)
			{
				FindPathFromSinker(x,y);
				m_state = MOVING_SINKER;
				m_diceValue = g_pGame->m_gameboard[x][y].dieState/4+1;
				CreateDiceList(x,y);
			}
			else if (g_pGame->m_gameboard[x][y].state == OCCUPIED && g_pBrain->m_gamepaths[x][y]->size() == 0)//(pTempVect->size() == 0)
			{
				//printf("AI %i didnt find a path\n", m_playerNum);
				FindClosestRollerPath(x,y);
				//m_numRandResponses++;
				//return (Direction)(rand()%5);
				break;
			}
			else if (g_pGame->m_gameboard[x][y].state == FREE)
			{
				// Somehow, I ended up on the floor. Switch states
				m_state = MOVING_RISER;
				break;
			}
			else if (g_pGame->m_gameboard[x][y].state == RISING)
			{
				// somehow, I'm on a riser
				m_state = NO_MATCHES;
				break;
			}

			//WaitForSingleObject(g_pBrain->m_mutexHandles[x][y], INFINITE);
			
			pathIndex = -1;
			maxScore = -1;
			// Pick path with highest score
			for(i = 0; i < (int)g_pBrain->m_gamepaths[x][y]->size(); i++)
			{
				if( m_diceValue == 0 || (*g_pBrain->m_gamepaths[x][y])[i].die_state/4+1 == m_diceValue)
				{
					tempScore = (*g_pBrain->m_gamepaths[x][y])[i].score * (MAX_PATH_LEN+1 - (*g_pBrain->m_gamepaths[x][y])[i].length);
					if( tempScore > maxScore)
					{
						maxScore = tempScore;
						pathIndex = i;
					}
				}
			}

			if(pathIndex == -1) // A path wasnt found. Do I scrap my set of dice and start over? 
				                // Or should I just try to find another roller?
			{
				FindClosestRollerPath(x,y);
				
				if(m_path[0] == NONE)
					m_sDice.clear(); // We still dont have a path, so ditch our list of dice
									 // We'll get a path next time around
				break;
			}
				//printf("pathIndex == -1\n");

			// Copy best path
			for(i = 0; i < MAX_PATH_LEN; i++)
			{
				//printf("size: %i\n", (*g_pBrain->m_gamepaths[x][y]).size());
				m_path[i] = (Direction)(((*g_pBrain->m_gamepaths[x][y])[pathIndex].path[i])&0xff);//(pTempVect->at(0)).path[i]; 
				//if(m_path[i] > 4)
				//	printf("bad things #4... %x %x %x\n", m_path[i], (*g_pBrain->m_gamepaths[x][y])[pathIndex].path[i], ((*g_pBrain->m_gamepaths[x][y])[pathIndex].path[i])&0xff);

			}
			
			//ReleaseMutex(g_pBrain->m_mutexHandles[x][y]);
			
			m_state = BUILDING_MATCHING;
		}
		break;
	case BUILDING_MATCHING:
		if(m_playerNum == 0 && m_wantDump)
			printf("player 0 is in BUILDING_MATCHING state\n");
		if(m_path[0] == NONE) // We finished matching up dice
		{
			if(g_pGame->m_gameboard[x][y].state == SINKING) // We finished a set!
			{
				FindPathFromSinker(x,y);
				m_state = MOVING_SINKER;
				m_diceValue = g_pGame->m_gameboard[x][y].dieState/4+1;
				CreateDiceList(x,y);
			}
			else // Hopefully, we're building a set
			{
				if(m_sDice.size() != 0) // we already have some dice set up...
				{
					if(m_diceValue == g_pGame->m_gameboard[x][y].dieState/4+1) // Make sure we successfully added a die
					{
						// Add die to list, find a path, anbd get moving!
						CreateDiceList(x,y);
						//if(!HasGoodPath(x,y))
						FindClosestRollerPath(x,y);
						m_state = BUILDING_MOVING;
					}
					else // We have dice, but for some reason our match didnt go well. 
					{
						// Try to find a new roller that matches these dice
						FindClosestRollerPath(x,y);

						if(m_path[0] == NONE) // Do we have a path now?
						{
							// Nope, no good rollers in the area that will match this set.
							// So, abandon set
							// TODO: Think about this more, I dont like to abandon sets...
							m_state = NO_MATCHES;
							break;
						}
						// Otherwise, we're good to go. Get moving!
						m_state = BUILDING_MOVING;

					}
				}
				else // we have no dice in our list, and we need something to do!
				{
					CreateDiceList(x,y); // See if we're sitting on a set of dice
					if(m_sDice.size() > 1) // >1 because 1 die isnt a set...
					{
						// Woo, we've got some nice dice, and now its our set. 
						// Go find a roller, and get moving!
						FindClosestRollerPath(x,y);
						m_state = BUILDING_MOVING;
					}
					else
					{
						// Wipe the dice list, go into BUILDING_MOVING, it'll know what to do
						m_sDice.clear();
						m_state = BUILDING_MOVING;
					}

				}


				//m_diceValue = g_pGame->m_gameboard[x][y].dieState/4+1;
				//CreateDiceList(x,y);
				//if(!HasGoodPath(x,y))
				//FindClosestRollerPath(x,y);
				//m_state = BUILDING_MOVING;			
				
			}
		}
		break;
	case MOVING_RISER:
		if(m_playerNum == 0 && m_wantDump)
			printf("player 0 is in MOVING_RISER state\n");
		//if(m_path[0] == NONE)
		//{
		// Always check this, so AI will always chase nearest riser, instead
		// of running to the first on that pops up
			if(g_pGame->m_gameboard[x][y].state == OCCUPIED)
				m_state = NO_MATCHES;
			else if(g_pGame->m_gameboard[x][y].state == RISING)
				m_state = NO_MATCHES;
			else
				FindPathToRiser(x,y);
		//}
		break;
	case MOVING_SINKER:
		if(m_playerNum == 0 && m_wantDump)
			printf("player 0 is in MOVING_SINKER state\n");
		if(g_pGame->m_gameboard[x][y].state == FREE)
		{
			m_state = MOVING_RISER;
			break;
		}
		if(m_path[0] == NONE)
		{
			if(g_pGame->m_gameboard[x][y].state == OCCUPIED)
				m_state = NO_MATCHES;
			else
			{
				FindPathFromSinker(x,y);
				if(m_path[0] == NONE) // still nothing
				{
					FindPathToRiser(x,y);
					if(m_path[0] != NONE) // We have something!
						m_state = MOVING_RISER;
				}

			}
		}
		break;
	case WAITING_RISER:	
	case WAITING_STUCK:	
	case CRUSHED:			
	case ON_GROUND:
		break;

	}

	/*
	//TODO: Implement me!
	if(m_path[0] == NONE)
	{
		if (g_pBrain->m_gamepaths[x][y]->size() == 0)//(pTempVect->size() == 0)
		{
			//printf("AI %i didnt find a path\n", m_playerNum);
			// TODO: Do something smart
			m_numRandResponses++;
			return (Direction)(rand()%5);
		}

		// Pick path with highest score
		for(i = 0; i < (int)g_pBrain->m_gamepaths[x][y]->size(); i++)
		{
			if((*g_pBrain->m_gamepaths[x][y])[i].score > maxScore)
			{
				maxScore = (*g_pBrain->m_gamepaths[x][y])[i].score;
				pathIndex = i;
			}
		}

		// Copy best path
		for(i = 0; i < MAX_PATH_LEN; i++)
			m_path[i] = (Direction)(((*g_pBrain->m_gamepaths[x][y])[pathIndex].path[i])&0xff);//(pTempVect->at(0)).path[i]; 
		
		// Currently, AI will finish a path, and then start a new one 
		// from the same point - destroying any match it made. So,
		// I'm going to temporarilty add a random movement to the end
		// of the path
		// Scan to first empty direction
		for(i = 0; i < MAX_PATH_LEN && m_path[i]!=NONE; i++); // Yeah, empty loop, I know.
		if(i<MAX_PATH_LEN) // Add random direction
			m_path[i] = (Direction)(rand()%5);
		*/

		/*printf("AI %i will follow: ", m_playerNum);
		for(i = 0; i < MAX_PATH_LEN && m_path[i] != NONE; i++)
		{
			switch(m_path[i])
			{
			case UP:
				printf("U");
				break;
			case DOWN:
				printf("D");
				break;
			case RIGHT:
				printf("R");
				break;
			case LEFT:
				printf("L");
				break;
			}
		}
		printf("\n");*/
	//}

	tempDir = m_path[0];
	// shift path down
	for(i = 0; i < MAX_PATH_LEN-1; i++)
			m_path[i] = m_path[i+1];
	m_path[MAX_PATH_LEN-1] = NONE;

	//if(g_pBrain->m_gamepaths[x][y]->size() != 0 && m_playerNum == 0)
		//printf("result dir: %i\n", tempDir);

	//if(tempDir > (Direction)4 || tempDir < (Direction)0)
	//{
		//printf("Bad things... \n", (int)tempDir);
		//for(i = 0; i < MAX_PATH_LEN; i++)
		//	printf("%i ", (int)m_path[i]);
		//printf("\n");
	//}
	return tempDir;
}

void AI::FindClosestRollerPath(int x, int y)
{
	int i,j,nx,ny;
	int oldLength, oldDieState, oldX, oldY; // Some temp vars 
	//int path[MAX_PATH_LEN];
	//int tempPos; // temporary path position (x<<16) + ( y<<8) + direction
	int key; // the path's position key: (x<<16) + ( y<<8) + diestate
	int score;
	Path tempPath; // a temporary path, for filling the vector
	vector<Path> vSearchPaths; // A vector of all the paths that we're working on
							   // Good paths still get put into m_gamepaths[x][y]
	set<int, less<int> > sPathEndpoints;
	//bool bFirstRun = true;

	// Clear our path
	for(i = 0; i < MAX_AI_PATH_LEN; i++)
		m_path[i] = NONE;
	for(i = 0; i < MAX_PATH_LEN; i++)
		tempPath.path[i] = NONE;

	// If this spot isnt occupied, I shouldnt even be here. 
	// But I'll check anyways
	if(g_pGame->m_gameboard[x][y].state != OCCUPIED)
	{
		// I shouldnt even be looking, I need to get to an occupied first!
		return;
	}

	key= (x<<16) +(y<<8) +g_pGame->m_gameboard[x][y].dieState;
	sPathEndpoints.insert(key); // Add this point to endpoint list, so
								// we dont come back here



	//for(i = 0; i<MAX_PATH_LEN;i++)
	//	tempPath.path[i] = (int)NONE;

	/*
	for(i = 0; i < 4; i++)
		{
			nx = x; ny = y;
			switch(i)
			{
			case LEFT:
				nx=x-1;
				break;
			case RIGHT:
				nx=x+1;
				break;
			case UP:
				ny=y-1;
				break;
			case DOWN:
				ny=y+1;
				break;
			default:
				return; // Something isnt right 
			}
			if(   nx <0 || nx >= g_pGame->m_boardSize
				||ny <0 || ny >= g_pGame->m_boardSize)
				continue; //this is a bad direction
			path[0] = (Direction)i;
			
			if(g_pGame->m_gameboard[nx][ny].state == OCCUPIED) // we're just walking...
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_gameboard[nx][ny].dieState, path, 1);
			else if(m_sDice.find((x<<8) + y) != m_sDice.end() && g_pGame->m_gameboard[nx][ny].state == FREE)
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);
			else if (m_sDice.find((x<<8) + y) != m_sDice.end() && g_pGame->m_gameboard[nx][ny].state == RISING && g_pGame->m_gameboard[nx][ny].y <= .5)
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);
			else if (m_sDice.find((x<<8) + y) != m_sDice.end() && g_pGame->m_gameboard[nx][ny].state == SINKING && g_pGame->m_gameboard[nx][ny].y <= .5)
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);
	*/
	
	for(i = 0; i < 4; i++)
	{
		nx = x; ny = y;
		switch(i)
		{
		case LEFT:
			nx=x-1;
			break;
		case RIGHT:
			nx=x+1;
			break;
		case UP:
			ny=y-1;
			break;
		case DOWN:
			ny=y+1;
			break;
		default:
			continue; // Something isnt right 
		}
		if(   nx <0 || nx >= g_pGame->m_boardSize
			||ny <0 || ny >= g_pGame->m_boardSize)
			continue; //this is a bad direction
		//path[0] = (nx<<16)+(ny<<8)+i;
		tempPath.path[0] = (nx<<16)+(ny<<8)+i;
		tempPath.length = 1;
		tempPath.final_x = nx;
		tempPath.final_y = ny;

		if(g_pGame->m_gameboard[nx][ny].state == OCCUPIED) // we're just walking...
		{
			tempPath.die_state = g_pGame->m_gameboard[nx][ny].dieState;
			vSearchPaths.push_back(tempPath);
		}
			//FindClosestRollerPathHelper(nx, ny, g_pGame->m_gameboard[nx][ny].dieState, path, 1);
		else if(m_sDice.find((x<<8) + y) == m_sDice.end() && g_pGame->m_gameboard[nx][ny].state == FREE)
		{
			tempPath.die_state =  g_pGame->m_transTable[ g_pGame->m_gameboard[x][y].dieState][i];
			vSearchPaths.push_back(tempPath);
		}
			//FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);
		else if (m_sDice.find((x<<8) + y) == m_sDice.end() && g_pGame->m_gameboard[nx][ny].state == RISING && g_pGame->m_gameboard[nx][ny].y <= .5)
		{
			tempPath.die_state =  g_pGame->m_transTable[ g_pGame->m_gameboard[x][y].dieState][i];
			vSearchPaths.push_back(tempPath);
		}	
		//FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);
		else if (m_sDice.find((x<<8) + y) == m_sDice.end() && g_pGame->m_gameboard[nx][ny].state == SINKING && g_pGame->m_gameboard[nx][ny].y <= .5)
		{
			tempPath.die_state =  g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i];
			vSearchPaths.push_back(tempPath);
		}		
			//FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);


		/*
		if(m_game.m_gameboard[nx][ny].state == FREE)
		{
			tempPath.die_state = m_game.m_transTable[m_game.m_gameboard[x][y].dieState][i];
			vSearchPaths.push_back(tempPath);
		}
			//FindRollingPathsHelper(x,y,nx, ny, m_game.m_transTable[m_game.m_gameboard[x][y].dieState][i], path, 1);
		else if (m_game.m_gameboard[nx][ny].state == RISING && m_game.m_gameboard[nx][ny].y <= .5)
		{
			tempPath.die_state = m_game.m_transTable[m_game.m_gameboard[x][y].dieState][i];
			vSearchPaths.push_back(tempPath);
		}
			//FindRollingPathsHelper(x,y,nx, ny, m_game.m_transTable[m_game.m_gameboard[x][y].dieState][i], path, 1);
		else if (m_game.m_gameboard[nx][ny].state == SINKING && m_game.m_gameboard[nx][ny].y <= .5)
		{
			tempPath.die_state = m_game.m_transTable[m_game.m_gameboard[x][y].dieState][i];
			vSearchPaths.push_back(tempPath);
		}
			//FindRollingPathsHelper(x,y,nx, ny, m_game.m_transTable[m_game.m_gameboard[x][y].dieState][i], path, 1);
	
		*/
	}

	while(vSearchPaths.size() > 0)
	{

		for(i = 0; i < (int)vSearchPaths.size(); i++)
		{
			for(j = 0; j < MAX_PATH_LEN; j++)
				tempPath.path[j] = vSearchPaths[i].path[j];
			tempPath.die_state = vSearchPaths[i].die_state;
			tempPath.final_x = vSearchPaths[i].final_x;
			tempPath.final_y = vSearchPaths[i].final_y; 
			tempPath.length = vSearchPaths[i].length; 
			
			//tempPath = vSearchPaths[i]; // Get the Path we're working on...

			key= (tempPath.final_x<<16) +(tempPath.final_y<<8) +tempPath.die_state;

			
			if(sPathEndpoints.find(key) != sPathEndpoints.end())
			{
				
				vSearchPaths.erase(vSearchPaths.begin() + i);
				i--;
				continue;
				//return; // We've already been here before.
			}
			else
			{
				
				sPathEndpoints.insert(key); // And now we wont come back here.
			}

			if(m_sDice.find((tempPath.final_x<<8) + tempPath.final_y) == m_sDice.end() && HasGoodPath(tempPath.final_x,tempPath.final_y) != -1)
			{   // ^^^ Make sure to check to see if this die is in ou list, so we dont roll it away
				
				// We've found a good paths, copy it and return.
				for(j = 0; j < MAX_PATH_LEN; j++)
					m_path[j] = (Direction)(tempPath.path[j]&0xff);
				if(m_path[j] > 4)
					printf("BAd things #5... %x %x %x\n", m_path[j], tempPath.path[j], tempPath.path[j]&0xff);
				if(m_wantDump)
				{
					//m_wantDump = false;
					for(j = 0; j < MAX_PATH_LEN && m_path[j] != NONE; j++)
					{	
						switch(m_path[j])
						{
						case UP:
							printf("U");
							break;
						case DOWN:
							printf("D");
							break;
						case RIGHT:
							printf("R");
							break;
						case LEFT:
							printf("L");
							break;
						}
					}
					printf("\n");
				}
				return;
				
			}

			if(tempPath.length>=MAX_PATH_LEN)
			{
				vSearchPaths.erase(vSearchPaths.begin() + i);
				i--;
				continue;
				//return; // We're at maximum depth.
			}

			//for(i = 0; i < MAX_PATH_LEN; i++)
			//	path[i] = oldPath[i];

			oldLength = tempPath.length;
			tempPath.length++;
			oldDieState = tempPath.die_state;
			oldX = tempPath.final_x;
			oldY = tempPath.final_y;

			for(j = 0; j < 4; j++)
			{
				nx = oldX; ny = oldY;
				switch(j)
				{
				case LEFT:
					nx--;
					break;
				case RIGHT:
					nx++;
					break;
				case UP:
					ny--;
					break;
				case DOWN:
					ny++;
					break;
				default:
					continue; // Something isnt right 
				}
				if(   nx <0 || nx >= g_pGame->m_boardSize
					||ny <0 || ny >= g_pGame->m_boardSize)
					continue; //this is a bad direction

				tempPath.path[oldLength] = (nx<<16)+(ny<<8)+j;
				tempPath.final_x = nx;
				tempPath.final_y = ny;

				if(g_pGame->m_gameboard[nx][ny].state == OCCUPIED) // we're just walking...
				{
					tempPath.die_state = g_pGame->m_gameboard[nx][ny].dieState;
					vSearchPaths.push_back(tempPath);
				}
					//FindClosestRollerPathHelper(nx, ny, g_pGame->m_gameboard[nx][ny].dieState, path, 1);
				else if(m_sDice.find((nx<<8) + ny) == m_sDice.end() && g_pGame->m_gameboard[nx][ny].state == FREE)
				{
					//printf("ping!\n");
					tempPath.die_state = g_pGame->m_transTable[oldDieState][j];
					vSearchPaths.push_back(tempPath);
				}
					//FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);
				else if (m_sDice.find((nx<<8) + ny) == m_sDice.end() && g_pGame->m_gameboard[nx][ny].state == RISING && g_pGame->m_gameboard[nx][ny].y <= .5)
				{
					//printf("ping!\n");
					tempPath.die_state = g_pGame->m_transTable[oldDieState][j];
					vSearchPaths.push_back(tempPath);
				}	
				//FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);
				else if (m_sDice.find((nx<<8) + ny) == m_sDice.end() && g_pGame->m_gameboard[nx][ny].state == SINKING && g_pGame->m_gameboard[nx][ny].y <= .5)
				{
					//printf("ping!\n");
					tempPath.die_state = g_pGame->m_transTable[oldDieState][j];
					vSearchPaths.push_back(tempPath);
				}		
					//FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);


				/*
				if(m_game.m_gameboard[nx][ny].state == FREE)
				{
					//printf("ping!\n");
					tempPath.die_state = m_game.m_transTable[oldDieState][j];
					vSearchPaths.push_back(tempPath);
				}
					//FindRollingPathsHelper(startX, startY, nx, ny, m_game.m_transTable[dieState][i], path, Depth+1);
				else if (m_game.m_gameboard[nx][ny].state == RISING && m_game.m_gameboard[nx][ny].y <= .5)
				{
					tempPath.die_state = m_game.m_transTable[oldDieState][j];
					vSearchPaths.push_back(tempPath);
				}
				//FindRollingPathsHelper(startX, startY, nx, ny, m_game.m_transTable[dieState][i], path, Depth+1);
				else if (m_game.m_gameboard[nx][ny].state == SINKING && m_game.m_gameboard[nx][ny].y <= .5)
				{
					tempPath.die_state = m_game.m_transTable[oldDieState][j];
					vSearchPaths.push_back(tempPath);
				}
					//FindRollingPathsHelper(startX, startY, nx, ny, m_game.m_transTable[dieState][i], path, Depth+1);
				*/
			}

			// We've processed this path, erase it, and reset 'i' so we
			// check this potition again.
			vSearchPaths.erase(vSearchPaths.begin() + i);
			i--;
		}



	}


		

	return; // We didnt find anything!
}

/*
// FIXME!! Agh! This wont find the closest at all! It will find a path though, I hope.
// Now I have to do some thinking...
void AI::FindClosestRollerPath(int x, int y)
{
	int i,nx,ny;
	Direction path[MAX_AI_PATH_LEN];

	// Clear out our path
	for(i = 0; i <MAX_AI_PATH_LEN; i++)
		m_path[i] = NONE;

	m_sPosList.clear();

	if(m_diceValue == 0) // we can mess up any dice we want
	{
		for(i = 0; i < 4; i++)
		{
			nx = x; ny = y;
			switch(i)
			{
			case LEFT:
				nx=x-1;
				break;
			case RIGHT:
				nx=x+1;
				break;
			case UP:
				ny=y-1;
				break;
			case DOWN:
				ny=y+1;
				break;
			default:
				return; // Something isnt right 
			}
			if(   nx <0 || nx >= g_pGame->m_boardSize
				||ny <0 || ny >= g_pGame->m_boardSize)
				continue; //this is a bad direction
			path[0] = (Direction)i;
			
			if(g_pGame->m_gameboard[nx][ny].state == OCCUPIED) // we're just walking...
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_gameboard[nx][ny].dieState, path, 1);
			else if(g_pGame->m_gameboard[nx][ny].state == FREE)
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);
			else if (g_pGame->m_gameboard[nx][ny].state == RISING && g_pGame->m_gameboard[nx][ny].y <= .5)
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);
			else if (g_pGame->m_gameboard[nx][ny].state == SINKING && g_pGame->m_gameboard[nx][ny].y <= .5)
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);
		}
	}
	else // We need to be careful about what dice we mess up
	{
		for(i = 0; i < 4; i++)
		{
			nx = x; ny = y;
			switch(i)
			{
			case LEFT:
				nx=x-1;
				break;
			case RIGHT:
				nx=x+1;
				break;
			case UP:
				ny=y-1;
				break;
			case DOWN:
				ny=y+1;
				break;
			default:
				return; // Something isnt right 
			}
			if(   nx <0 || nx >= g_pGame->m_boardSize
				||ny <0 || ny >= g_pGame->m_boardSize)
				continue; //this is a bad direction
			path[0] = (Direction)i;
			
			if(g_pGame->m_gameboard[nx][ny].state == OCCUPIED) // we're just walking...
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_gameboard[nx][ny].dieState, path, 1);
			else if(m_sDice.find((x<<8) + y) != m_sDice.end() && g_pGame->m_gameboard[nx][ny].state == FREE)
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);
			else if (m_sDice.find((x<<8) + y) != m_sDice.end() && g_pGame->m_gameboard[nx][ny].state == RISING && g_pGame->m_gameboard[nx][ny].y <= .5)
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);
			else if (m_sDice.find((x<<8) + y) != m_sDice.end() && g_pGame->m_gameboard[nx][ny].state == SINKING && g_pGame->m_gameboard[nx][ny].y <= .5)
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);
		}

	}


}
*/

/*
void AI::FindClosestRollerPathHelper(int x,int y,int dieState, Direction *oldPath, int Depth)
{
	int i,j,nx,ny;
	Direction path[MAX_AI_PATH_LEN];

	for(i = 0; i < MAX_AI_PATH_LEN; i++)
		path[i] = oldPath[i];

	if(m_diceValue != 0) // We're targetting a specific die value
	{
		for(i = 0; i < (int)g_pBrain->m_gamepaths[x][y]->size(); i++)
		{
			if( (*g_pBrain->m_gamepaths[x][y])[i].die_state/4+1 == m_diceValue)
			{
				// TODO: Make sure the path back wouldnt mess up
				// dice before approving it
				for(j = 0; j < MAX_AI_PATH_LEN; j++)
					m_path[j] = path[j];
				return; // Quit, we've got a path
			}

		}

		m_sPosList.insert((x<<8)+y);

		// Try to continue this path
		for(i = 0; i < 4; i++)
		{
			nx = x; ny = y;
			switch(i)
			{
			case LEFT:
				nx=x-1;
				break;
			case RIGHT:
				nx=x+1;
				break;
			case UP:
				ny=y-1;
				break;
			case DOWN:
				ny=y+1;
				break;
			default:
				return; // Something isnt right 
			}
			if(   nx <0 || nx >= g_pGame->m_boardSize
				||ny <0 || ny >= g_pGame->m_boardSize)
				continue; //this is a bad direction
			path[Depth] = (Direction)i;
			
			if(m_sPosList.find((nx<<8) + ny) != m_sPosList.end() && g_pGame->m_gameboard[nx][ny].state == OCCUPIED) // we're just walking...
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_gameboard[nx][ny].dieState, path, Depth+1);
			else if(m_sPosList.find((nx<<8) + ny) != m_sPosList.end() && m_sDice.find((x<<8) + y) != m_sDice.end() && g_pGame->m_gameboard[nx][ny].state == FREE)
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, Depth+1);
			else if (m_sPosList.find((nx<<8) + ny) != m_sPosList.end() && m_sDice.find((x<<8) + y) != m_sDice.end() && g_pGame->m_gameboard[nx][ny].state == RISING && g_pGame->m_gameboard[nx][ny].y <= .5)
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, Depth+1);
			else if (m_sPosList.find((nx<<8) + ny) != m_sPosList.end() && m_sDice.find((x<<8) + y) != m_sDice.end() && g_pGame->m_gameboard[nx][ny].state == SINKING && g_pGame->m_gameboard[nx][ny].y <= .5)
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, Depth+1);
		}
	}
	else // we can move wherever we want, basically
	{
		
		if( g_pBrain->m_gamepaths[x][y]->size() > 0)
		{
			for(j = 0; j < MAX_AI_PATH_LEN; j++)
				m_path[j] = path[j];
			return; // Quit, we've got a path
		}

		m_sPosList.insert((x<<8)+y);

		// Try to continue this path
		for(i = 0; i < 4; i++)
		{
			nx = x; ny = y;
			switch(i)
			{
			case LEFT:
				nx=x-1;
				break;
			case RIGHT:
				nx=x+1;
				break;
			case UP:
				ny=y-1;
				break;
			case DOWN:
				ny=y+1;
				break;
			default:
				return; // Something isnt right 
			}
			if(   nx <0 || nx >= g_pGame->m_boardSize
				||ny <0 || ny >= g_pGame->m_boardSize)
				continue; //this is a bad direction
			path[0] = (Direction)i;
			
			if(m_sPosList.find((nx<<8) + ny) != m_sPosList.end() && g_pGame->m_gameboard[nx][ny].state == OCCUPIED) // we're just walking...
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_gameboard[nx][ny].dieState, path, 1);
			else if(m_sPosList.find((nx<<8) + ny) != m_sPosList.end() && g_pGame->m_gameboard[nx][ny].state == FREE)
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);
			else if (m_sPosList.find((nx<<8) + ny) != m_sPosList.end() && g_pGame->m_gameboard[nx][ny].state == RISING && g_pGame->m_gameboard[nx][ny].y <= .5)
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);
			else if (m_sPosList.find((nx<<8) + ny) != m_sPosList.end() && g_pGame->m_gameboard[nx][ny].state == SINKING && g_pGame->m_gameboard[nx][ny].y <= .5)
				FindClosestRollerPathHelper(nx, ny, g_pGame->m_transTable[g_pGame->m_gameboard[x][y].dieState][i], path, 1);
		}
	}

	return;

}
*/

int AI::HasGoodPath(int x, int y)
{
	//TODO: Make better, I dont check if dice get messed up
	int i,j,dieX, dieY;

	//WaitForSingleObject(g_pBrain->m_mutexHandles[x][y], INFINITE);

	if(g_pBrain->m_gamepaths[x][y]->size() == 0)
	{
		//ReleaseMutex(g_pBrain->m_mutexHandles[x][y]);
		return -1; // No paths here
	}

	if(m_sDice.size() == 0)
	{
		//ReleaseMutex(g_pBrain->m_mutexHandles[x][y]);
		return 0; // We dont have any dice set up, so any match is good
				  // Should never use this, because it has no path picking logic
	}

	for(i = 0; i < (int)g_pBrain->m_gamepaths[x][y]->size(); i++)
	{
		if( (*g_pBrain->m_gamepaths[x][y])[i].die_state/4 + 1 == m_diceValue) // theres a potential...
		{
			dieX = (*g_pBrain->m_gamepaths[x][y])[i].final_x;
			dieY = (*g_pBrain->m_gamepaths[x][y])[i].final_y;

			// Search list for adjacent dice
			if(m_sDice.find((dieX<<8)+(dieY+1)) != m_sDice.end())
			{
				//ReleaseMutex(g_pBrain->m_mutexHandles[x][y]);
				return i;
			}
			else if(m_sDice.find((dieX<<8)+(dieY-1)) != m_sDice.end())
			{
				//ReleaseMutex(g_pBrain->m_mutexHandles[x][y]);
				return i;
			}
			else if(m_sDice.find(((dieX+1)<<8)+dieY) != m_sDice.end())
			{
				//ReleaseMutex(g_pBrain->m_mutexHandles[x][y]);
				return i;
			}
			else if(m_sDice.find(((dieX-1)<<8)+dieY) != m_sDice.end())
			{
				//ReleaseMutex(g_pBrain->m_mutexHandles[x][y]);
				return i;
			}
		
		}
	}
	
	//ReleaseMutex(g_pBrain->m_mutexHandles[x][y]);

	return -1;
}

void AI::VerifyDiceSet()
{
	set <int>::iterator sIter;
	int i;
	int x,y;
	vector <int> vBadDice; // list of dice that shouldnt be in the set anymore ((x<<8)+y)

	if(m_sDice.size() == 0)
	{
		m_diceValue = 0;
		return; // the set is empty, so its good
	}
	if(m_diceValue == 0)
	{
		// No die value is set, so if there are any dice in the set, theyre all invalid
		m_sDice.clear();
		return;
	}

	for(sIter = m_sDice.begin(); sIter != m_sDice.end(); sIter++)
	{
		x = (*sIter >> 8)&0xff;
		y = *sIter & 0xFF;
		if(g_pGame->m_gameboard[x][y].dieState/4+1 != m_diceValue ||
			!(g_pGame->m_gameboard[x][y].state == OCCUPIED || g_pGame->m_gameboard[x][y].state == SINKING))
			vBadDice.push_back((x<<8)+y);
	}

	for (i = 0; i < vBadDice.size(); i++)
		m_sDice.erase(vBadDice[i]);

	if(m_sDice.size() == 0)
		m_diceValue = 0;
}

void AI::FindPathFromSinker(int x, int y)
{
	int i,j,k,nx,ny;
	float dY, tempY1, tempY2;
	int oldLength, oldDieState, oldX, oldY; // Some temp vars 
	//int path[MAX_PATH_LEN];
	//int tempPos; // temporary path position (x<<16) + ( y<<8) + direction
	int key; // the path's position key: (x<<16) + ( y<<8) + diestate
	Path tempPath; // a temporary path, for filling the vector
	vector<Path> vSearchPaths; // A vector of all the paths that we're working on
							   // Good paths still get put into m_gamepaths[x][y]
	set<int, less<int> > sPathEndpoints;

	// Clear our path
	for(i = 0; i < MAX_AI_PATH_LEN; i++)
		m_path[i] = NONE;
	for(i = 0; i < MAX_PATH_LEN; i++)
		tempPath.path[i] = NONE;

	// If this spot isnt sinking, I shouldnt even be here. 
	// But I'll check anyways
	if(g_pGame->m_gameboard[x][y].state != SINKING)
	{
		// I shouldnt even be looking, I'm not even on a sinker!
		return;
	}

	
	for(i = 0; i < 4; i++)
	{
		nx = x; ny = y;
		switch(i)
		{
		case LEFT:
			nx=x-1;
			break;
		case RIGHT:
			nx=x+1;
			break;
		case UP:
			ny=y-1;
			break;
		case DOWN:
			ny=y+1;
			break;
		default:
			continue; // Something isnt right 
		}
		if(   nx <0 || nx >= g_pGame->m_boardSize
			||ny <0 || ny >= g_pGame->m_boardSize)
			continue; //this is a bad direction
		//path[0] = (nx<<16)+(ny<<8)+i;
		tempPath.path[0] = (nx<<16)+(ny<<8)+i;
		tempPath.length = 1;
		tempPath.final_x = nx;
		tempPath.final_y = ny;

		tempY1 = g_pGame->m_gameboard[x][y].y;
		tempY2 = g_pGame->m_gameboard[nx][ny].y;
		// Free spaces might not have a Y of 0, so fix that
		// TODO: Fix this in DiceGame, not here.
		if(g_pGame->m_gameboard[x][y].state == FREE)
			tempY1 = 0.0f;
		if(g_pGame->m_gameboard[nx][ny].state == FREE)
			tempY2 = 0.0f;
		if(g_pGame->m_gameboard[x][y].state == OCCUPIED)
			tempY1 = 1.0f;
		if(g_pGame->m_gameboard[nx][ny].state == OCCUPIED)
			tempY2 = 1.0f;

		if(tempY2 > tempY1)
			dY = tempY2 - tempY1;
		else
			dY = tempY1 - tempY2;
		if(g_pGame->m_gameboard[nx][ny].state == OCCUPIED && dY <= MAX_Y_VARIANCE)
		{
			// Hell, we already found a path!
			for(j = 0; j < MAX_PATH_LEN; j++)
				m_path[j] = (Direction)(tempPath.path[j]&0xFF);
			//if(m_path[j] > 4)
			//	printf("bad things #6... %x %x %x\n", m_path[j], tempPath.path[j], tempPath.path[j]&0xFF);

			return;
		}
		else if(g_pGame->m_gameboard[nx][ny].state == RISING && dY <= MAX_Y_VARIANCE)
		{
			tempPath.die_state = g_pGame->m_gameboard[nx][ny].dieState;
			vSearchPaths.push_back(tempPath);
		}	
		else if(g_pGame->m_gameboard[nx][ny].state == SINKING && dY <= MAX_Y_VARIANCE)
		{
			g_pGame->m_gameboard[nx][ny].dieState;
			vSearchPaths.push_back(tempPath);
		}
		else if(g_pGame->m_gameboard[nx][ny].state == FREE && dY <= MAX_Y_VARIANCE)
		{  // Checking FREE spaces, even though a path from them is unlikely
			g_pGame->m_gameboard[nx][ny].dieState;
			vSearchPaths.push_back(tempPath);
		}	
	}

	while(vSearchPaths.size() > 0)
	{

		for(i = 0; i < (int)vSearchPaths.size(); i++)
		{
			for(j = 0; j < MAX_PATH_LEN; j++)
				tempPath.path[j] = vSearchPaths[i].path[j];
			tempPath.die_state = vSearchPaths[i].die_state;
			tempPath.final_x = vSearchPaths[i].final_x;
			tempPath.final_y = vSearchPaths[i].final_y; 
			tempPath.length = vSearchPaths[i].length; 
			
			//tempPath = vSearchPaths[i]; // Get the Path we're working on...

			key= (tempPath.final_x<<16) +(tempPath.final_y<<8) +tempPath.die_state;

			
			if(sPathEndpoints.find(key) != sPathEndpoints.end())
			{
				
				vSearchPaths.erase(vSearchPaths.begin() + i);
				i--;
				continue;
				//return; // We've already been here before.
			}
			else
			{
				
				sPathEndpoints.insert(key); // And now we wont come back here.
			}

			if(tempPath.length>=MAX_PATH_LEN)
			{
				vSearchPaths.erase(vSearchPaths.begin() + i);
				i--;
				continue;
				//return; // We're at maximum depth.
			}


			oldLength = tempPath.length;
			tempPath.length++;
			oldDieState = tempPath.die_state;
			oldX = tempPath.final_x;
			oldY = tempPath.final_y;

			for(j = 0; j < 4; j++)
			{
				nx = oldX; ny = oldY;
				switch(j)
				{
				case LEFT:
					nx--;
					break;
				case RIGHT:
					nx++;
					break;
				case UP:
					ny--;
					break;
				case DOWN:
					ny++;
					break;
				default:
					continue; // Something isnt right 
				}
				if(   nx <0 || nx >= g_pGame->m_boardSize
					||ny <0 || ny >= g_pGame->m_boardSize)
					continue; //this is a bad direction

				tempPath.path[oldLength] = (nx<<16)+(ny<<8)+j;

				//if((tempPath.path[oldLength]&0xff) > 4)
				//	printf("double bad things... %x %x %x\n", j, tempPath.path[oldLength], tempPath.path[oldLength]&0xff );

				tempPath.final_x = nx;
				tempPath.final_y = ny;

				tempY1 = g_pGame->m_gameboard[x][y].y;
				tempY2 = g_pGame->m_gameboard[nx][ny].y;
				// Free spaces might not have a Y of 0, so fix that
				// TODO: Fix this in DiceGame, not here.
				if(g_pGame->m_gameboard[x][y].state == FREE)
					tempY1 = 0.0f;
				if(g_pGame->m_gameboard[nx][ny].state == FREE)
					tempY2 = 0.0f;
				if(g_pGame->m_gameboard[x][y].state == OCCUPIED)
					tempY1 = 1.0f;
				if(g_pGame->m_gameboard[nx][ny].state == OCCUPIED)
					tempY2 = 1.0f;

				if(tempY2 > tempY1)
					dY = tempY2 - tempY1;
				else
					dY = tempY1 - tempY2;

				if(g_pGame->m_gameboard[nx][ny].state == OCCUPIED && dY <= MAX_Y_VARIANCE)
				{
					//Heres our path
					for(k = 0; k < MAX_PATH_LEN; k++)
					{
						m_path[k] = (Direction)(tempPath.path[k]&0xFF);
						//if(m_path[k] > 4)
						//	printf("triple bad things... %x %x %x\n", j, tempPath.path[k], tempPath.path[k]&0xff );
					}

					return;
				}	
				else if(g_pGame->m_gameboard[nx][ny].state == RISING && dY <= MAX_Y_VARIANCE)
				{
					//printf("ping!\n");
					tempPath.die_state = g_pGame->m_gameboard[nx][ny].dieState;
					vSearchPaths.push_back(tempPath);
				}	
				else if (g_pGame->m_gameboard[nx][ny].state == SINKING && dY <= MAX_Y_VARIANCE)
				{
					//printf("ping!\n");
					tempPath.die_state = g_pGame->m_gameboard[nx][ny].dieState;
					vSearchPaths.push_back(tempPath);
				}	
				else if (g_pGame->m_gameboard[nx][ny].state == FREE && dY <= MAX_Y_VARIANCE)
				{
					// Checking free spaces, even though a path from them is unlikely
					tempPath.die_state = g_pGame->m_gameboard[nx][ny].dieState;
					vSearchPaths.push_back(tempPath);
				}
					
				
			}

			// We've processed this path, erase it, and reset 'i' so we
			// check this potition again.
			vSearchPaths.erase(vSearchPaths.begin() + i);
			i--;
		}



	}

	return; // We didnt find anything!
}

void AI::FindPathToRiser(int x, int y)
{
	int i,j,k,nx,ny;
	float dY, tempY1, tempY2;
	int oldLength, oldDieState, oldX, oldY; // Some temp vars 
	//int path[MAX_PATH_LEN];
	//int tempPos; // temporary path position (x<<16) + ( y<<8) + direction
	int key; // the path's position key: (x<<16) + ( y<<8) + diestate
	Path tempPath; // a temporary path, for filling the vector
	vector<Path> vSearchPaths; // A vector of all the paths that we're working on

	set<int, less<int> > sPathEndpoints;

	// Clear our path
	for(i = 0; i < MAX_AI_PATH_LEN; i++)
		m_path[i] = NONE;
	for(i = 0; i < MAX_PATH_LEN; i++)
		tempPath.path[i] = NONE;

	// If I'm at a riser or occupied, I shouldnt even be here
	if(g_pGame->m_gameboard[x][y].state == RISING || g_pGame->m_gameboard[x][y].state == OCCUPIED)
	{
		return;
	}

	
	for(i = 0; i < 4; i++)
	{
		nx = x; ny = y;
		switch(i)
		{
		case LEFT:
			nx=x-1;
			break;
		case RIGHT:
			nx=x+1;
			break;
		case UP:
			ny=y-1;
			break;
		case DOWN:
			ny=y+1;
			break;
		default:
			continue; // Something isnt right 
		}
		if(   nx <0 || nx >= g_pGame->m_boardSize
			||ny <0 || ny >= g_pGame->m_boardSize)
			continue; //this is a bad direction
		//path[0] = (nx<<16)+(ny<<8)+i;
		tempPath.path[0] = (nx<<16)+(ny<<8)+i;
		tempPath.length = 1;
		tempPath.final_x = nx;
		tempPath.final_y = ny;

		tempY1 = g_pGame->m_gameboard[x][y].y;
		tempY2 = g_pGame->m_gameboard[nx][ny].y;
		// Free spaces might not have a Y of 0, so fix that
		// TODO: Fix this in DiceGame, not here.
		if(g_pGame->m_gameboard[x][y].state == FREE)
			tempY1 = 0.0f;
		if(g_pGame->m_gameboard[nx][ny].state == FREE)
			tempY2 = 0.0f;
		if(g_pGame->m_gameboard[x][y].state == OCCUPIED)
			tempY1 = 1.0f;
		if(g_pGame->m_gameboard[nx][ny].state == OCCUPIED)
			tempY2 = 1.0f;

		if(tempY2 > tempY1)
			dY = tempY2 - tempY1;
		else
			dY = tempY1 - tempY2;

		//printf("%f\n", dY);

		if(g_pGame->m_gameboard[nx][ny].state == OCCUPIED && dY <= MAX_Y_VARIANCE)
		{
			// Hell, we already found a path! Even though we're looking for risers, this is good too.
			for(j = 0; j < MAX_PATH_LEN; j++)
				m_path[j] = (Direction)(tempPath.path[j]&0xFF);
			
			return;
		}
		else if(g_pGame->m_gameboard[nx][ny].state == RISING && dY <= MAX_Y_VARIANCE)
		{
			// Hell, we already found a path! 
			for(j = 0; j < MAX_PATH_LEN; j++)
				m_path[j] = (Direction)(tempPath.path[j]&0xFF);
			return;
			
		}	
		else if(g_pGame->m_gameboard[nx][ny].state == SINKING && dY <= MAX_Y_VARIANCE)
		{
			g_pGame->m_gameboard[nx][ny].dieState;
			vSearchPaths.push_back(tempPath);
		}
		else if(g_pGame->m_gameboard[nx][ny].state == FREE && dY <= MAX_Y_VARIANCE)
		{
			//printf("ping! %f\n", dY);
			g_pGame->m_gameboard[nx][ny].dieState;
			vSearchPaths.push_back(tempPath);
		}
	}

	while(vSearchPaths.size() > 0)
	{

		for(i = 0; i < (int)vSearchPaths.size(); i++)
		{
			for(j = 0; j < MAX_PATH_LEN; j++)
				tempPath.path[j] = vSearchPaths[i].path[j];
			tempPath.die_state = vSearchPaths[i].die_state;
			tempPath.final_x = vSearchPaths[i].final_x;
			tempPath.final_y = vSearchPaths[i].final_y; 
			tempPath.length = vSearchPaths[i].length; 
			
			//tempPath = vSearchPaths[i]; // Get the Path we're working on...

			key= (tempPath.final_x<<16) +(tempPath.final_y<<8) +tempPath.die_state;

			
			if(sPathEndpoints.find(key) != sPathEndpoints.end())
			{
				
				vSearchPaths.erase(vSearchPaths.begin() + i);
				i--;
				continue;
				//return; // We've already been here before.
			}
			else
			{
				
				sPathEndpoints.insert(key); // And now we wont come back here.
			}

			if(tempPath.length>=MAX_PATH_LEN)
			{
				vSearchPaths.erase(vSearchPaths.begin() + i);
				i--;
				continue;
				//return; // We're at maximum depth.
			}


			oldLength = tempPath.length;
			tempPath.length++;
			oldDieState = tempPath.die_state;
			oldX = tempPath.final_x;
			oldY = tempPath.final_y;

			for(j = 0; j < 4; j++)
			{
				nx = oldX; ny = oldY;
				switch(j)
				{
				case LEFT:
					nx--;
					break;
				case RIGHT:
					nx++;
					break;
				case UP:
					ny--;
					break;
				case DOWN:
					ny++;
					break;
				default:
					continue; // Something isnt right 
				}
				if(   nx <0 || nx >= g_pGame->m_boardSize
					||ny <0 || ny >= g_pGame->m_boardSize)
					continue; //this is a bad direction

				tempPath.path[oldLength] = (nx<<16)+(ny<<8)+j;

				tempPath.final_x = nx;
				tempPath.final_y = ny;

				tempY1 = g_pGame->m_gameboard[x][y].y;
				tempY2 = g_pGame->m_gameboard[nx][ny].y;
				// Free spaces might not have a Y of 0, so fix that
				// TODO: Fix this in DiceGame, not here.
				if(g_pGame->m_gameboard[x][y].state == FREE)
					tempY1 = 0.0f;
				if(g_pGame->m_gameboard[nx][ny].state == FREE)
					tempY2 = 0.0f;
				if(g_pGame->m_gameboard[x][y].state == OCCUPIED)
					tempY1 = 1.0f;
				if(g_pGame->m_gameboard[nx][ny].state == OCCUPIED)
					tempY2 = 1.0f;

				if(tempY2 > tempY1)
					dY = tempY2 - tempY1;
				else
					dY = tempY1 - tempY2;

				if(g_pGame->m_gameboard[nx][ny].state == OCCUPIED && dY <= MAX_Y_VARIANCE)
				{
					//Heres our path
					for(k = 0; k < MAX_PATH_LEN; k++)
					{
						m_path[k] = (Direction)(tempPath.path[k]&0xFF);
						//if(m_path[k] > 4)
						//	printf("triple bad things... %x %x %x\n", j, tempPath.path[k], tempPath.path[k]&0xff );
					}

					return;
				}	
				else if(g_pGame->m_gameboard[nx][ny].state == RISING && dY <= MAX_Y_VARIANCE)
				{
					//Heres our path
					for(k = 0; k < MAX_PATH_LEN; k++)
					{
						m_path[k] = (Direction)(tempPath.path[k]&0xFF);
						//if(m_path[k] > 4)
						//	printf("triple bad things... %x %x %x\n", j, tempPath.path[k], tempPath.path[k]&0xff );
					}

					return;
				}		
				else if (g_pGame->m_gameboard[nx][ny].state == SINKING && dY <= MAX_Y_VARIANCE)
				{
					//printf("ping!\n");
					tempPath.die_state = g_pGame->m_gameboard[nx][ny].dieState;
					vSearchPaths.push_back(tempPath);
				}
				else if (g_pGame->m_gameboard[nx][ny].state == FREE && dY <= MAX_Y_VARIANCE)
				{
					//printf("ping2!\n");
					tempPath.die_state = g_pGame->m_gameboard[nx][ny].dieState;
					vSearchPaths.push_back(tempPath);
				}
					
				
			}

			// We've processed this path, erase it, and reset 'i' so we
			// check this potition again.
			vSearchPaths.erase(vSearchPaths.begin() + i);
			i--;
		}



	}

	return; // We didnt find anything!
}

// Creates a list of matching dice adjacent
// to x,y with value of, well, 'value'
// Copied from CDiceGame's CreateSinkers
void AI::CreateDiceList(int x, int y) 
{
	int i, j,tempX, tempY;
	int nx, ny;
	int numSunk = 0; 
	int numMatched=0;
	int maxChain = 0;

	// The value of the die here
	//int value = (m_game.m_gameboard[x][y].dieState / 4) + 1;
	int score = 0; // The score I get from occ->sinks
	int chainscore = 0;// The score I get from chaining

	int value = g_pGame->m_gameboard[x][y].dieState/4 +1; 

	m_sDice.clear(); // Clear the dice list

	if(value < 4 && g_pGame->m_gameType == BASIC_HARDCORE)
		return;

	if(value == 1)
	{ // No need to track lists of '1' dice, so just return
	
		return;
	}


	// I need to check neighers for sinkers and as well as occupieds
	// They both work differently. Lets see how confusing I can make this...

	// clear gameboard flags
	for(i = 0; i < g_pGame->m_boardSize; i++)
		for(j = 0; j < g_pGame->m_boardSize; j++)
			g_pGame->m_gameboard[i][j].flag = false;
	// Set our flag, so we're not checked again.
	g_pGame->m_gameboard[x][y].flag = true;

	for(i = 0; i < 4; i++)
	{
		nx = x; ny = y;
		switch(i)
		{
		case LEFT:
			nx=x-1;
			break;
		case RIGHT:
			nx=x+1;
			break;
		case UP:
			ny=y-1;
			break;
		case DOWN:
			ny=y+1;
			break;
		default:
			continue; // Something isnt right 
		}
		if(   nx <0 || nx >= g_pGame->m_boardSize
			||ny <0 || ny >= g_pGame->m_boardSize)
			continue; //this is a bad direction

		if(g_pGame->m_gameboard[nx][ny].state == SINKING && (g_pGame->m_gameboard[nx][ny].dieState/4)+1 == value && !g_pGame->m_gameboard[nx][ny].flag)
			numMatched+=CreateDiceListHelper(nx, ny, SINKING);
	}

	for(i = 0; i < 4; i++)
	{
		nx = x; ny = y;
		switch(i)
		{
		case LEFT:
			nx=x-1;
			break;
		case RIGHT:
			nx=x+1;
			break;
		case UP:
			ny=y-1;
			break;
		case DOWN:
			ny=y+1;
			break;
		default:
			continue; // Something isnt right 
		}
		if(   nx <0 || nx >= g_pGame->m_boardSize
			||ny <0 || ny >= g_pGame->m_boardSize)
			continue; //this is a bad direction

		if(g_pGame->m_gameboard[nx][ny].state == OCCUPIED && (g_pGame->m_gameboard[nx][ny].dieState/4)+1 == value && !g_pGame->m_gameboard[nx][ny].flag)
			numMatched+=CreateDiceListHelper(nx, ny, OCCUPIED);
	}

	

	if(numMatched > 0)
		m_sDice.insert((x<<8)+y); // Only add this die, if we found other dice
	
	return;
}

// Swiped from CDiceGames CreateSinkersHelper
// Help to create a list of matching dice
int AI::CreateDiceListHelper(int x, int y, GamePosState state)
{
	// The value of the die here
	int value = (g_pGame->m_gameboard[x][y].dieState / 4) + 1;
	int result = 1;
	int i,nx,ny;

	// return on bad position
	if(x < 0 || x >= g_pGame->m_boardSize || y < 0 || y >= g_pGame->m_boardSize)
		return 0;

	g_pGame->m_gameboard[x][y].flag = true;

	m_sDice.insert((x<<8)+y);
	
	for(i = 0; i < 4; i++)
	{
		nx = x; ny = y;
		switch(i)
		{
		case LEFT:
			nx=x-1;
			break;
		case RIGHT:
			nx=x+1;
			break;
		case UP:
			ny=y-1;
			break;
		case DOWN:
			ny=y+1;
			break;
		default:
			continue; // Something isnt right 
		}
		if(   nx <0 || nx >= g_pGame->m_boardSize
			||ny <0 || ny >= g_pGame->m_boardSize)
			continue; //this is a bad direction

		if(g_pGame->m_gameboard[nx][ny].state == state && (g_pGame->m_gameboard[nx][ny].dieState/4)+1 == value && !g_pGame->m_gameboard[nx][ny].flag)
			result+=CreateDiceListHelper(nx, ny, state);
	}

	return result;
}
