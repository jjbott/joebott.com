#pragma once

#include <set>
#include "DiceGame.h"

#define MAX_AI_PATH_LEN 20

enum AIState {NO_MATCHES,		 // AI doesnt have a match set up, so its moving 
                                 // to a good die to set up a match with
									// When entering this state (such as game start)
									// I need to find a rollable die near to me, with a 
									// good path leading from it.
									// I shouldnt be in this state for more than 1 cycle
									// So when leaving (hopefully immediately after finding
									// a good die with a good path leading from it), I need to 
									// add the path end to my die list, set up the path to
									// the movable die, and enter state "BUILDING_MOVING"

			  BUILDING_MOVING,   // The AI has a set of matching dice that its working on,
                                 // right now it is moving to grab a die to roll back
									// If I'm in this state, I have a path set up to a movable
									// die. So, I just traverse the path until its end.
									// Once path has finished, I select a patch that ends
									// with a die matching a position in my set. If this path 
									// exists, I switch to BUILDING_MATCHING. Otherwise,
									// I'll either build a new path to a new movable die
									// (staying in the BUILDING_MOVING state),
									// or pick a path from this die and reset my die list
									// to the new target (switching to BUILDING_MATCHING).
			  BUILDING_MATCHING, // The AI has a set of matching dice that its working on,
								 // right now it has a die that will add another potential 
								 // match
									// The AI is following a path to add a die to its set
									// of matching dice. If the path is empty, hopefully we
									// have a new die to add to the list. Then, we'll find
									// a new movable die to add to my set, create a path
									// to it, and enter the BUILDING_MOVING state.
									// If this die creates a match, now its on a set of sinkers
									// and needs to get off. So find a path to nearest 
									// OCCUPIED or RISING
			  MOVING_RISER,		 // The AI is on the ground, and moving towards a rising 
								 // die to climb on
									// The AI is following a path to a riser. Once 
									// finished, I need to enter the WAITING_RISER state
			  MOVING_SINKER,     // The AI is on a set of sinkers, and moving on a path 
			                     // to get off and onto OCCUPIEDs
									// The AI is on some sinkers, and needs to get off
									// NOW. So it has a path that it is following. Once it
									// finishes, enter the NO_MATCH state
			  WAITING_RISER,	 // The AI is on a riser, and is waiting for it to get 
			                     // high enough to roll or move onto an OCCUPIED from
									// The AI is basically stuck, waiting until it can
									// move favorably. Once it can, enter NO_MATCH state
			  WAITING_STUCK,	 // The AI is no available moves, so is waiting for 
			                     // something to open up
									// The AI is basically stuck, waiting until it can
									// move favorably. Once it can, enter NO_MATCH or
									// other suitable state if it still has a valid
									// die list
			  CRUSHED,			 // The AI is under a die, and needs to pick a suitable
			                     // direction to get out
									// If I'm in this state, move to an available exit.
									// If I'm no longer crushed, enter ON_GROUND.
									// Probably should try to be smart about which exit
									// is chosen, can make situation worse
			  ON_GROUND          // The AI is on the ground, and there are no risers available, so hes hangin out.
									// Who knows what the AI should be doing in this state,
									// beyond wait for risers to pop up
									// Theres also a chance a path will become available
									// by running up staggered sinkers, need to watch for
									// them. Also, should try to do useful things with
									// sliders, somehow...
};

class AI
{
public:
	AI(void);
	~AI(void);

	//for stat tracking
	int m_numDirRequests;   // How many times was GetDirection called?
	int m_numRandResponses; // How many times did we return a random direction from GetDirection?

	// The AI's state
	AIState m_state;
	// The queued up path an AI has decided to take
	Direction m_path[MAX_AI_PATH_LEN];

	int m_playerNum; // The AI's player number (corresponds to g_pGame->m_players[] index)

	int m_IQ; // How smart the player is: 0 is stupidest (random movement)
	          //                          higher is better

	int m_diceValue; // The value of the dice that we're working on. (1-6)
	set<int, less<int> > m_sDice; // The set of dice positions that we're working on
	                              // encoded as int = x<<8 + y

	set<int, less<int> > m_sPosList; // A list of positions, used by movement
	                                 // searches. Same encoding, I'm lazy.

	bool m_wantDump; // for debugging

	// Used in NO_MATCH state
	// This will finds a path to the closest rollable die that has 
	// good paths attached to it. "Good path" depends on m_diceValue and m_sDice.
	// If m_diceValue is 0, any closest path will work, otherwise we
	// want a path that ends with a die that has a path with a m_diceValue ending
	// and avoids messing up m_sDice positions
	void FindClosestRollerPath(int x, int y);
	void FindClosestRollerPathHelper(int x,int y,int dieState, Direction *oldPath, int Depth);			  

	int HasGoodPath(int x, int y); // Tests if a position has a good path leading from it
	                               // "Good" == makes a match we want without messing up dice
	void VerifyDiceSet(); // Makes sure our set of dice is still valid
	void FindPathFromSinker(int x, int y);
	void FindPathToRiser(int x, int y);

	void CreateDiceList(int x, int y); 
	int  CreateDiceListHelper(int x, int y, GamePosState state);

	// Workhorse, this gets called everytime the main loop needs input from the player
	Direction GetDirection();
};
