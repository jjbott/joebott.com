// Functions for creating a script from a running game
// I could probably put this into a class, but I dont think thats necessary really

#include <windows.h>
#include <vector>
#include "ScriptEvents.h"
#include "DiceGame.h" 
using namespace std;

// The global CDiceGame
extern CDiceGame *g_pGame;

vector<unsigned char> g_vFileBuffer; // The buffer for the file we'll create
                            // I'll fill this as the game runs, and dump it to a file at the end.


HRESULT WriteScript(char *filename)
{
	printf("Saving script...\n");
	if(g_vFileBuffer.size() == 0)
	{
		printf("Nothing to save\n");
		return S_OK;
	}
	FILE *outStream;
	outStream = fopen(filename, "wb");
	if(outStream == NULL)
	{
		printf("Failed to open file \"%s\" for writing\n",filename);
		return E_FAIL;
	}

	for(int i = 0; i < (int)g_vFileBuffer.size(); i++)
	{
		//printf("saving....\n");
		if(putc(g_vFileBuffer[i],outStream) == EOF)
		{
			printf("Writing to file failed: %i\n", GetLastError());
			fclose(outStream);
			return E_FAIL;
		}
	}

	fclose(outStream);

	g_vFileBuffer.clear();

	return S_OK;
}

HRESULT AddInitInfo()
{
	g_vFileBuffer.push_back((unsigned char)g_pGame->m_gameType);
	g_vFileBuffer.push_back((unsigned char)g_pGame->m_boardSize);
	g_vFileBuffer.push_back((unsigned char)g_pGame->m_numPlayers);

	for(int i = 0; i < g_pGame->m_boardSize; i++)
		for(int j = 0; j < g_pGame->m_boardSize; j++)
		{
			if(g_pGame->m_gameboard[i][j].state == FREE)
				g_vFileBuffer.push_back((unsigned char)0xF0); // Use 0xf0 for free spots I guess. Good enough
			else
				g_vFileBuffer.push_back((unsigned char)g_pGame->m_gameboard[i][j].dieState);
		}
	
	g_vFileBuffer.push_back(EVENT_DELIMITER); // End of init info

	return S_OK;
}

HRESULT AddRiserEvent(DWORD dwTime, int x, int y, int mode)
{
	// Push event type
	g_vFileBuffer.push_back((unsigned char)NEW_RISER);

	// push event time
	g_vFileBuffer.push_back((unsigned char)dwTime&0xFF);
	g_vFileBuffer.push_back((unsigned char)((dwTime&0xFF00) >> 8));
	g_vFileBuffer.push_back((unsigned char)((dwTime&0xFF0000) >> 16));
	g_vFileBuffer.push_back((unsigned char)((dwTime&0xFF000000) >> 24));

	// Push the x,y values of the riser
	// They'll never be even near 255, so a char is fine
	g_vFileBuffer.push_back((unsigned char) x);
	g_vFileBuffer.push_back((unsigned char) y);

	// Push the die's mode (range of 0-23)
	g_vFileBuffer.push_back((unsigned char) mode);
	
	// Push "Event End"
	g_vFileBuffer.push_back(EVENT_DELIMITER);

	return S_OK;

}

HRESULT AddInputUpdateEvent(DWORD dwTime, Player *players, int numPlayers)
{
	// Push event type
	g_vFileBuffer.push_back((unsigned char)INPUT_UPDATE);

	// push event time
	g_vFileBuffer.push_back((unsigned char)dwTime&0xFF);
	g_vFileBuffer.push_back((unsigned char)((dwTime&0xFF00) >> 8));
	g_vFileBuffer.push_back((unsigned char)((dwTime&0xFF0000) >> 16));
	g_vFileBuffer.push_back((unsigned char)((dwTime&0xFF000000) >> 24));

	for(int i = 0; i < numPlayers; i++)
	{
		g_vFileBuffer.push_back((unsigned char) players[i].dir);
	}
	
	// Push "Event End"
	g_vFileBuffer.push_back(EVENT_DELIMITER);

	return S_OK;

}