#pragma once

HRESULT WriteScript(char *filename);

HRESULT AddInitInfo();

HRESULT AddRiserEvent(DWORD dwTime, int x, int y, int mode);

HRESULT AddInputUpdateEvent(DWORD dwTime, Player *players, int numPlayers);