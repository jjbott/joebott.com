// Function to convert a DI keycode to a string
// So big, it gets its own file!

// Most of these, I'll never use. But I left them just in case.
// I might want to use this function again someday, might as well do all the keys!

#include <dinput.h>

// Define this to omit non-standard keys. Dont need that crud bulking up my program
#define BASIC_KEYS

char* DIKtoStr(unsigned char keycode)
{
	switch(keycode)
	{
	case DIK_ESCAPE://          0x01
		return "Escape";
	case DIK_1://               0x02
		return "1";
	case DIK_2://               0x03
		return "2";
	case DIK_3://               0x04
		return "3";
	case DIK_4://                0x05
		return "4";
	case DIK_5://                0x06
		return "5";
	case DIK_6://                0x07
		return "6";
	case DIK_7://                0x08
		return "7";
	case DIK_8://                0x09
		return "8";
	case DIK_9://               0x0A
		return "9";
	case DIK_0://                0x0B
		return "0";
	case DIK_MINUS://            0x0C    /* - on main keyboard */
		return "-";
	case DIK_EQUALS://           0x0D
		return "=";
	case DIK_BACK://             0x0E    /* backspace */
		return "Backspace";
	case DIK_TAB://              0x0F
		return "Tab";
	case DIK_Q://                0x10
		return "Q";
	case DIK_W://                0x11
		return "W";
	case DIK_E://                0x12
		return "E";
	case DIK_R://                0x13
		return "R";
	case DIK_T://                0x14
		return "T";
	case DIK_Y://                0x15
		return "Y";
	case DIK_U://                0x16
		return "U";
	case DIK_I://                0x17
		return "I";
	case DIK_O://                0x18
		return "O";
	case DIK_P://                0x19
		return "P";
	case DIK_LBRACKET://         0x1A
		return "[";
	case DIK_RBRACKET://         0x1B
		return "]";
	case DIK_RETURN://           0x1C    /* Enter on main keyboard */
		return "Enter";
	case DIK_LCONTROL://         0x1D
		return "Left Control";
	case DIK_A://                0x1E
		return "A";
	case DIK_S://                0x1F
		return "S";
	case DIK_D://                0x20
		return "D";
	case DIK_F://                0x21
		return "F";
	case DIK_G://                0x22
		return "G";
	case DIK_H://                0x23
		return "H";
	case DIK_J://                0x24
		return "J";
	case DIK_K://                0x25
		return "K";
	case DIK_L://                0x26
		return "L";
	case DIK_SEMICOLON://        0x27
		return ";";
	case DIK_APOSTROPHE://       0x28
		return "'";
	case DIK_GRAVE://            0x29    /* accent grave */
		return "`"; // I think
	case DIK_LSHIFT://          0x2A
		return "Left Shift";
	case DIK_BACKSLASH://        0x2B
		return "\\";
	case DIK_Z://                0x2C
		return "Z";
	case DIK_X://                0x2D
		return "X";
	case DIK_C://                0x2E
		return "C";
	case DIK_V://                0x2F
		return "V";
	case DIK_B://                0x30
		return "B";
	case DIK_N://                0x31
		return "N";
	case DIK_M://                0x32
		return "M";
	case DIK_COMMA://           0x33
		return ",";
	case DIK_PERIOD://          0x34    /* . on main keyboard */
		return ".";
	case DIK_SLASH://           0x35    /* / on main keyboard */
		return "/";
	case DIK_RSHIFT://           0x36
		return "Right Shift";
	case DIK_MULTIPLY://         0x37    /* * on numeric keypad */
		return "Numpad *";
	case DIK_LMENU://            0x38    /* left Alt */
		return "Left Alt";
	case DIK_SPACE://            0x39
		return "Space";
	case DIK_CAPITAL://          0x3A
		return "Caps Lock";
	case DIK_F1://               0x3B
		return "F1";
	case DIK_F2://               0x3C
		return "F2";
	case DIK_F3://               0x3D
		return "F3";
	case DIK_F4://               0x3E
		return "F4";
	case DIK_F5://               0x3F
		return "F5";
	case DIK_F6://               0x40
		return "F6";
	case DIK_F7://               0x41
		return "F7";
	case DIK_F8://               0x42
		return "F8";
	case DIK_F9://               0x43
		return "F9";
	case DIK_F10://              0x44
		return "F10";
	case DIK_NUMLOCK://          0x45
		return "Num Lock";
	case DIK_SCROLL://           0x46    /* Scroll Lock */
		return "Scroll Lock";
	case DIK_NUMPAD7://          0x47
		return "Numpad 7";
	case DIK_NUMPAD8://          0x48
		return "Numpad 8";
	case DIK_NUMPAD9://          0x49
		return "Numpad 9";
	case DIK_SUBTRACT://         0x4A    /* - on numeric keypad */
		return "Numpad -";
	case DIK_NUMPAD4://          0x4B
		return "Numpad 4";
	case DIK_NUMPAD5://          0x4C
		return "Numpad 5";
	case DIK_NUMPAD6://          0x4D
		return "Numpad 6";
	case DIK_ADD://              0x4E    /* + on numeric keypad */
		return "Numpad +";
	case DIK_NUMPAD1://          0x4F
		return "Numpad 1";
	case DIK_NUMPAD2://          0x50
		return "Numpad 2";
	case DIK_NUMPAD3://          0x51
		return "Numpad 3";
	case DIK_NUMPAD0://          0x52
		return "Numpad 0";
	case DIK_DECIMAL://          0x53    /* . on numeric keypad */
		return "Numpad .";

#ifndef BASIC_KEYS
	case DIK_OEM_102://          0x56    /* <> or \| on RT 102-key keyboard (Non-U.S.) */
		return "???";
#endif

	case DIK_F11://              0x57
		return "F11";
	case DIK_F12://              0x58
		return "F12";

#ifndef BASIC_KEYS
	case DIK_F13://              0x64    /*                     (NEC PC98) */
		return "F13";
	case DIK_F14://              0x65    /*                     (NEC PC98) */
		return "F14";
	case DIK_F15://              0x66    /*                     (NEC PC98) */
		return "F15";
	case DIK_KANA://             0x70    /* (Japanese keyboard)            */
		return "Kana";
	case DIK_ABNT_C1://          0x73    /* /? on Brazilian keyboard */
		return "???";
	case DIK_CONVERT://          0x79    /* (Japanese keyboard)            */
		return "Convert";
	case DIK_NOCONVERT://        0x7B    /* (Japanese keyboard)            */
		return "No Convert";
	case DIK_YEN://              0x7D    /* (Japanese keyboard)            */
		return "Yen";
	case DIK_ABNT_C2://          0x7E    /* Numpad . on Brazilian keyboard */
		return "Numpad .";
	case DIK_NUMPADEQUALS://     0x8D    /* = on numeric keypad (NEC PC98) */
		return "Numpad =";
	case DIK_PREVTRACK://        0x90    /* Previous Track (DIK_CIRCUMFLEX on Japanese keyboard) */
		return "Previous Track";
	case DIK_AT://               0x91    /*                     (NEC PC98) */
		return "@";
	case DIK_COLON://            0x92    /*                     (NEC PC98) */
		return ":";
	case DIK_UNDERLINE://        0x93    /*                     (NEC PC98) */
		return "_";
	case DIK_KANJI://            0x94    /* (Japanese keyboard)            */
		return "Kanji";
	case DIK_STOP://             0x95    /*                     (NEC PC98) */
		return "Stop";
	case DIK_AX://               0x96    /*                     (Japan AX) */
		return "???";
	case DIK_UNLABELED://        0x97    /*                        (J3100) */
		return "???";
	case DIK_NEXTTRACK://        0x99    /* Next Track */
		return "Next Track";
#endif

	case DIK_NUMPADENTER://      0x9C    /* Enter on numeric keypad */
		return "Numpad Enter";
	case DIK_RCONTROL://         0x9D
		return "Right Control";

#ifndef BASIC_KEYS
	case DIK_MUTE://             0xA0    /* Mute */
		return "Mute";
	case DIK_CALCULATOR://       0xA1    /* Calculator */
		return "Calculator";
	case DIK_PLAYPAUSE://        0xA2    /* Play / Pause */
		return "Play/Pause";
	case DIK_MEDIASTOP://        0xA4    /* Media Stop */
		return "Stop";
	case DIK_VOLUMEDOWN://       0xAE    /* Volume - */
		return "Volume Down";
	case DIK_VOLUMEUP://         0xB0    /* Volume + */
		return "Volume Up";
	case DIK_WEBHOME://         0xB2    /* Web home */
		return "Web Home";
	case DIK_NUMPADCOMMA://      0xB3    /* , on numeric keypad (NEC PC98) */
		return "Numpad ,";
#endif

	case DIK_DIVIDE://           0xB5    /* / on numeric keypad */
		return "Numpad /";

#ifndef BASIC_KEYS
	case DIK_SYSRQ://            0xB7
		return "????";
#endif

	case DIK_RMENU://            0xB8    /* right Alt */
		return "Right Alt";
	case DIK_PAUSE://            0xC5    /* Pause */
		return "Pause";
	case DIK_HOME ://            0xC7    /* Home on arrow keypad */
		return "Home";
	case DIK_UP://               0xC8    /* UpArrow on arrow keypad */
		return "Up Arrow";
	case DIK_PRIOR://            0xC9    /* PgUp on arrow keypad */
		return "PgUp";
	case DIK_LEFT://             0xCB    /* LeftArrow on arrow keypad */
		return "Left Arrow";
	case DIK_RIGHT://            0xCD    /* RightArrow on arrow keypad */
		return "Right Arrow";
	case DIK_END://              0xCF    /* End on arrow keypad */
		return "End";
	case DIK_DOWN://             0xD0    /* DownArrow on arrow keypad */
		return "Down Arrow";
	case DIK_NEXT://             0xD1    /* PgDn on arrow keypad */
		return "PgDn";
	case DIK_INSERT://           0xD2    /* Insert on arrow keypad */
		return "Insert";
	case DIK_DELETE://           0xD3    /* Delete on arrow keypad */
		return "Delete";
	case DIK_LWIN://             0xDB    /* Left Windows key */
		return "Left Windows";
	case DIK_RWIN://             0xDC    /* Right Windows key */
		return "Right Windows";
	case DIK_APPS ://            0xDD    /* AppMenu key */
		return "Menu";//??

#ifndef BASIC_KEYS
	case DIK_POWER://            0xDE    /* System Power */
		return "Power";
	case DIK_SLEEP://            0xDF    /* System Sleep */
		return "Sleep";
	case DIK_WAKE://             0xE3    /* System Wake */
		return "Wake";
	case DIK_WEBSEARCH://        0xE5    /* Web Search */
		return "Search";
	case DIK_WEBFAVORITES://     0xE6    /* Web Favorites */
		return "Favorites";
	case DIK_WEBREFRESH://       0xE7    /* Web Refresh */
		return "Refresh";
	case DIK_WEBSTOP://          0xE8    /* Web Stop */
		return "Stop";
	case DIK_WEBFORWARD://       0xE9    /* Web Forward */
		return "Forward";
	case DIK_WEBBACK://          0xEA    /* Web Back */
		return "Back";
	case DIK_MYCOMPUTER://       0xEB    /* My Computer */
		return "My Computer";
	case DIK_MAIL://             0xEC    /* Mail */
		return "Mail";
	case DIK_MEDIASELECT://      0xED    /* Media Select */
		return "Media Select";
#endif
	}

	return "???";
}