#include "dicegame.h"
#include <windows.h>
#include <malloc.h>
#include <time.h>
#include "CreateScript.h"
#include "RunScript.h"

#include "Input.h" // FIXME: Get this out of here!


CDiceGame::CDiceGame(int gameType, int boardSize, int numPlayers)
{
	Init(gameType, boardSize, numPlayers);
}

// Assignment operator
// Not a perfect assignment operator - I'm dropping some stuff for speed.
// "this" must be completely initialized, and have the same gameboard size
// and number of players as "right"
// FIXME! Because this will be used by the brain thread, I should probably
// create some mutexes so I dont get weird data
const CDiceGame &CDiceGame::operator=(const CDiceGame &right) 
{
	int i,j;

	WaitForSingleObject(m_hMutex, INFINITE);
	//printf("%i %i %i %i\n", right.m_boardSize, right.m_numPlayers, right.dwTime, right.m_numSunk);

	if(&right != this && this != NULL && &right!=NULL)
	{
		
		// Free the old board's memory

		// Removed - we're now keeping the old memory spaces, because
		// the gameboard size and number of players should be the same
		// anyways. If theyre not, too bad, crashity crash!
		/*
		if(m_gameboard != NULL)
		{
			for(i = 0; i < m_boardSize; i++)
			{
				printf("i: %i\n", i);
				free(m_gameboard[i]);
			}
			free(m_gameboard);
		}
		
		if(m_players != NULL)
			free(m_players);

		if(m_oldDirections != NULL)
			free(m_oldDirections);
		*/

		m_vEvents.clear();
		m_vTempEvents.clear();
		m_vPosList.clear();

		// Re-init the board
		// Removed, the board should be initialized already
		//Init(right.m_gameType, right.m_boardSize, right.m_numPlayers);

		m_numSunk = right.m_numSunk;  
		m_level = right.m_level;
		gameover = right.gameover;

		m_runningScript = right.m_runningScript;
		m_recordingScript = right.m_recordingScript;

		m_gameType = right.m_gameType;
		m_boardSize = right.m_boardSize;
		m_numPlayers = right.m_numPlayers;
		dwTime = right.dwTime;
		m_numUpdates = right.m_numUpdates;

		for(i = 0; i < m_boardSize; i++)
			for(j = 0; j < m_boardSize; j++)
			{
				m_gameboard[i][j] = right.m_gameboard[i][j];
			}

		for(i = 0; i < m_numPlayers; i++)
		{
			m_players[i] = right.m_players[i];
		}

		for(i = 0; i < m_numPlayers; i++)
		{
			m_oldDirections[i] = right.m_oldDirections[i]; 
		}
		
		
		for(i = 0; i < (int)right.m_vEvents.size(); i++)
		{
			m_vEvents.push_back(right.m_vEvents[i]);
		}

		
		for(i = 0; i < (int)right.m_vTempEvents.size(); i++)
		{
			m_vTempEvents.push_back(right.m_vTempEvents[i]);
		}
		
		for(i = 0; i < (int)right.m_vPosList.size(); i++)
		{
			m_vPosList.push_back(right.m_vPosList[i]);
		}

	}

	ReleaseMutex(m_hMutex);
	return *this;
}

void CDiceGame::Init(int gameType, int boardSize, int numPlayers)
{
	int i,j,k;
	Event temp;
	
	printf("entering Init()\n");

	// Create the Class' Mutex
	m_hMutex = CreateMutex(NULL, true, NULL);

	//WaitForSingleObject(m_hMutex, INFINITE);
	
	// Create first
	temp.what = CHECK_FREE_SPACES;
	temp.when = TIME_BTW_FREE_CHECK;
	m_vEvents.push_back(temp);

	// Default to not recording or running a script.
	// The main program will have to change these before calling gameloop
	// if we dont want to play a standard game
	m_runningScript = false;
	m_recordingScript = false;

	gameover = false;
	srand((unsigned int)time(0));

	m_gameType = gameType;
	m_boardSize = boardSize;
	m_numPlayers = numPlayers;
	m_level = 1;
	m_numSunk = 0;


	// Create board
	m_gameboard = (GamePos **)malloc(boardSize * sizeof(GamePos*));
	for(i = 0; i < boardSize; i++)
	{
		m_gameboard[i] = (GamePos *)malloc(boardSize * sizeof(GamePos));
	}

	// Init board
	// *This makes an empty board...
	/*
	for(i = 0; i < boardSize; i++)
		for(j = 0; j < boardSize; j++)
		{
			m_gameboard[i][j].state = FREE;
			m_gameboard[i][j].dieState = 0;
			m_gameboard[i][j].flag = false;
			for(k = 0; k < 5; k++)
				m_gameboard[i][j].unmovable[k] = false;
		}
		*/

	// Was for making a script...
	/*
	m_gameboard[1][1].state = OCCUPIED;
	m_gameboard[1][1].dieState = 5;
	m_gameboard[1][1].flag = false;
	m_gameboard[1][5].state = OCCUPIED;
	m_gameboard[1][5].dieState = 7;
	m_gameboard[1][5].flag = false;
	m_gameboard[2][5].state = OCCUPIED;
	m_gameboard[2][5].dieState = 8;
	m_gameboard[2][5].flag = false;
	m_gameboard[6][5].state = OCCUPIED;
	m_gameboard[6][5].dieState = 9;
	m_gameboard[6][5].flag = false;
	m_gameboard[6][4].state = OCCUPIED;
	m_gameboard[6][4].dieState = 10;
	m_gameboard[6][4].flag = false;
	m_gameboard[5][4].state = OCCUPIED;
	m_gameboard[5][4].dieState = 12;
	m_gameboard[5][4].flag = false;
	m_gameboard[6][2].state = OCCUPIED;
	m_gameboard[6][2].dieState = 15;
	m_gameboard[6][2].flag = false;
	m_gameboard[6][1].state = OCCUPIED;
	m_gameboard[6][1].dieState = 13;
	m_gameboard[6][1].flag = false;
	m_gameboard[6][0].state = OCCUPIED;
	m_gameboard[6][0].dieState = 14;
	m_gameboard[6][0].flag = false;
	m_gameboard[5][2].state = OCCUPIED;
	m_gameboard[5][2].dieState = 16;
	m_gameboard[5][2].flag = false;
	m_gameboard[0][0].state = OCCUPIED;
	m_gameboard[0][0].dieState = 17;
	m_gameboard[0][0].flag = false;
	m_gameboard[1][0].state = OCCUPIED;
	m_gameboard[1][0].dieState = 16;
	m_gameboard[1][0].flag = false;
	m_gameboard[2][0].state = OCCUPIED;
	m_gameboard[2][0].dieState = 18;
	m_gameboard[2][0].flag = false;
	m_gameboard[3][0].state = OCCUPIED;
	m_gameboard[3][0].dieState = 19;
	m_gameboard[3][0].flag = false;
	*/


	
	for(i = 0; i < boardSize; i++)
		for(j = 0; j < boardSize; j++)
		{
			// Make half the spaces occupied, to start
			if(rand()%2 == 1)
			{
				m_gameboard[i][j].state = FREE;
				m_gameboard[i][j].y = 0.0f;
			}
			else
			{
				m_gameboard[i][j].state = OCCUPIED;
				m_gameboard[i][j].y = 1.0f;
			}
			m_gameboard[i][j].dieState = rand()%24;
			m_gameboard[i][j].flag = false;
			for(k = 0; k < 5; k++)
				m_gameboard[i][j].unmovable[k] = false;
		}

	// Create Player array
	m_players = (Player *)malloc(numPlayers * sizeof(Player));
	// Create Old Direction array
	m_oldDirections = (Direction *)malloc(numPlayers * sizeof(Direction));

	//Init PLayers
	for(i = 0; i < numPlayers; i++)//Oh my. Dont put a ';' here, idiot. That only took me 2 days to find...
	{
		m_players[i].boardX = 0;
		m_players[i].boardY = 0;
		m_players[i].score = 0;
		m_players[i].health = 0;
		m_oldDirections[i] = m_players[i].dir = NONE;
		m_players[i].facing = UP;
		m_players[i].idle = true;
		m_players[i].smashed = false;
		m_players[i].AI = false;

		//if(i != 1) // temp debugging thingy
		//{
			// TODO: Make offsets make sense, not random.
			m_players[i].offsetX = ((rand()%100)/100.0f)*.25f-.125f;
			//m_players[i].offsetY = 50.0f/(float)(rand()%100);
			m_players[i].offsetZ = ((rand()%100)/100.0f)*.25f-.125f;
		//}
		//else
		//{
		//	m_players[i].offsetX = 0;
			//m_players[i].offsetY = 50.0f/(float)(rand()%100);
		//	m_players[i].offsetZ = 0;
		//}


		//printf("offset for player %i: %f, %f\n", i, m_players[i].offsetX, m_players[i].offsetZ);
	}

	if(numPlayers > 0) // And it better be!
	{
		if(m_boardSize > 0) // And it better be!
		{
			m_players[0].boardX = 1;
			m_players[0].boardY = 1;
			m_gameboard[1][1].state = OCCUPIED;
			m_players[0].diecolor = 0xFFFF7070;
			m_players[0].color = 0xFFFF2020;
		}
	}

	if(numPlayers > 1)
	{
		if(m_boardSize > 0) // And it better be!
		{
			m_players[1].boardX = m_boardSize-2;
			m_players[1].boardY = m_boardSize-2;
			m_gameboard[m_boardSize-2][m_boardSize-2].state = OCCUPIED;
			m_players[1].diecolor = 0xFF7070FF;
			m_players[1].color = 0xFF2020FF;
		}
	}

	if(numPlayers > 2)
	{
		if(m_boardSize > 0) // And it better be!
		{
			m_players[2].boardX = 1;
			m_players[2].boardY = m_boardSize-2;
			m_gameboard[1][m_boardSize-2].state = OCCUPIED;
			m_players[2].diecolor = 0xFF70FF70;
			m_players[2].color = 0xFF20FF20;
		}
	}

	if(numPlayers > 3)
	{
		if(m_boardSize > 0) // And it better be!
		{
			m_players[3].boardX = m_boardSize-2;
			m_players[3].boardY = 1;
			m_gameboard[m_boardSize-2][1].state = OCCUPIED;
			m_players[3].diecolor = 0xFFFFFF70;
			m_players[3].color = 0xFFFFFF20;
		}
	}
	if(numPlayers > 4)
	{
		if(m_boardSize > 0) // And it better be!
		{
			m_players[4].boardX = m_boardSize/2;
			m_players[4].boardY = m_boardSize/2;
			m_gameboard[m_boardSize/2][m_boardSize/2].state = OCCUPIED;
			m_players[4].diecolor = 0xFF70FFFF;
			m_players[4].color = 0xFF20FFFF;
		}
	}

	//Init Time
	dwTime = 0;
	m_numUpdates = 0;

	// Set up transition table for rolls
	//If I roll a "12" die in the "UP" direction, it will turn into a m_transTable[12][up] die
	// 0 = up, 1 = right, 2 = down, 3 = left
	m_transTable[0][UP] = 14; m_transTable[0][RIGHT] = 16; m_transTable[0][DOWN] = 8; m_transTable[0][LEFT] = 4;
	m_transTable[1][UP] = 5; m_transTable[1][RIGHT] = 15; m_transTable[1][DOWN] = 17; m_transTable[1][LEFT] = 9;
	m_transTable[2][UP] = 10; m_transTable[2][RIGHT] = 6; m_transTable[2][DOWN] = 12; m_transTable[2][LEFT] = 18;
	m_transTable[3][UP] = 19; m_transTable[3][RIGHT] = 11; m_transTable[3][DOWN] = 7; m_transTable[3][LEFT] = 13;
	m_transTable[4][UP] = 13; m_transTable[4][RIGHT] = 0; m_transTable[4][DOWN] = 9; m_transTable[4][LEFT] = 20;
	m_transTable[5][UP] = 21; m_transTable[5][RIGHT] = 14; m_transTable[5][DOWN] = 1; m_transTable[5][LEFT] = 10;
	m_transTable[6][UP] = 11; m_transTable[6][RIGHT] = 22; m_transTable[6][DOWN] = 15; m_transTable[6][LEFT] = 2;
	m_transTable[7][UP] = 3; m_transTable[7][RIGHT] = 8; m_transTable[7][DOWN] = 23; m_transTable[7][LEFT] = 12;
	m_transTable[8][UP] = 0; m_transTable[8][RIGHT] = 17; m_transTable[8][DOWN] = 22; m_transTable[8][LEFT] = 7;
	m_transTable[9][UP] = 4; m_transTable[9][RIGHT] = 1; m_transTable[9][DOWN] = 18; m_transTable[9][LEFT] = 23;
	m_transTable[10][UP] = 20; m_transTable[10][RIGHT] = 5; m_transTable[10][DOWN] = 2; m_transTable[10][LEFT] = 19;
	m_transTable[11][UP] = 16; m_transTable[11][RIGHT] = 21; m_transTable[11][DOWN] = 6; m_transTable[11][LEFT] = 3;
	m_transTable[12][UP] = 2; m_transTable[12][RIGHT] = 7; m_transTable[12][DOWN] = 20; m_transTable[12][LEFT] = 17;
	m_transTable[13][UP] = 18; m_transTable[13][RIGHT] = 3; m_transTable[13][DOWN] = 4; m_transTable[13][LEFT] = 21;
	m_transTable[14][UP] = 22; m_transTable[14][RIGHT] = 19; m_transTable[14][DOWN] = 0; m_transTable[14][LEFT] = 5;
	m_transTable[15][UP] = 6; m_transTable[15][RIGHT] = 23; m_transTable[15][DOWN] = 16; m_transTable[15][LEFT] = 1;
	m_transTable[16][UP] = 15; m_transTable[16][RIGHT] = 20; m_transTable[16][DOWN] = 11; m_transTable[16][LEFT] = 0;
	m_transTable[17][UP] = 1; m_transTable[17][RIGHT] = 12; m_transTable[17][DOWN] = 21; m_transTable[17][LEFT] = 8;
	m_transTable[18][UP] = 9; m_transTable[18][RIGHT] = 2; m_transTable[18][DOWN] = 13; m_transTable[18][LEFT] = 22;
	m_transTable[19][UP] = 23; m_transTable[19][RIGHT] = 10; m_transTable[19][DOWN] = 3; m_transTable[19][LEFT] = 14;
	m_transTable[20][UP] = 12; m_transTable[20][RIGHT] = 4; m_transTable[20][DOWN] = 10; m_transTable[20][LEFT] = 16;
	m_transTable[21][UP] = 17; m_transTable[21][RIGHT] = 13; m_transTable[21][DOWN] = 5; m_transTable[21][LEFT] = 11;
	m_transTable[22][UP] = 8; m_transTable[22][RIGHT] = 18; m_transTable[22][DOWN] = 14; m_transTable[22][LEFT] = 6;
	m_transTable[23][UP] = 7; m_transTable[23][RIGHT] = 9; m_transTable[23][DOWN] = 19; m_transTable[23][LEFT] = 15;

	printf("leaving init()\n");
	ReleaseMutex(m_hMutex);
}

CDiceGame::~CDiceGame(void)
{
	WaitForSingleObject(m_hMutex, INFINITE);
	//int i;
	if(m_gameboard == NULL)
		return;

	// Free the board's memory
	for(int i = 0; i < m_boardSize; i++)
		free(m_gameboard[i]);
	free(m_gameboard);

	free(m_players);

	free(m_oldDirections);

	ReleaseMutex(m_hMutex);
	CloseHandle(m_hMutex);

}

bool CDiceGame::IsMovable(int x, int y)
{
	if( x < 0 || x >= m_boardSize || y < 0 || y >= m_boardSize)
		return false; //position isnt even valid!

	for(int i = 0; i < 5; i++)
	{
		if(m_gameboard[x][y].unmovable[i])
			return false;
	}

	return true;

}


// Given a player number, this function returns what directions are valid for movement
//	(returnvalue) & 1<<UP == up is valid
//  (returnvalue) & 1<<DOWN == DOWN is valid
//  (ret... ah, you get it...
// Maybe change it so only the direction the player wants to move is checked... Hmm. Yeah.
bool CDiceGame::IsMovementValid(int playerNum, Direction dir)
{
	//printf("ping2!\n");
	
	int x = m_players[playerNum].boardX,
		y = m_players[playerNum].boardY;
	int nx,ny,nnx,nny; // next x, next next x, you get it. :P
	GamePosState s, ns;//, nns;

	// Compute next and nextnext position
	switch(dir)
	{
	case LEFT:
		nny=ny=y;
		nx=x-1;
		nnx=x-2;
		break;
	case RIGHT:
		nny=ny=y;
		nx=x+1;
		nnx=x+2;
		break;
	case UP:
		nnx=nx=x;
		ny=y-1;
		nny=y-2;
		break;
	case DOWN:
		nnx=nx=x;
		ny=y+1;
		nny=y+2;
		break;
	default:
		return false; // dir must be invalid
	}

	s = m_gameboard[x][y].state;
	if( nx < 0 || nx >= m_boardSize || ny < 0 || ny >= m_boardSize)
		return false;
	else
		ns = m_gameboard[nx][ny].state;

	// Test: Sinkers and Risers may == Occupieds or Frees, when determining movement
	// depending on Y value
	if(s == SINKING || s == RISING)
	{
		if(m_gameboard[x][y].y <= .5)
			s = FREE;
		else
			s = OCCUPIED;
	}
	if(ns == SINKING || ns == RISING)
	{
		if(m_gameboard[nx][ny].y <= .5)
			ns = FREE;
		else
			ns = OCCUPIED;
	}

	// treat smashed players like they're on a free spot
	if(m_players[playerNum].smashed)
		s = FREE;

	// Is this space occupied?
	// Then any move is possible, as long as:
	//		it doesnt go off the gameboard
	//      the space we move to is either occupied or free.
	//TODO: Add rising/sinking states (can climb down onto them (maybe))
	if(m_gameboard[x][y].state == SINKING || m_gameboard[x][y].state == RISING)
	{

		//if((m_gameboard[nx][ny].state == FREE && m_gameboard[x][y].y <= MAX_Y_VARIANCE) ||
		//   (m_gameboard[nx][ny].state == OCCUPIED && m_gameboard[x][y].y >= 1.0-MAX_Y_VARIANCE))
		//{
		//	printf("I'll never get here. Right?\n");
		//	return true;
		//}
		if(m_gameboard[nx][ny].state == SINKING || m_gameboard[nx][ny].state == RISING)
		{  
			// Instead of doing a floating point ABS, I'm doing extra compares
			// That doesnt seem so effecient.
			if(m_gameboard[x][y].y >= m_gameboard[nx][ny].y
				&& (m_gameboard[x][y].y-m_gameboard[nx][ny].y) <= MAX_Y_VARIANCE)
				return true;
			if(m_gameboard[nx][ny].y >= m_gameboard[x][y].y
				&& (m_gameboard[nx][ny].y-m_gameboard[x][y].y) <= MAX_Y_VARIANCE)
				return true;
		}
	}
	
	if(s == OCCUPIED) //if(m_gameboard[x][y].state == OCCUPIED)
	{

		//if(m_gameboard[nx][ny].state == FREE || 
		//   m_gameboard[nx][ny].state == OCCUPIED ||
		//   (m_gameboard[nx][ny].state == SINKING && m_gameboard[nx][ny].y >= 1.0-MAX_Y_VARIANCE) ||
		//   (m_gameboard[nx][ny].state == RISING && m_gameboard[nx][ny].y >= 1.0-MAX_Y_VARIANCE))
		
		// hmm. sinker->sinker == okay
		//      occupied->sinker == bad

		// what a mess. This is occupied, next is sinking, and next is not crushable (ns == OCCUPIED)
		if(m_gameboard[x][y].state == OCCUPIED&& m_gameboard[nx][ny].state == SINKING && ns == OCCUPIED)
			return false; // take care of occupied->sinker case

		if(ns == OCCUPIED)// if(ns == FREE || ns == OCCUPIED)		
			return true;

		// Still have to use original state, so we dont jump off high sinkers/rollers

		if(ns == FREE && !(m_gameboard[x][y].state == SINKING || m_gameboard[x][y].state == RISING)&& IsMovable(x,y) && IsMovable(nx,ny))
			return true;

	
	
	}
	// Is this space free? 
	// Then things are a little more tricky. If our neighbors are free
	// then we can move anywhere. If a neighbor is occupied, then we can
	// only move that direction if the next space over is free (for sliding)
	//TODO: Add rising/sinking states (can climb up them, maybe)
	else if(s == FREE) //else if(m_gameboard[x][y].state == FREE)
	{
		//printf("ping4! %i %i\n", nx, ny);
	
		//printf("ping5!\n");
		//if(m_gameboard[nx][ny].state == FREE ||
		//   (m_gameboard[nx][ny].state == SINKING && m_gameboard[nx][ny].y <= MAX_Y_VARIANCE) ||
		//   (m_gameboard[nx][ny].state == RISING && m_gameboard[nx][ny].y <= MAX_Y_VARIANCE))
		if(ns == FREE)		
			return true;
		// For these, we use the true state, no fake sinker/riser states
		// Otherwise we'll be pushing risers onto sinkers and such. No good.
		else if ((m_gameboard[x][y].state == FREE || m_players[playerNum].smashed) && m_gameboard[nx][ny].state == OCCUPIED &&
				 nnx >= 0 && nnx < m_boardSize && nny >= 0 && nny < m_boardSize)
		{
			if(m_gameboard[nnx][nny].state == FREE && IsMovable(nx,ny)) // if target is free, and block is movable, we're good
				return true;
		}
		
	}
	
	
	
	return false;

	
}

void CDiceGame::MovePlayer(int playerNum)//, Direction dir)
{
	Direction dir = m_players[playerNum].dir;
	Event temp;
	int x = m_players[playerNum].boardX,
		y = m_players[playerNum].boardY;
	int nx,ny,nnx,nny; // next x, next next x, you get it. :P
	int nnnx, nnny; // Next next next X/Y. Only used for players on the ground being shoved by a slider
	int i;
	bool shovable; // Flag that will be set if, when sliding a die, it
				   // is possible to shove a player on the other side of the die
				   // ie: nnnx/nnny is valid and free
	GamePosState s, ns;
	GamePosState tempState;

	if(dir == NONE)
		return; // nothing to do
	if(dir > 4)
		return; // Invalid direction

	// Compute next and nextnext position
	switch(dir)
	{
	case LEFT:
		nnny=nny=ny=y;
		nx=x-1;
		nnx=x-2;
		nnnx=x-3;
		break;
	case RIGHT:
		nnny=nny=ny=y;
		nx=x+1;
		nnx=x+2;
		nnnx=x+3;
		break;
	case UP:
		nnnx=nnx=nx=x;
		ny=y-1;
		nny=y-2;
		nnny=y-3;
		break;
	case DOWN:
		nnnx=nnx=nx=x;
		ny=y+1;
		nny=y+2;
		nnny=y+3;
		break;
	}
	

	if(!m_players[playerNum].idle)
		return;
	if(dir == NONE)
		return;

	// Determine if I can possibly shove any players on the other side of this die
	if( nnnx < 0 || nnnx >= m_boardSize || nnny < 0 || nnny >= m_boardSize) // nnnx/nnny invalid
		shovable = false;
	else if (m_gameboard[nnnx][nnny].state == FREE)
		shovable = true;
	else
		shovable = false;

	if(IsMovementValid(playerNum, dir))
	{
		s = m_gameboard[x][y].state;
		ns = m_gameboard[nx][ny].state;

		// Test: Sinkers and Risers may == Occupieds or Frees, when determining movement
		// depending on Y value
		if(s == SINKING || s == RISING)
		{
			if(m_gameboard[x][y].y <= .5)
				s = FREE;
			else
				s = OCCUPIED;
		}
		if(ns == SINKING || ns == RISING)
		{
			if(m_gameboard[nx][ny].y <= .5)
				ns = FREE;
			else
				ns = OCCUPIED;
		}
		tempState = m_gameboard[x][y].state;
		if(m_players[playerNum].smashed)
			tempState = FREE;
		switch(tempState)//(m_gameboard[x][y].state)
		{
		case FREE:
			// This spot is free, so we're moving the player from x,y to nx,ny
			// and moving the Die (if its there) from nx,ny to nnx,nny
			//printf("Moving player from (%i,%i) to (%i,%i)\n", x, y, nx, ny);
			m_players[playerNum].idle = false; // Player isnt idle anymore

			if(!m_gameboard[x][y].state == FREE) // Dont set unmovable flag if the position is really free, so player can get squished
				m_gameboard[x][y].unmovable[playerNum] = true; // This position cant be rolled/slid to

			// Create event to clear the player's unmovable flag
			temp.what = MAKE_MOVABLE;
			temp.when = dwTime + (DWORD)SLIDE_TIME/2; // set to half the time, because player wont be at this position the whole time
			temp.boardX = x;
			temp.boardY = y;
			temp.arg1 = playerNum;
			m_vEvents.push_back(temp);

			// Create player movement event
			temp.what = PL_MV_STR_IN;
			temp.when = dwTime + (DWORD)SLIDE_TIME;
			temp.boardX = x;
			temp.boardY = y;
			temp.arg1   = playerNum;
			temp.arg2   = dir;
			m_vEvents.push_back(temp);

			// Create player pos update event
			temp.what = PL_UPDATE_POS;
			temp.when = dwTime + (DWORD)SLIDE_TIME;
			temp.boardX = nx;
			temp.boardY = ny;
			temp.arg1   = playerNum;
			//temp.arg2   = dir;
			m_vEvents.push_back(temp);
			if(m_gameboard[nx][ny].state == OCCUPIED)
			{
				// set board states
				m_gameboard[nx][ny].state = SLIDE_FROM;
				m_gameboard[nnx][nny].state = SLIDE_TO;

				// Create slide sound event
				temp.what = PLAY_SLIDE_SOUND;
				temp.when = 0;
				temp.boardX = x;
				temp.boardY = y;
				m_vTempEvents.push_back(temp);

				// Create die movement event
				temp.what = SLIDE;
				temp.when = dwTime + (DWORD)SLIDE_TIME;
				temp.boardX = nx;
				temp.boardY = ny;
				temp.arg1   = playerNum;
				temp.arg2   = dir;
				m_vEvents.push_back(temp);

				// Create state change event (die position)
				temp.what = CHANGE_STATE;
				temp.when = dwTime + (DWORD)SLIDE_TIME;
				temp.boardX = nx;
				temp.boardY = ny;
				temp.arg1   = FREE;
				//temp.arg2   = ; //not used 
				m_vEvents.push_back(temp);

				// Create state change event (next die position)
				temp.what = CHANGE_STATE;
				temp.when = dwTime + (DWORD)SLIDE_TIME;
				temp.boardX = nnx;
				temp.boardY = nny;
				temp.arg1   = OCCUPIED;
				temp.arg2   = m_gameboard[nx][ny].dieState; 
				m_vEvents.push_back(temp);
				
				// Create sink dice event (next die position)
				temp.what = CHECK_SLID_SINK;
				temp.when = dwTime + (DWORD)SLIDE_TIME;
				temp.boardX = nnx;
				temp.boardY = nny;
				temp.arg1   = playerNum;
				//temp.arg2   = m_gameboard[nx][ny].dieState;  // Not used
				m_vEvents.push_back(temp);

				// Make sure we shove all the people riding the die
				// or on the other side of the die
				for(i = 0; i < m_numPlayers; i++)
				{
					// check for players riding the die
					// Make sure to only push idle players, if they're already moving let them escape
					if(i != playerNum && m_players[i].idle && !m_players[i].smashed && m_players[i].boardX == nx && m_players[i].boardY == ny)
					{
						// Shove this player.
						m_players[i].idle = false; // Player isnt idle anymore

						// Create player movement event
						temp.what = PL_MV_STR_OUT;
						temp.when = dwTime + (DWORD)SLIDE_TIME;
						temp.boardX = nx;
						temp.boardY = ny;
						temp.arg1   = i;
						temp.arg2   = dir;
						m_vEvents.push_back(temp);

						// Create player pos update event
						temp.what = PL_UPDATE_POS;
						temp.when = dwTime + (DWORD)SLIDE_TIME;
						temp.boardX = nnx;
						temp.boardY = nny;
						temp.arg1   = i;
						m_vEvents.push_back(temp);

					}
					// Check for players in front of the die
					else if(i != playerNum && m_players[i].idle && !m_players[i].smashed 
						    && m_players[i].boardX == nnx // players is on the ground in front of die..
							&& m_players[i].boardY == nny
							&& shovable) // Determined earlier, if this is a legal shove...
					{
						// Shove this player.
						m_players[i].idle = false; // Player isnt idle anymore

						// Create player movement event
						temp.what = PL_MV_STR_OUT;
						temp.when = dwTime + (DWORD)SLIDE_TIME;
						temp.boardX = nnx;
						temp.boardY = nny;
						temp.arg1   = i;
						temp.arg2   = dir;
						m_vEvents.push_back(temp);

						// Create player pos update event
						temp.what = PL_UPDATE_POS;
						temp.when = dwTime + (DWORD)SLIDE_TIME;
						temp.boardX = nnnx;
						temp.boardY = nnny;
						temp.arg1   = i;
						m_vEvents.push_back(temp);

					}
					else // this person isnt getting shoved, 
						 // so its possible theyre getting smashed
					{
						//Create player stomp events
						if(i != playerNum)// &&
							//(m_players[i].boardX == nnx && m_players[i].boardY == nny))
						{
							// Create die movement event
							temp.what = SMASH_PLAYER;
							temp.when = dwTime + (DWORD)SLIDE_TIME;
							temp.boardX = nnx;
							temp.boardY = nny;
							temp.arg1   = i;
							m_vEvents.push_back(temp);
						}
					}
				}
			}
			else //player isnt moving a die, set unmovable flag on the die we're moving to then
			{
				if(!m_gameboard[nx][ny].state == FREE) // Dont set unmovable flag if the position is really free, so player can get squished
					m_gameboard[nx][ny].unmovable[playerNum] = true;
			}
			break;

		case OCCUPIED:
			// This spot is occupied, so we're moving the player from x,y to nx,ny
			// and moving the Die from x,y to nx,ny also
			//printf("Moving player from (%i,%i) to (%i,%i)\n", x, y, nx, ny);
			m_players[playerNum].idle = false; // Player isnt idle anymore

			m_gameboard[x][y].unmovable[playerNum] = true; // This position cant be rolled/slid

			// Create event to clear the player's unmovable flag
			temp.what = MAKE_MOVABLE;
			temp.when = dwTime + (DWORD)SLIDE_TIME/2; // set to half the time, because player wont be at this position the whole time
			temp.boardX = x;
			temp.boardY = y;
			temp.arg1 = playerNum;
			m_vEvents.push_back(temp);
			

			// Create player pos update event
			temp.what = PL_UPDATE_POS;
			temp.when = dwTime + (DWORD)ROLL_TIME;
			temp.boardX = nx;
			temp.boardY = ny;
			temp.arg1   = playerNum;
			//temp.arg2   = dir;
			m_vEvents.push_back(temp);

			// If next spot is free, we're doing a roll
			// otherwise, only player is moving


			if(m_gameboard[nx][ny].state == FREE || ns==FREE)// m_gameboard[nx][ny].state == SINKING || m_gameboard[nx][ny].state == RISING)
			{
				// Rolling, so make a player move event
				temp.what = PL_MV_ARC_IN;
				temp.when = dwTime + (DWORD)ROLL_TIME;
				temp.boardX = x;
				temp.boardY = y;
				temp.arg1   = playerNum;
				temp.arg2   = dir;
				m_vEvents.push_back(temp);

				if(m_gameboard[nx][ny].state == SINKING)
				{
					// Create die movement event
					temp.what = KILL_SINKER;
					temp.when = dwTime + (DWORD)ROLL_TIME; // killing at the same time the roller stops.
					temp.boardX = nx;
					temp.boardY = ny;
					m_vEvents.push_back(temp);
				}
				if(m_gameboard[nx][ny].state == RISING)
				{
					// Create die movement event
					temp.what = MOVE_RISER;
					temp.when = dwTime + (DWORD)ROLL_TIME; // killing at the same time the roller stops.
					temp.boardX = nx;
					temp.boardY = ny;
					temp.arg1   = x;
					temp.arg2	= y;
					m_vEvents.push_back(temp);
				}
				// set board states
				m_gameboard[x][y].state = ROLL_FROM;
				m_gameboard[nx][ny].state = ROLL_TO;

				//Create player stomp events, for anyone currently at nx,ny
				// FIXME: What if a player is on a riser/sinker thats
				//        about to be moved/destroyed?
				/*for(i = 0; i<m_numPlayers; i++)
				{
					//printf("Hmmm...\n");
					if(i != playerNum &&
						(m_players[i].boardX == nx && m_players[i].boardY == ny))
					{
						// Create die movement event
						temp.what = SMASH_PLAYER;
						temp.when = dwTime + (DWORD)SLIDE_TIME;
						temp.boardX = nx;
						temp.boardY = ny;
						temp.arg1   = i;
						m_vEvents.push_back(temp);
					}
				}*/

				// Create die movement event
				temp.what = ROLL;
				temp.when = dwTime + (DWORD)ROLL_TIME;
				temp.boardX = x;
				temp.boardY = y;
				temp.arg1   = playerNum;
				temp.arg2   = dir;
				m_vEvents.push_back(temp);

				// Create state change event (die position)
				temp.what = CHANGE_STATE;
				temp.when = dwTime + (DWORD)ROLL_TIME;
				temp.boardX = x;
				temp.boardY = y;
				temp.arg1   = FREE;
				//temp.arg2   = ; //not used 
				m_vEvents.push_back(temp);

				// Create state change event (next die position)
				temp.what = CHANGE_STATE;
				temp.when = dwTime + (DWORD)ROLL_TIME;
				temp.boardX = nx;
				temp.boardY = ny;
				temp.arg1   = OCCUPIED;
				temp.arg2   = m_transTable[m_gameboard[x][y].dieState][dir]; 
				m_vEvents.push_back(temp);
				
				// Create sink dice event (next die position)
				temp.what = CHECK_SINK;
				temp.when = dwTime + (DWORD)ROLL_TIME;
				temp.boardX = nx;
				temp.boardY = ny;
				temp.arg1   = playerNum;
				//temp.arg2   = m_gameboard[nx][ny].dieState;  // Not used
				m_vEvents.push_back(temp);

				// Make sure we shove all the people riding the die
				for(i = 0; i < m_numPlayers; i++)
				{
					if(i != playerNum && m_players[i].idle &&!m_players[i].smashed && m_players[i].boardX == x && m_players[i].boardY == y)
					{
						//printf("Shoving player %i to %i,%i\n", i, nx, ny);
						// Shove this player.
						m_players[i].idle = false; // Player isnt idle anymore

						// Create player movement event
						temp.what = PL_MV_ARC_OUT;
						temp.when = dwTime + (DWORD)ROLL_TIME;
						temp.boardX = x;
						temp.boardY = y;
						temp.arg1   = i;
						temp.arg2   = dir;
						m_vEvents.push_back(temp);

						// Create player pos update event
						temp.what = PL_UPDATE_POS;
						temp.when = dwTime + (DWORD)ROLL_TIME;
						temp.boardX = nx;
						temp.boardY = ny;
						temp.arg1   = i;
						m_vEvents.push_back(temp);

					}
					else // this person isnt getting shoved, so its possible theyre getting smashed
					{
						//Create player stomp events
						if(i != playerNum)// &&
							//(m_players[i].boardX == nnx && m_players[i].boardY == nny))
						{
							// Create die movement event
							temp.what = SMASH_PLAYER;
							temp.when = dwTime + (DWORD)ROLL_TIME;
							temp.boardX = nx;
							temp.boardY = ny;
							temp.arg1   = i;
							m_vEvents.push_back(temp);
						}
					}
				}
			}
			else
			{
				// I'm just moving from die to die
				// creat the player move event
				temp.what = PL_MV_STR_IN;
				temp.when = dwTime + (DWORD)SLIDE_TIME;
				temp.boardX = x;
				temp.boardY = y;
				temp.arg1   = playerNum;
				temp.arg2   = dir;
				m_vEvents.push_back(temp);

				//make next die unmovable
				m_gameboard[nx][ny].unmovable[playerNum] = true;
			}
			break;
		case SINKING:
		case RISING:
			//Cant roll or slide anything from these positions, 
			// we can only move the player
			m_players[playerNum].idle = false; // Player isnt idle anymore

			m_gameboard[x][y].unmovable[playerNum] = true; // This position cant be rolled onto
			m_gameboard[nx][ny].unmovable[playerNum] = true; // Next position cant be rolled onto

			// Create event to clear the player's unmovable flag
			temp.what = MAKE_MOVABLE;
			temp.when = dwTime + (DWORD)SLIDE_TIME/2; // set to half the time, because player wont be at this position the whole time
			temp.boardX = x;
			temp.boardY = y;
			temp.arg1 = playerNum;
			m_vEvents.push_back(temp);

			// Create player movement event
			temp.what = PL_MV_STR_IN;
			temp.when = dwTime + (DWORD)SLIDE_TIME;
			temp.boardX = x;
			temp.boardY = y;
			temp.arg1   = playerNum;
			temp.arg2   = dir;
			m_vEvents.push_back(temp);

			// Create player pos update event
			temp.what = PL_UPDATE_POS;
			temp.when = dwTime + (DWORD)SLIDE_TIME;
			temp.boardX = nx;
			temp.boardY = ny;
			temp.arg1   = playerNum;
			//temp.arg2   = dir;
			m_vEvents.push_back(temp);
			break;

		}

	}
}

void CDiceGame::CreateSlidSinkers(int x, int y, int playerNum)
{
	int value = (m_gameboard[x][y].dieState / 4) + 1;
	int score = 0;
	Event event;

	// I only care about 1's let the other function deal with other values
	if(value != 1)
	{
		CreateSinkers(x,y,playerNum);
		return;
	}

	// Check if any beighbors are sinking
	// Left
	if((x-1 >=0 && m_gameboard[x-1][y].state == SINKING) || 
		(x+1 <m_boardSize && m_gameboard[x+1][y].state == SINKING) || 
		(y-1 >=0 && m_gameboard[x][y-1].state == SINKING) ||
		(y+1 <m_boardSize && m_gameboard[x][y+1].state == SINKING))
	{

		for(int i = 0; i < m_boardSize; i++)
			for(int j = 0; j < m_boardSize; j++)
			{
				if((m_gameboard[i][j].dieState / 4) == 0 && m_gameboard[i][j].state == OCCUPIED)
				{
					m_numSunk++;
					if(m_numSunk > 30)
					{
						// FIXME: Define the number of sunk dice per level somewhere
						m_level++;
						m_numSunk%=30;

						// Make the Level Up sound
						event.what = PLAY_LEVELUP_SOUND;
						event.when = 0;
						m_vTempEvents.push_back(event);
					}
					score += 1; // 1 point for every 1 sunk
					m_gameboard[i][j].state = SINKING;
					m_gameboard[i][j].chains = 0; 

					// Make sinking die event
					event.what = SINK;
					event.when = SINK_TIME+dwTime;
					event.boardX = i;
					event.boardY = j;
					event.arg1 = m_gameboard[x][y].dieState;
					event.arg2 = playerNum;
					m_vEvents.push_back(event);

					// Make state change event
					event.what = CHANGE_STATE;
					event.when = SINK_TIME+dwTime;
					event.boardX = i;
					event.boardY = j;
					event.arg1 = FREE;
					m_vEvents.push_back(event);
				}
			}

	}
	if(score > 0)
	{
		m_players[playerNum].score += score;
		//printf("%i 1's sunk! Total score for player %i is %i\n", score, playerNum, m_players[playerNum].score);
		
		// If we've got a score, we've sunk dice, so play the chime
		event.what = PLAY_SINK_SOUND;
		event.when = 0;
		event.boardX = x;
		event.boardY = y;
		m_vTempEvents.push_back(event);
	
	}
	return;

}

void CDiceGame::CreateSinkers(int x, int y, int playerNum)
{

	int i, j;
	Event event;
	int numSunk = 0; 

	// The value of the die here
	int value = (m_gameboard[x][y].dieState / 4) + 1;
	int score = 0; // The score I get from occ->sinks
	int chainscore = 0;// The score I get from chaining

	if(value < 4 && m_gameType == BASIC_HARDCORE)
		return;

	if(value == 1)
	{
		// Check if any beighbors are sinking
		// Left
		if((x-1 >=0 && m_gameboard[x-1][y].state == SINKING) || 
		   (x+1 <m_boardSize && m_gameboard[x+1][y].state == SINKING) || 
		   (y-1 >=0 && m_gameboard[x][y-1].state == SINKING) ||
		   (y+1 <m_boardSize && m_gameboard[x][y+1].state == SINKING))
		{

			for(i = 0; i < m_boardSize; i++)
				for(j = 0; j < m_boardSize; j++)
				{
					if((m_gameboard[i][j].dieState / 4) == 0 && m_gameboard[i][j].state == OCCUPIED
						&& !(x == i && y== j))
					{
						m_numSunk++;
						if(m_numSunk > 30)
						{
							// FIXME: Define the number of sunk dice per level somewhere
							m_level++;
							m_numSunk%=30;

							// Make the Level Up sound
							event.what = PLAY_LEVELUP_SOUND;
							event.when = 0;
							m_vTempEvents.push_back(event);
						}
						score += 1; // 1 point for every 1 sunk
						m_gameboard[i][j].state = SINKING;
						m_gameboard[i][j].chains = 0; 

						// Make sinking die event
						event.what = SINK;
						event.when = SINK_TIME+dwTime;
						event.boardX = i;
						event.boardY = j;
						event.arg1 = m_gameboard[x][y].dieState;
						event.arg2 = playerNum;
						m_vEvents.push_back(event);

						// Make state change event
						event.what = CHANGE_STATE;
						event.when = SINK_TIME+dwTime;
						event.boardX = i;
						event.boardY = j;
						event.arg1 = FREE;
						m_vEvents.push_back(event);
					}
				}

		}
		if(score > 0)
		{
			m_players[playerNum].score += score;
			//printf("%i 1's sunk! Total score for player %i is %i\n", score, playerNum, m_players[playerNum].score);
			
			event.what = PLAY_SINK_SOUND;
			event.when = 0;
			event.boardX = x;
			event.boardY = y;
			m_vTempEvents.push_back(event);
		}
		return;
	}


		

	

	// I need to check neighers for sinkers and as well as occupieds
	// They both work differently. Lets see how confusing I can make this...

	//clear sinker vector
	m_vPosList.clear();
	// clear gameboard flags
	for(i = 0; i < m_boardSize; i++)
		for(j = 0; j < m_boardSize; j++)
			m_gameboard[i][j].flag = false;
	// Set our flag, so we're not checked again.
	m_gameboard[x][y].flag = true;

	// First, make a list of all the matching sinkers. We'll need to steal them
	// Check neighbors to see if theyre sinking, have the same value as us,
	// and are unflagged. If so, run CheckSinkersHelper on them
	// Left
	if(x-1 >=0 && m_gameboard[x-1][y].state == SINKING && (m_gameboard[x-1][y].dieState/4)+1 == value && !m_gameboard[x-1][y].flag)
		CreateSinkersHelper(x-1, y, SINKING);
	// Right
	if(x+1 <m_boardSize && m_gameboard[x+1][y].state == SINKING && (m_gameboard[x+1][y].dieState/4)+1 == value && !m_gameboard[x+1][y].flag)
		CreateSinkersHelper(x+1, y, SINKING);
	// Up
	if(y-1 >=0 && m_gameboard[x][y-1].state == SINKING && (m_gameboard[x][y-1].dieState/4)+1 == value && !m_gameboard[x][y-1].flag)
		CreateSinkersHelper(x, y-1, SINKING);
	// Left
	if(y+1 <m_boardSize && m_gameboard[x][y+1].state == SINKING && (m_gameboard[x][y+1].dieState/4)+1 == value && !m_gameboard[x][y+1].flag)
		CreateSinkersHelper(x, y+1, SINKING);

	/*if(m_vPosList.size() > 0)
	{
		score = (m_vPosList.size() +1)*value; // Compute score, before muliplier for chaining
		// We have matching sinkers, so we need to sink this one, plus steal all the others
		m_gameboard[x][y].state = SINKING;
		m_gameboard[x][y].chains = 0; // set to base value, increase to sinkers chain value

		// Steal the coresponding SINK events
		for(i= 0; i<m_vEvents.size(); i++)
		{
			//printf("ping1!\n");
			if(m_vEvents[i].what == SINK)
			{
				//printf("ping2!\n");
				for(j = 0; j < m_vPosList.size(); j++)
				{
					printf("ping3!\n");
					if(m_vEvents[i].boardX == m_vPosList[j].x && m_vEvents[i].boardY == m_vPosList[j].y)
					{
						// Need to steal this event
						// TODO: Do special action, steal score or whatever
						m_vEvents[i].arg2 = playerNum;
						if(m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].chains < 0)
							printf("something is wrong!\n");
						m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].chains++;
						printf("Chain value at %i, %i is now %i\n", m_vEvents[i].boardX, m_vEvents[i].boardY, m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].chains);
						if(m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].chains > m_gameboard[x][y].chains)
						{
							m_gameboard[x][y].chains = m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].chains;
							
							// If this is printed more than once, not all sinkers have 
							// the same sink value, which might be trouble.
							printf("Boosting the chain value at %i,%i\n", x, y);
						}
						// Erase this position from the list, to speed things up
						m_vPosList.erase(m_vPosList.begin()+j);

						// wont be any more matches, so break
						break;
					}
				}
			}
		}

		printf("Chain!! Number #%i\n", m_gameboard[x][y].chains);
		m_players[playerNum].score += score *(m_gameboard[x][y].chains+1);
		printf("Base score: %i\nMultiplier: %i\nTotal score: %i\nTotal player %i score: %i\n", score, m_gameboard[x][y].chains+1, score *( m_gameboard[x][y].chains+1), playerNum,m_players[playerNum].score );

		// Make sinking die event
		event.what = SINK;
		event.when = SINK_TIME+dwTime;
		event.boardX = x;
		event.boardY = y;
		event.arg1 = m_gameboard[x][y].dieState;
		event.arg2 = playerNum;
		m_vEvents.push_back(event);

		// Make state change event
		event.what = CHANGE_STATE;
		event.when = SINK_TIME+dwTime;
		event.boardX = x;
		event.boardY = y;
		event.arg1 = FREE;
		m_vEvents.push_back(event);

		
		
	}

	//clear sinker vector
	m_vPosList.clear();
	// clear gameboard flags
	for(i = 0; i < m_boardSize; i++)
		for(j = 0; j < m_boardSize; j++)
			m_gameboard[i][j].flag = false;
	// Set our flag, so we're not checked again.
	m_gameboard[x][y].flag = true;

	*/

	// Sinkers are taken care of, now check occupied neighbors
	// Check neighbors to see if theyre occupied, have the same value as us,
	// and are unflagged. If so, run CheckSinkers on them
	// Left
	if(x-1 >=0 && m_gameboard[x-1][y].state == OCCUPIED && (m_gameboard[x-1][y].dieState/4)+1 == value && !m_gameboard[x-1][y].flag)
		CreateSinkersHelper(x-1, y, OCCUPIED);
	// Right
	if(x+1 <m_boardSize && m_gameboard[x+1][y].state == OCCUPIED && (m_gameboard[x+1][y].dieState/4)+1 == value && !m_gameboard[x+1][y].flag)
		CreateSinkersHelper(x+1, y, OCCUPIED);
	// Up
	if(y-1 >=0 && m_gameboard[x][y-1].state == OCCUPIED && (m_gameboard[x][y-1].dieState/4)+1 == value && !m_gameboard[x][y-1].flag)
		CreateSinkersHelper(x, y-1, OCCUPIED);
	// Left
	if(y+1 <m_boardSize && m_gameboard[x][y+1].state == OCCUPIED && (m_gameboard[x][y+1].dieState/4)+1 == value && !m_gameboard[x][y+1].flag)
		CreateSinkersHelper(x, y+1, OCCUPIED);

	
	

	// Now, we have a big list full of potential sinkers, some of which may already be sinking
	// We need to steal and chain the sinkers, and sink the occupied
	// But, only if the total number of potential sinkers is >= value
	if(m_vPosList.size() >= (unsigned int)value-1) // Only make sinkers if we have enough matches (including this one)
	{
		m_numSunk += (int)m_vPosList.size() +1; // FIXME. I'm counting stolen sinkers 
		                                // twice. Is that okay? I dont know.
		if(m_numSunk > 30)
		{
			// FIXME: Define the number of sunk dice per level somewhere
			m_level++;
			m_numSunk%=30;

			// Make the Level Up sound
			event.what = PLAY_LEVELUP_SOUND;
			event.when = 0;
			m_vTempEvents.push_back(event);
		}
		
		// TODO: If the die created a combo and a new chain at the same time,
		// Its getting scored twice. Probably fine, no big deal. 
		// At most, its a 6 point difference. :P
		//score = (m_vPosList.size() +1)*value;
		//m_players[playerNum].score += score;
		//printf("Score: %i. PLayer %i total: %i\n", score, playerNum, m_players[playerNum].score);

		//if(m_gameboard[x][y].state != SINKING)
		//{
		m_gameboard[x][y].state = SINKING;
		m_gameboard[x][y].chains = 0;

		// Make sinking die event
		event.what = SINK;
		event.when = SINK_TIME+dwTime;
		event.boardX = x;
		event.boardY = y;
		event.arg1 = m_gameboard[x][y].dieState;
		event.arg2 = playerNum;
		m_vEvents.push_back(event);

		// Make state change event
		event.what = CHANGE_STATE;
		event.when = SINK_TIME+dwTime;
		event.boardX = x;
		event.boardY = y;
		event.arg1 = FREE;
		m_vEvents.push_back(event);
		//}

		for(i = 0; i < (int)m_vPosList.size(); i++)
		{
			if(m_gameboard[m_vPosList[i].x][m_vPosList[i].y].state == OCCUPIED)
			{
				score+= value;
				m_gameboard[m_vPosList[i].x][m_vPosList[i].y].state = SINKING;
				m_gameboard[m_vPosList[i].x][m_vPosList[i].y].chains = 0;


				// Make sinking die event
				event.what = SINK;
				event.when = SINK_TIME+dwTime;
				event.boardX = m_vPosList[i].x;
				event.boardY = m_vPosList[i].y;
				event.arg1 = m_gameboard[x][y].dieState;
				event.arg2 = playerNum;
				m_vEvents.push_back(event);

				// Make state change event
				event.what = CHANGE_STATE;
				event.when = SINK_TIME+dwTime;
				event.boardX = m_vPosList[i].x;
				event.boardY = m_vPosList[i].y;
				event.arg1 = FREE;
				m_vEvents.push_back(event);
			}
			else
			{
				// Steal the coresponding SINK events
				for(j= 0; j<(int)m_vEvents.size(); j++)
				{
					//printf("ping1!\n");
					if(m_vEvents[j].what == SINK)
					{
						//printf("ping2!\n");
						//for(j = 0; j < m_vPosList.size(); j++)
						//{
							//printf("ping3!\n");
						if(m_vEvents[j].boardX == m_vPosList[i].x && m_vEvents[j].boardY == m_vPosList[i].y)
						{
							chainscore += value;
							// Need to steal this event
							// TODO: Do special action, steal score or whatever
							m_vEvents[j].arg2 = playerNum;
							if(m_gameboard[m_vEvents[j].boardX][m_vEvents[j].boardY].chains < 0)
								printf("something is wrong!\n");
							m_gameboard[m_vEvents[j].boardX][m_vEvents[j].boardY].chains++;
							//printf("Chain value at %i, %i is now %i\n", m_vEvents[j].boardX, m_vEvents[j].boardY, m_gameboard[m_vEvents[j].boardX][m_vEvents[j].boardY].chains);
							if(m_gameboard[m_vEvents[j].boardX][m_vEvents[j].boardY].chains > m_gameboard[x][y].chains)
							{
								//m_gameboard[x][y].chains = m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].chains;
								m_gameboard[x][y].chains = m_gameboard[m_vEvents[j].boardX][m_vEvents[j].boardY].chains;
								
								// If this is printed more than once, not all sinkers have 
								// the same sink value, which might be trouble.
								//printf("Boosting the chain value at %i,%i\n", x, y);
							}
							// Erase this position from the list, to speed things up
							//m_vPosList.erase(m_vPosList.begin()+j);

							// wont be any more matches, so break
							break;
						}
						//}
					}
				}// End event scan
				//chainscore *=(m_gameboard[x][y].chains+1);

			}

		}// End potential sinker position scan
	}//End sinker.size()>=value check

	if(score>0)
	{
		score += value; // Add in this die's value to score
		//printf("Score: %i\n", score);

		
	}
	if(chainscore >0)
	{
		chainscore += value; // Add in this die's chain score
		chainscore *= (m_gameboard[x][y].chains+1); //Do multiplier
		//printf("Chainscore: %i (muliplier: %i)\n", chainscore,m_gameboard[x][y].chains+1);
	}
	m_players[playerNum].score += score+chainscore;
	if(score+chainscore >0)
	{
		// If we have a score, we're sinking, so play the chime
		event.what = PLAY_SINK_SOUND;
		event.when = 0;
		event.boardX = x;
		event.boardY = y;
		m_vTempEvents.push_back(event);
	}
	//if(score+chainscore > 0)
		//printf("Total score for player %i: %i\n", playerNum, m_players[playerNum].score);
}


void CDiceGame::CreateSinkersHelper(int x, int y, GamePosState state)
{
	// return on bad position
	if(x < 0 || x >= m_boardSize || y < 0 || y >= m_boardSize)
		return;

	Position temp;

	// The value of the die here
	int value = (m_gameboard[x][y].dieState / 4) + 1;

	m_gameboard[x][y].flag = true;
	// If we're called, this die is a sinker candidate, so add it to the list
	temp.x = x, temp.y = y;
	m_vPosList.push_back(temp);

	// Left
	if(x-1 >=0 && m_gameboard[x-1][y].state == state && (m_gameboard[x-1][y].dieState/4)+1 == value && !m_gameboard[x-1][y].flag)
		CreateSinkersHelper(x-1, y, state);
	// Right
	if(x+1 <m_boardSize && m_gameboard[x+1][y].state == state && (m_gameboard[x+1][y].dieState/4)+1 == value && !m_gameboard[x+1][y].flag)
		CreateSinkersHelper(x+1, y, state);
	// Up
	if(y-1 >=0 && m_gameboard[x][y-1].state == state && (m_gameboard[x][y-1].dieState/4)+1 == value && !m_gameboard[x][y-1].flag)
		CreateSinkersHelper(x, y-1, state);
	// DOWN
	if(y+1 <m_boardSize && m_gameboard[x][y+1].state == state && (m_gameboard[x][y+1].dieState/4)+1 == value && !m_gameboard[x][y+1].flag)
		CreateSinkersHelper(x, y+1, state);

	
	return;
}


void CDiceGame::GameLoop(DWORD dwElapsedTime)//, Direction *pPlayerInput)
{
	//printf("Entered Gameloop\n");
	static int timeRemaining;
	//static DWORD numUpdates = 0; // The number of times we've run the game loop
	                           // This bumber will be used with scripting. The value
							   // is saved when making script events, and then 
							   // check when the script event is run.
	
	//printf("dwTimw: %i\n", dwTime);
	int i, j, k;
	//vector<Event> vTempEvents;
	Event event;
	Direction playerInputs[5]; // array for input

	WaitForSingleObject(m_hMutex,INFINITE);

	timeRemaining += dwElapsedTime;

	// We've been called, but not enough time has passed to 
	// update the event list. So, make sure sound events are stripped
	// otherwise they get played twice
	if(timeRemaining < UPDATE_TIME)
	{
		for(i = 0; i < (int)m_vEvents.size(); i++)
		{
			switch(m_vEvents[i].what) // Easier than making a giant 'if'
			{
			case PLAY_GAME_OVER_SOUND:
			case PLAY_ZAP_SOUND:
			case PLAY_SLIDE_SOUND:
			case PLAY_ROLL_END_SOUND:
			case PLAY_SINK_SOUND:
			case PLAY_LEVELUP_SOUND:
			case PLAY_OUCH_SOUND:
				//printf("Stripped a sound\n");
				m_vEvents.erase(m_vEvents.begin()+i);
				i--;
				break;
			default:
				break;
			}

		}
	}

	if(dwElapsedTime == 0)
	{
		//printf("I'm running incredibly fast\n");
		return; // Game is paused. Or, I'm running incredibly fast. :)
	}

	while(timeRemaining >= UPDATE_TIME)
	{
		if(m_runningScript)
			RunScript();
		else
			// FIXME!!! This fuction makes the class dependant on the outside
			// function. Not so bad, but I must make the function configurable
			// with a function pointer
		{
			DIGetInput(playerInputs);

			// Copy player input into the player struct
			// --only if script isnt running, you doof--
			for(i = 0; i < m_numPlayers; i++)
			{
				m_players[i].dir = playerInputs[i];
			}
		}

		// Create scripting events for player input
		bool inputChanged = false;
		for(i = 0; i < m_numPlayers; i++)
		{
			if(m_oldDirections[i] != m_players[i].dir)
				inputChanged = true;
			m_oldDirections[i] = m_players[i].dir;
		}
		
		
		if(m_recordingScript && inputChanged)
			AddInputUpdateEvent(m_numUpdates, m_players, m_numPlayers);

		

		// Event loop. Process all events
		for(i = 0; i < (int)m_vEvents.size(); i++)
		{
		
			// Only process event that have expired
			if(m_vEvents[i].when <= dwTime)
			{
				// Do the event
				switch(m_vEvents[i].what)
				{
				case ROLL:  // Rolling Die
				case SLIDE: // Sliding Die
				case RISE:           // Rising Die
				case SINK:           // Sinking Die
					break; 
				case PL_MV_STR_IN:   // Player moving in a straight line (sliding a die), in control
				case PL_MV_STR_OUT:  // Player moving in a straight line out of control (riding a sliding die)
				case PL_MV_ARC_IN:  // Player moving, in control, in an arc (rolling a die)
				case PL_MV_ARC_OUT: 
					m_players[m_vEvents[i].arg1].idle = true;
					break; // For movement events, hitting the event time means the event has finished. 
						// I only have to remove it from the list. Cake!
						// The Event itself is only used for the graphic renderer

				case CHANGE_STATE:	// Change of state at a board position
					if(m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].state == ROLL_TO)
					{
						//printf("Adding clunk sound at dwTime\n");
						event.what = PLAY_ROLL_END_SOUND;
						event.when = 0;
						event.boardX = m_vEvents[i].boardX;
						event.boardY = m_vEvents[i].boardY;
						m_vTempEvents.push_back(event);
					}
					// Arg1 is the new state...
					m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].state = (GamePosState)m_vEvents[i].arg1;
					// Arg2 is the new dieState, if needed. Should only only when new state is OCCUPIED, I think...
					if(m_vEvents[i].arg1 == OCCUPIED)
						m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].dieState = m_vEvents[i].arg2;
					break;

				case CHECK_SINK: 	// Check for sinkers at this loc
					CreateSinkers(m_vEvents[i].boardX, m_vEvents[i].boardY, m_vEvents[i].arg1);
					break;
				case CHECK_SLID_SINK: 	// Check for sinkers at this loc
					CreateSlidSinkers(m_vEvents[i].boardX, m_vEvents[i].boardY, m_vEvents[i].arg1);
					break;
				case PL_UPDATE_POS:
					m_players[m_vEvents[i].arg1].boardX = m_vEvents[i].boardX;
					m_players[m_vEvents[i].arg1].boardY = m_vEvents[i].boardY;
					m_players[m_vEvents[i].arg1].smashed = false; // Unsmash the player
					m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].unmovable[m_vEvents[i].arg1] = false; // clear player's unmovable flag
					break;
				case KILL_SINKER:
					// I need to scan the list, and kill all 
					// event relating to the sinker
					// But, I need to be careful, and not go on position alone
					// There will be a change state event for this spot for the roller
					for(j = 0; j < (int)m_vEvents.size(); j++)
					{
						if(j != i // dont delete this one!
							&& m_vEvents[i].boardX == m_vEvents[j].boardX
							&& m_vEvents[i].boardY == m_vEvents[j].boardY
							&& (m_vEvents[j].what == SINK // Catch the sinker event
								|| (m_vEvents[j].what == CHANGE_STATE && m_vEvents[j].arg1 == FREE))) // Catch the change state event
						{
							m_vEvents.erase(m_vEvents.begin()+j); // Delete the event
							// decrement both counter, dont screw things up
							j--;
							i--;
						}
					}
					break;
				case MOVE_RISER:
					// I need to scan the list, and change all
					// events relating to the riser, to move it
					// I need to change:
					//		The RISE event - new position
					//      The CHANGE_STATE - OCCUPIED event, relating to the riser 
					//                       - new position
					//      The CHANGE_STATE - FREE event, relating to the 
					//                         roller crushing the riser
					//                       - change state to RISING to negate it's effect
					// Need to be careful, this will find 2 indistinguishable
					// CHANGE_STATE - OCCUPIED events, one is for the roller. 
					// That one cant be changed. I seem to have gotten around
					// that problem with a well placed 'break;'
					for(j = 0; j < (int)m_vEvents.size(); j++)
					{
						if(j != i // dont mess up this one!
							&& ((m_vEvents[i].boardX == m_vEvents[j].boardX 
							&& m_vEvents[i].boardY == m_vEvents[j].boardY)
								|| (m_vEvents[i].arg1 == m_vEvents[j].boardX 
								&& m_vEvents[i].arg2 == m_vEvents[j].boardY)))
						{
							// This will catch the roller's CHANGE_STATE
							if(m_vEvents[j].what == CHANGE_STATE && m_vEvents[j].arg1 == FREE)
							{
								//printf("Caught a CHANGE_STATE-FREE at %i,%i\n", m_vEvents[j].boardX,m_vEvents[j].boardY);
								m_vEvents[j].arg1 = RISING; // I could remove event, but nahh
								break; // This seems to be the last event I catch that I want
							}
							// This will catch the RISE event
							else if(m_vEvents[j].what == RISE)
							{
								//printf("caught a RISE event at %i,%i\n", m_vEvents[j].boardX,m_vEvents[j].boardY);
								// These dont need to be here, but good enough
								m_gameboard[m_vEvents[i].arg1][m_vEvents[i].arg2].state = RISING;// tempState;
								m_gameboard[m_vEvents[i].arg1][m_vEvents[i].arg2].y = m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].y;
								
								// Move the riser to the new location
								m_vEvents[j].boardX = m_vEvents[i].arg1;
								m_vEvents[j].boardY = m_vEvents[i].arg2;
							}
							else if(m_vEvents[j].what == CHANGE_STATE && m_vEvents[j].arg1 == OCCUPIED)
							{
								//printf("caught a CHANGE_STATE-OCCUPIED at %i,%i\n", m_vEvents[j].boardX,m_vEvents[j].boardY);
								// Move the riser to the new location
								m_vEvents[j].boardX = m_vEvents[i].arg1;
								m_vEvents[j].boardY = m_vEvents[i].arg2;
							}
							
						}
					}
					break;
				case SMASH_PLAYER:
					//printf("Got smash event\n");
					if(m_vEvents[i].boardX == m_players[m_vEvents[i].arg1].boardX &&
						m_vEvents[i].boardY == m_players[m_vEvents[i].arg1].boardY)
					{
						//printf("Smashing player %i\n", m_vEvents[i].arg1);
						m_players[m_vEvents[i].arg1].smashed = true;

						// Make the poor player scream. :)
						event.what = PLAY_OUCH_SOUND;
						event.when = 0;
						event.boardX = m_players[m_vEvents[i].arg1].boardX;
						event.boardY = m_players[m_vEvents[i].arg1].boardY;
						event.arg1 = m_vEvents[i].arg1; // Send along player number
														// So someday I can make each 
						                                // sound a little different maybe
						m_vTempEvents.push_back(event);
					}
					break;
				case MAKE_MOVABLE: // clear the player's unmovabel flag at this position
					m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].unmovable[m_vEvents[i].arg1] = false;
					break;
				case CHECK_FREE_SPACES:
					{
						//printf("Checking Free spaces at time %i\n", dwTime);
					Position temp;
					m_vPosList.clear();
					// Get list of free spots
					for(j = 0; j < m_boardSize; j++)
						for(k=0; k<m_boardSize; k++)
						{
							if(m_gameboard[j][k].state == FREE)
							{
								temp.x = j;
								temp.y = k;
								m_vPosList.push_back(temp);
							}
						}
					j = 0;
					if((int)m_vPosList.size() > (20-m_level))//(int)(m_boardSize * m_boardSize)/2)
					{
						int numToCreate = (int)m_vPosList.size() - (20-m_level);//(m_boardSize * m_boardSize)/2;
						for(j = 0; j < numToCreate; j++)
						{
							Event event;

							event.what = CREATE_RISER;
							event.when = dwTime + j*MIN_TIME_BTW_RISE;
							m_vEvents.push_back(event);
						}
						event.what = CHECK_FREE_SPACES;
						event.when = dwTime + j*MIN_TIME_BTW_RISE + TIME_BTW_FREE_CHECK;
						m_vEvents.push_back(event);
					}
					else // We have plenty of dice, but keep spawning slowly to keep the pressure on.
					{
						event.what = CREATE_RISER;
						event.when = dwTime;
						m_vEvents.push_back(event);

						event.what = CHECK_FREE_SPACES;
						event.when = dwTime + RISE_TIME; //FIXME: define this time value
						m_vEvents.push_back(event);
					}
					break;
					}
				case CREATE_RISER:
					//break;
						
					Position temp;
					int variable; // HA.
					int mode; // the mode for the new die.
					m_vPosList.clear();
					// Get list of free spots
					for(j = 0; j < m_boardSize;j++)
						for(k=0; k<m_boardSize; k++)
						{
							if(m_gameboard[j][k].state == FREE)
							{
								temp.x = j;
								temp.y = k;
								m_vPosList.push_back(temp);
							}
						}
					if(m_vPosList.size() == 0)
						break; // Game will probably be over very shortly.
					Event event;
					variable = rand()%(int)m_vPosList.size();
					
					//Set riser state
					m_gameboard[m_vPosList[variable].x][m_vPosList[variable].y].state = RISING;
					mode = rand()%24;
					// Make riser event
					event.what = PLAY_ZAP_SOUND;
					event.when = 0;
					event.boardX = m_vPosList[variable].x;
					event.boardY = m_vPosList[variable].y;
					m_vTempEvents.push_back(event);

					// Make riser event
					event.what = RISE;
					event.when = dwTime+RISE_TIME;
					event.boardX = m_vPosList[variable].x;
					event.boardY = m_vPosList[variable].y;
					event.arg1 = mode;
					m_vEvents.push_back(event);
					
					// Make State Change event
					event.what = CHANGE_STATE;
					event.when = dwTime+RISE_TIME;
					event.boardX = m_vPosList[variable].x;
					event.boardY = m_vPosList[variable].y;
					event.arg2 = event.arg1;
					event.arg1 = OCCUPIED;
					m_vEvents.push_back(event);

					// Add riser event to script;
					// TODO: Use numUpdates instead of dwTime
					if(m_recordingScript)
						AddRiserEvent(m_numUpdates, m_vPosList[variable].x,m_vPosList[variable].y,mode);
					
					break;
					
				default:
					break;
				}

				// The event has happened, erase it from the vector
				m_vEvents.erase(m_vEvents.begin()+i);

				// decrement i, so this position is checked again
				i--;
			}
			else
			{
				switch(m_vEvents[i].what)
				{
				case RISE:           // Rising Die
					if(RISE_TIME-(m_vEvents[i].when-dwTime) < PRE_RISE_TIME)
					{
						m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].y = .05f;
					}
					else
						m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].y = (1-((m_vEvents[i].when-dwTime)/(float)(RISE_TIME-PRE_RISE_TIME))) * .95f +0.05f;
					//printf("When: %i Time: %i Riser Y: %f.\n",m_vEvents[i].when,dwTime,m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].y);
					break;
				case SINK:           // Sinking Die
					m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].y = (m_vEvents[i].when-dwTime)/(float)SINK_TIME;
					//printf("%f\n",m_gameboard[m_vEvents[i].boardX][m_vEvents[i].boardY].y);
					break; 
				}
			}
		}
		
		
		for(i = 0; i < (int)m_numPlayers; i++)
		{
			if(m_players[i].dir != NONE)
				m_players[i].facing = m_players[i].dir;
		

			// Checking to see if I can remove smashed flag here too
			// Checking to see if the player's state is free should catch everything
			if(m_players[i].smashed && m_gameboard[m_players[i].boardX][m_players[i].boardY].state == FREE)
			{
				//printf("unsmashing player %i\n", i);
				m_players[i].smashed = false;
			}
			if(m_players[i].idle)
			{
				//printf("ping!\n");
				MovePlayer(i);//,pPlayerInput[i]);
			}
		}

		
		// Check to see if the game is over
		bool flag = true;
		for(i = 0; i < m_boardSize; i++)
			for(int j=0; j<m_boardSize; j++)
			{
				if(m_gameboard[i][j].state != OCCUPIED)
				{
					flag = false;
				}
			}
		
		if(flag && !gameover) // Game over. haha!
		{
			gameover = true;
			printf("Game over!!\n");
			for(i = 0; i < m_numPlayers; i++)
				printf("   Player %i final score: %i\n", i+1, m_players[i].score);

			// Make game over sound
			event.what = PLAY_GAME_OVER_SOUND;
			event.when = 0;
			m_vTempEvents.push_back(event);
		}

		m_numUpdates++;
		timeRemaining -= UPDATE_TIME;
		dwTime+= UPDATE_TIME;
	}//End while(timeRemaining > UPDATE_TIME)

	// Copy temp event vector to real buffer
	// Should be all sound events. They're in a temp vector
	// so they dont get eaten by the event processing, 
	// because they only last 1 event loop.
	while(m_vTempEvents.size() > 0)
	{
		m_vEvents.push_back(m_vTempEvents[m_vTempEvents.size()-1]);
		m_vTempEvents.pop_back();
	}

	ReleaseMutex(m_hMutex);
}
