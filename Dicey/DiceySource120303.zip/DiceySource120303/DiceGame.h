#pragma once
#include <windows.h> //Just for DWORD basically..
#include <vector>
using namespace std;

#define UPDATE_TIME 10 // The amount of time (in ms) that the gameloop will do per update

#define SLIDE_TIME 300  // Time to slide a Die
#define ROLL_TIME 300   // Time to roll a Die
#define SINK_TIME 10000 // Time to sink a die
#define RISE_TIME 3000 // This includes the pre-rise time!
#define PRE_RISE_TIME 1000 // the time the riser sits there for a bit
#define MAX_Y_VARIANCE .5  // MAximum variance of the y values of 2 dice, for the player to walk between them
#define MIN_TIME_BTW_RISE  300//1000 // The mininum amount of time between creating risers
#define TIME_BTW_FREE_CHECK 10000 // Time between checks to see if we should spawn more dice.

enum GameTypes {BASIC_NORMAL, BASIC_HARDCORE}; // The gametypes
											   // Basic is the standard game, just remove dice until you die
											   //    Normal - standard
											   //    Hardcore - 1s, 2s, 3s do nothing

//enum {IN, OUT}; // For player movement events, in or out of control
enum GamePosState {FREE, OCCUPIED, SLIDE_FROM, SLIDE_TO, ROLL_FROM, ROLL_TO, SINKING, RISING};
enum Direction {UP, DOWN, LEFT, RIGHT, NONE}; // NONE used for input only
enum EventType {ROLL,           // Rolling Die
				SLIDE,			// Sliding Die
				CHANGE_STATE,	// Change of state at a board position
				CHECK_SINK,		// Check for sinkers at this loc
				CHECK_SLID_SINK,// Check for sinkers at this loc, noting that the die was slid here
								// This is because slid 1's sink, while rolled ones dont.
				RISE,           // Rising Die
				SINK,           // Sinking Die

				KILL_SINKER,    // Player has smashed a sinker, all events about it need to be erased   
				MOVE_RISER,		// Player has smashed a riser, so it needs to be moved to where the player rolled from

				SMASH_PLAYER,  // Event sent to notify that a play might be 
							   // getting smahed at a particular location
							   // If theyre still there, their smashed flag is set

				PL_UPDATE_POS,    // Update the player's position
								  // Will also clear the unmovable flag when appropriate
				// Maybe condense these by giving Event a 3rd argument for in/out of control
				PL_MV_STR_IN,   // Player moving in a straight line (sliding a die)
				PL_MV_STR_OUT,
				PL_MV_ARC_IN,// Player moving in an arc (rolling a die)
				PL_MV_ARC_OUT,

				CHECK_FREE_SPACES,  // See how many free spaces there are to see if we should spawn more
				CREATE_RISER,       // Create a riser at a random position.

				MAKE_MOVABLE,		// Clear the unmovable flag. this event is only created when the flag clearing doesnt
									// coincide with a PL_UPDATE_POS event. (arg1 = playerNum)

				PLAY_GAME_OVER_SOUND,
				PLAY_ZAP_SOUND,
				PLAY_SLIDE_SOUND,
				PLAY_ROLL_END_SOUND,
				PLAY_SINK_SOUND,
				PLAY_LEVELUP_SOUND,
				PLAY_OUCH_SOUND};  // These events will only be in the list for 1 cycle
                                       // When the event should be fired, the event is created
									   // Next GameLoop, the event is deleted
				//PLAYER_DEATH  // Future use: Player is dying
struct GamePos
{
	GamePosState state; // FREE, OCCUPIED, ...
	int dieState;       // 0-24, orientation of die
	bool flag;          // Used in searches, to check for sinkers. Cleared every frame
	float y;			// Added pretty late. Movement needs to know the Y value
						// of sinkers and risers, so force CDiceGame to calculate it.
						// instead of the renderer
	int chains;			// Added in really late. Everytime this die is stolen, the chain
						// number is incremented. All chained sinkers should (I hope)
						// always have the samew chain value. This lets me know how many
						// chains the player has completed, so I can compute score multiplier
	bool unmovable[5];  // Flag array for fixing movement conflicts. If a position has any of these flags set to true
						// then the position cant have a die moved to/from it. This is to prevent players from
						// moving dice that other players are trying to move to already.

	//TODO: Add Die types - metal (doesnt move), stone (doesnt slide), wood(always rolls), ice(slides forever)
};

// used for building lists of sinkers and free spots.
struct Position
{
	int x;
	int y;
};

struct Event
{
	int what; // What event is this? ex: RISE,SINK,SLIDE,CHANGE...
	DWORD when; // Time this will happen or end (if event is in list, it has started)
	int boardX,boardY; // Position on board, where this is happening.
	int arg1,arg2;  // Arguments, depending on what event
					// Ex:
					// Roll event needs the die state, and player # that is controlling the roll.
	// May need arg3 - PLayer in/out of control
	//   			   Type of Die being moved (for graphic)
};

struct Player
{
	int boardX, boardY; // Players position on the gameboard
	                    // Position of player in world coords is calculated by renderer
	int score;  // Used by some game types
	int health; // Used by some game types
	bool idle;  // Flag - is the player idle?
	            // Used for movement input, and in rendering 
				//   (if player is idle, we need to render it)
				//   (otherwise, rendering info is in an event)
	Direction dir; // For input, the direction the player wants to go
				   // Also can be used for display
	Direction facing; // Usually the same as dir, but can never be NONE
	bool smashed; // This will be set to true if the player is squashed under a die
				  // The player will be treated as if they were on a free space, until they move
				  // to an adjacent free space


	unsigned int color; //this better be 32 bits...
	                    // The color of the player, in D3DCOLOR DWORD format
	                    // 0xAARRGGBB
	unsigned int diecolor; // The color of the player's sinking dice. 2 separate colors, so the player
						   // and their dice dont blend in together
	// Player offset, so not all players are in the exact center of the die.
	// TODO: PAck intoa struct maybe?
	float offsetX;
	//float offsetY;
	float offsetZ;

	bool AI; // True if the player is an AI, used by input

};

class CDiceGame
{
public:
	CDiceGame(){};
	CDiceGame(int gameType, int boardSize, int numPlayers);
	~CDiceGame(void);

	const CDiceGame &operator=(const CDiceGame &); // Assignment operator

	void Init(int gameType, int boardSize, int numPlayers);

	
	void CreateSlidSinkers(int x, int y, int playerNum); // Used to check sinkers caused by sliding a die
														 // Only does special behavior for 1's, otherwise uses CreateSinkers
	void CreateSinkers(int x, int y, int playerNum);
	void CreateSinkersHelper(int x, int y, GamePosState state);
	void GameLoop(DWORD dwElapsedTime);//, Direction *pPlayerInput);
	bool IsMovementValid(int playerNum, Direction dir);
	void MovePlayer(int playerNum);//, Direction dir);
	//void CheckCombos(int x, int y, int playerNum);
	bool IsMovable(int x, int y); // returns true if no 'unmovable' flags are set at the position

	int m_numSunk;  // How many dice we've sunk, total 
	int m_level;
	bool gameover;

	// Flag to let the program know if we're recording or running a script
	bool m_runningScript;
	bool m_recordingScript;

	int m_gameType; // type of game, for future use
	int m_boardSize; // Size of gameboard (size = width = height)
	int m_numPlayers; // Number of players
	GamePos **m_gameboard; // Array of GamePos's, for gameboard
	Player *m_players;
	Direction *m_oldDirections; // Used to see if we need to make new input events (for scripting)
	DWORD dwTime; // Class keeps its own Time value, using only ElapsedTime info from GameLoop
	DWORD m_numUpdates;
	int m_transTable[24][4]; // Transition table for rolling dice
							 // this relies on the 4 directions being numbered 0-3...
	vector<Event> m_vEvents; // the main event list
							 // TODO: Break this into several lists for different event types
							 // to make list scanning faster
	vector<Event> m_vTempEvents; // Temporary list of events. Filled while processing 
	                             // the main event list, so new events arent processed
								 // this loop. Used for sound events, so they survive 
								 // until the main Render() call

	vector<Position> m_vPosList; // Lists of free spots, or potential sinkers.

	HANDLE m_hMutex; // Now the class is definately not platform independant...

};
