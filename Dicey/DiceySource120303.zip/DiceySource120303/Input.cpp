// Input functions
// Init DInput, set up devices, choose devices, get input, configure player input. Fun stuffs

// TODO: I'm already using windows messages to track the keyboard state,
// so, why use DirectInput? I guess, I'll be using it anyways for joysticks,
// so why not? I dunno... hmm.

#include <windows.h>
#include <dinput.h>
#include <vector>
#include "DiceGame.h"
#include "Input.h"
#include "AI.h"
using namespace std;


extern CDiceGame *g_pGame;
extern AI **g_AIplayers;

PLAYERCONFIG g_playerConfig[5];

LPDIRECTINPUT8  g_lpDI; 
//vector<LPDIRECTINPUTDEVICE8>  g_vlpDIDevices ;

// Vector full of DI devices. Will be filled by EnumDevices
vector<DIDEVICEINFO> g_vDIDevInfo;

BOOL CALLBACK DIEnumDevicesCallback(LPCDIDEVICEINSTANCE lpddi, LPVOID pvRef)
{
	DIDEVICEINFO tempDevInfo;

	tempDevInfo.Enum = *lpddi;
	tempDevInfo.Interface = NULL;

	g_vDIDevInfo.push_back(tempDevInfo);
	
	return DIENUM_CONTINUE ;
}

HRESULT InitDI(HINSTANCE hInst, HWND hWnd)
{
	LPDIRECTINPUTDEVICE8  lpDIDevice;


	if(FAILED(DirectInput8Create(hInst, DIRECTINPUT_VERSION, IID_IDirectInput8, (void**)&g_lpDI, NULL)))
	{
		printf("InitDI failed: %i\n", GetLastError());
		return E_FAIL;
	}

	if(FAILED(g_lpDI->EnumDevices(DI8DEVCLASS_ALL, DIEnumDevicesCallback, NULL, DIEDFL_ATTACHEDONLY)))
	{
		printf("g_lpDI->EnumDevices failed: %i\n", GetLastError());
		return E_FAIL;
	}

	// Scan devices, remove devices that wont work well (mouse),
	// create device interfaces, and set cooperative level and everything
	for(int i = 0; i < (int)g_vDIDevInfo.size(); i++)
	{
		printf("Device Type: %i\n",g_vDIDevInfo[i].Enum.dwDevType);
		if ((g_vDIDevInfo[i].Enum.dwDevType & DI8DEVTYPE_KEYBOARD) == DI8DEVTYPE_KEYBOARD)
		{
			printf("Device is a keyboard\n");

			// Create the keyboard device
			if (FAILED(g_lpDI->CreateDevice(g_vDIDevInfo[i].Enum.guidInstance, &lpDIDevice, NULL))) 
			{
				printf("Failed to create keyboard DI Device interface: %i",  GetLastError());
				return E_FAIL;
			} 
			// Store interface pointer
			g_vDIDevInfo[i].Interface = lpDIDevice;

			// Set the keyboard device's data format
			if(FAILED(lpDIDevice->SetDataFormat(&c_dfDIKeyboard)))
			{
				printf("Failed to set keyboard device's data format: %i\n", GetLastError());
				return E_FAIL;
			}

			if(FAILED(lpDIDevice->SetCooperativeLevel(hWnd, DISCL_BACKGROUND | DISCL_NONEXCLUSIVE)))
			{
				printf("Failed to set keyboard device's cooperative level: %i\n", GetLastError());
				return E_FAIL;
			}
			
			lpDIDevice->Acquire();
			

			// Save this interface in our vector
			//g_vlpDIDevices.push_back(lpDIDevice);
		}
		else if((g_vDIDevInfo[i].Enum.dwDevType & DI8DEVTYPE_MOUSE) == DI8DEVTYPE_MOUSE)
		{
			printf("Device is a mousey, removing from list\n");
			g_vDIDevInfo.erase(g_vDIDevInfo.begin() + i);
			i--;
		}
		else if(((g_vDIDevInfo[i].Enum.dwDevType & DI8DEVTYPE_JOYSTICK) == DI8DEVTYPE_JOYSTICK) ||
			    ((g_vDIDevInfo[i].Enum.dwDevType & DI8DEVTYPE_GAMEPAD) == DI8DEVTYPE_GAMEPAD))
		{
			printf("Device is a Joystick or gamepad\n");

			// Create the joystick device
			if (FAILED(g_lpDI->CreateDevice(g_vDIDevInfo[i].Enum.guidInstance, &lpDIDevice, NULL))) 
			{
				printf("Failed to create joystick DI Device interface: %i",  GetLastError());
				return E_FAIL;
			} 

			g_vDIDevInfo[i].Interface = lpDIDevice;

			// Set the joystick device's data format
			if(FAILED(lpDIDevice->SetDataFormat(&c_dfDIJoystick2)))
			{
				printf("Failed to set joystick device's data format: %i\n", GetLastError());
				return E_FAIL;
			}

			if(FAILED(lpDIDevice->SetCooperativeLevel(hWnd, DISCL_BACKGROUND | DISCL_NONEXCLUSIVE)))
			{
				printf("Failed to set joystick device's cooperative level: %i\n", GetLastError());
				return E_FAIL;
			}
			
			g_vDIDevInfo[i].Caps.dwSize = sizeof(DIDEVCAPS);
			if (FAILED(g_vDIDevInfo[i].Interface->GetCapabilities(&g_vDIDevInfo[i].Caps)))
			{
				printf("GetCaps failed: %i\n", GetLastError());
				return E_FAIL;
			}
			lpDIDevice->Acquire();
			// Save this interface in our vector
			//g_vlpDIDevices.push_back(lpDIDevice);
		}
		/*else if((g_vDIDevices[i].dwDevType & DI8DEVTYPE_GAMEPAD) == DI8DEVTYPE_GAMEPAD)
		{
			printf("Device is a gamepad\n");

			// Create the gamepad device
			if (FAILED(g_lpDI->CreateDevice(g_vDIDevices[i].guidInstance, &lpDIDevice, NULL))) 
			{
				printf("Failed to create gamepad DI Device interface: %i",  GetLastError());
				return E_FAIL;
			} 

			// Set the gamepad device's data format
			// Using &c_dfDIJoystick2? I hope this works. Maybe I need to buy a gamepad
			if(FAILED(lpDIDevice->SetDataFormat(&c_dfDIJoystick2)))
			{
				printf("Failed to set gamepad device's data format: %i\n", GetLastError());
				return E_FAIL;
			}

			if(FAILED(lpDIDevice->SetCooperativeLevel(hWnd, DISCL_BACKGROUND | DISCL_NONEXCLUSIVE)))
			{
				printf("Failed to set gamepad device's cooperative level: %i\n", GetLastError());
				return E_FAIL;
			}
			
			// Save this interface in our vector
			g_vlpDIDevices.push_back(lpDIDevice);
		}*/
		else
		{
			printf("Device is something else, removing from list\n");
			g_vDIDevInfo.erase(g_vDIDevInfo.begin() + i);
			i--;
		}
	}
 
	// TODO: Remove me later, when the front end cant let the user pick devices
	g_playerConfig[0].device = 0;
	g_playerConfig[0].up = DIK_UP;
	g_playerConfig[0].down = DIK_DOWN;
	g_playerConfig[0].left = DIK_LEFT;
	g_playerConfig[0].right  = DIK_RIGHT;
	g_playerConfig[1].device = 0;
	g_playerConfig[1].up = DIK_W;
	g_playerConfig[1].down = DIK_S;
	g_playerConfig[1].left = DIK_A;
	g_playerConfig[1].right  = DIK_D;
	g_playerConfig[2].device = -1;
	g_playerConfig[3].device = -1;
	g_playerConfig[4].device = -1;
	
	return S_OK;
}

HRESULT DICleanup()
{
	// Clean up all our devices
	while(g_vDIDevInfo.size() > 0)
	{
		if(g_vDIDevInfo[g_vDIDevInfo.size()-1].Interface != NULL)
		{
			// Unacquire the device
			g_vDIDevInfo[g_vDIDevInfo.size()-1].Interface->Unacquire();

			// Release
			g_vDIDevInfo[g_vDIDevInfo.size()-1].Interface->Release();
		}
		g_vDIDevInfo.pop_back();
	}

	if(g_lpDI != NULL)
		g_lpDI->Release();

	
	return S_OK;
}

// Function to get input data for all players
HRESULT DIGetInput(Direction *plDirections) // We better get an array of 5 directions
{
	int i;
	long x, y;
	unsigned char keystates[256];

	// Update state for all the devices
	for(i = 0; i < (int)g_vDIDevInfo.size(); i++)
	{
		if ((g_vDIDevInfo[i].Enum.dwDevType & DI8DEVTYPE_KEYBOARD) == DI8DEVTYPE_KEYBOARD)
		{
			// Get keyboard state
			if (FAILED(g_vDIDevInfo[i].Interface->GetDeviceState(sizeof(unsigned char[256]), keystates)))
			{
				printf("Keyboard GetDeviceState failed: %i\n", GetLastError());
				return E_FAIL; // bail out!!
			}
		}
		else // Otherwise, this is a joystick/gamepad
		{
			if (NULL == g_vDIDevInfo[i].Interface) 
			{
				printf("Trouble: Using a joystick interface that hasnt been created\n");
				continue;
			}

			// Because we're using BACKGROUND cooperation level, we
			// shouldnt lose the device. Check just in case
			// Dont return error, we may not even be using this device
			if(FAILED(g_vDIDevInfo[i].Interface->Poll()))
			{
				printf("Trouble: Joystick access was lost\n");
				continue;
			}
			//printf("ping!\n");
			if (FAILED(g_vDIDevInfo[i].Interface->GetDeviceState(sizeof(DIJOYSTATE2), &g_vDIDevInfo[i].State)))
			{
				printf("Joystick GetDeviceState failed: %i\n", GetLastError());
				return E_FAIL; // bail out!!
			}


		}

	}

	// For every player, check the device they're using
	for(int i = 0; i < 5 && i < g_pGame->m_numPlayers; i++)
	{
		if(g_pGame->m_players[i].AI && g_pGame->m_players[i].idle) // The player is an AI, let the AI class handle it
		{
			plDirections[i] = g_AIplayers[i]->GetDirection();
		}
		else if(g_playerConfig[i].device == -1)
		{
			plDirections[i] = NONE;
			continue;
		}
		else if ((g_vDIDevInfo[g_playerConfig[i].device].Enum.dwDevType & DI8DEVTYPE_KEYBOARD) == DI8DEVTYPE_KEYBOARD)
		{
			//for(int j = 0; j < 256; j++)
			//{
			//	if(keystates[j] & 0x80)
			//		printf("Keydown: %i\n",j);
			//}
			
			if(keystates[g_playerConfig[i].up] & 0x80)
				plDirections[i] = UP;
			else if(keystates[g_playerConfig[i].down])
				plDirections[i] = DOWN;
			else if(keystates[g_playerConfig[i].left])
				plDirections[i] = LEFT;
			else if(keystates[g_playerConfig[i].right])
				plDirections[i] = RIGHT;
			else 
				plDirections[i] = NONE;
		}
		else // Joystick/Gamepad
		{
			// For X,Y values:
			// 0,0 is upper left; 65536, 65536 is lower right
			x = g_vDIDevInfo[g_playerConfig[i].device].State.lX;
			y = g_vDIDevInfo[g_playerConfig[i].device].State.lY;

			// Using a dead zone of 10000 units
			// TODO: Make adjustable
			if(x > 27768 && x < 37768
				&& y > 27768 && y < 37768)
				plDirections[i] = NONE; // In dead zone
			else if(x > y && y <= (-x+65536)) // UP
				plDirections[i] = UP;
			else if(x <= y && y >(-x+65536)) // DOWN
				plDirections[i] = DOWN;
			else if(x <= y && y <=(-x+65536)) // Left
				plDirections[i] = LEFT;
			else if(x > y && y > (-x+65536)) // RIGHT
				plDirections[i] = RIGHT;

			// Debug
			/*switch(plDirections[i])
			{
			case UP:
				printf("Joystick: UP\n");
				break;
			case DOWN:
				printf("Joystick: DOWN\n");
				break;
			case LEFT:
				printf("Joystick: LEFT\n");
				break;
			case RIGHT:
				printf("Joystick: RIGHT\n");
				break;
			case NONE:
				printf("Joystick: NONE\n");
			}*/
			//printf("Joystick: %i %i %i\n", g_vDIDevInfo[g_playerConfig[i].device].State.lX, g_vDIDevInfo[g_playerConfig[i].device].State.lY, g_vDIDevInfo[g_playerConfig[i].device].State.rglSlider[0]); 
			
		}
	}
	return S_OK;
}

HRESULT ChangePlayerDevice(int playerNum, int deviceIndex)
{
	g_playerConfig[playerNum].device = deviceIndex;
	return S_OK;
}

// Return the first key it finds beinh held down, or 255 for no key
// Keyboard device better be device #0...
unsigned char GetKey()
{
	static unsigned char lastKey; // 
	unsigned char tempKey = 255;

	unsigned char keystates[256];

	// Get keyboard state
	if (FAILED(g_vDIDevInfo[0].Interface->GetDeviceState(sizeof(unsigned char[256]), keystates)))
	{
		printf("Keyboard GetDeviceState failed: %i\n", GetLastError());
		return 255;
	}

	for(int i = 0; i < 256; i++)
	{
		if(keystates[i])
		{
			tempKey = i;
			break;
		}
	}

	if(lastKey == 255)
	{
		lastKey = tempKey;
		return lastKey;
	}
	else
		lastKey = tempKey;


	return 255;
}