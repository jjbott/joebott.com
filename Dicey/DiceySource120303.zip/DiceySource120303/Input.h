#include <dinput.h>

// Struct that hold info about what device the player is using
struct PLAYERCONFIG
{
	int device; // The index of the device in the g_vDIDevInfo vector
				// -1 == No device selected
	
	// Index of keyboard state that will control the player
	// used for keyboard devices only. 
	// Yeah, I'm wasting a little space, its 4 bytes, get over it. :P
	unsigned char up;
	unsigned char down;
	unsigned char left;
	unsigned char right;
};

// struct that will hold the data returned from 
// EnumDevices, CreateDevice, and GetDevCaps
struct DIDEVICEINFO // Bah, I couldnt think of a good name
{
	DIDEVICEINSTANCE Enum; // I'll end up using this mostly for names
	LPDIRECTINPUTDEVICE8 Interface; //The main device interface
    DIDEVCAPS Caps; // Wont be used by keyboard, but thats okay I guess.

	DIJOYSTATE2 State; // State of the joystick. Also wont be used by keyboard. Oh well!
};

HRESULT InitDI(HINSTANCE hInst, HWND hWnd);
HRESULT DICleanup();
HRESULT DIGetInput(Direction *plDirections);
HRESULT ChangePlayerDevice(int playerNum, int deviceIndex);
unsigned char GetKey(); // Return the first key it finds beinh held down, or 255 for no key
