// Functions fore loading and running a script. 
// This probably would be better in a class, doing it without for now

#include <windows.h>
#include <vector>
#include "ScriptEvents.h"
#include "RunScript.h"
#include "DiceGame.h"
#include "main.h"
using namespace std;

// The global CDiceGame
extern CDiceGame *g_pGame;

// TODO: Multiple vectors, one for each event type, doesnt seem very elegant...
vector<RiseEvent> g_vRiseEvents;
vector<InputUpdateEvent> g_vInputEvents;

// Load the script, and fill the event vectors
HRESULT LoadScript(char *filename)
{
	int i, j;
	int gameType;
	int boardSize;
	int numPlayers;
	unsigned char tempChar;
	int counter = 0; // temp, count the nunber of times we get through the loop
	unsigned char inputEventBuffer[20]; // temp, for debugging

	RiseEvent tempRiser;
	InputUpdateEvent tempInput;

	unsigned char eventType;

	// WE better not have a game created already...
	if(g_pGame != NULL)
		return E_FAIL;

	FILE *inStream;
	inStream = fopen(filename, "rb");
	if(inStream == NULL)
	{
		printf("Failed to open script \"%s\": %i\n", filename, GetLastError());
		return E_FAIL;
	}

	gameType = fgetc(inStream);
	boardSize = fgetc(inStream);
	numPlayers = fgetc(inStream);

	g_pGame = new CDiceGame;
	g_pGame->Init(gameType, boardSize, numPlayers);

	// Currently, the game Init will add 1 event, to start
	// dice spawning. We'll clear it so we have full control
	g_pGame->m_vEvents.clear();


	for(i = 0; i < g_pGame->m_boardSize; i++)
		for(j = 0; j < g_pGame->m_boardSize; j++)
		{
			tempChar = fgetc(inStream);
			if(tempChar == 0xF0)
				g_pGame->m_gameboard[i][j].state = FREE;
			else
			{
				g_pGame->m_gameboard[i][j].state = OCCUPIED;
				g_pGame->m_gameboard[i][j].dieState = tempChar;
			}		
		}

	if(fgetc(inStream) != EVENT_DELIMITER)
	{
		printf("Didnt get 0xFF after gamboard init\n");
		fclose(inStream);
		delete g_pGame;
		g_pGame = NULL;
		return E_FAIL;
	}

	// FIXME! Not robust
	// If stream ends in the middle of an event, I'm gonna crash
	while(!feof(inStream))
	{
		eventType=fgetc(inStream);

		counter++;
		switch(eventType)
		{
		case NEW_RISER:
			// Rebuild time
			tempRiser.dwTime = fgetc(inStream);
			tempRiser.dwTime += fgetc(inStream) << 8;
			tempRiser.dwTime += fgetc(inStream) << 16;
			tempRiser.dwTime += fgetc(inStream) << 24;

			tempRiser.x = fgetc(inStream);
			tempRiser.y = fgetc(inStream);

			tempRiser.mode = fgetc(inStream);
			g_vRiseEvents.push_back(tempRiser);

			if(fgetc(inStream) != EVENT_DELIMITER)
			{
				printf("Didnt get 0xFF after Riser event\n");
				fclose(inStream);
				delete g_pGame;
				g_pGame = NULL;

				return E_FAIL;
			}
			break;
		case INPUT_UPDATE:
			for(i = 0; i < 5 + numPlayers; i++)
			{
				inputEventBuffer[i] = fgetc(inStream);
				//printf("%x,", inputEventBuffer[i]);
			}
			//printf("\n");
			// Rebuild time
			tempInput.dwTime = inputEventBuffer[0];//fgetc(inStream);
			tempInput.dwTime += inputEventBuffer[1]<< 8;//fgetc(inStream) << 8;
			tempInput.dwTime += inputEventBuffer[2]<< 16;//fgetc(inStream) << 16;
			tempInput.dwTime += inputEventBuffer[3]<< 24;//fgetc(inStream) << 24;


			// using malloc scares me...
			tempInput.input = (char *)malloc(numPlayers * sizeof(char));

			// Get the input
			for(i = 0; i < numPlayers; i++)
			{
				tempInput.input[i] = inputEventBuffer[i+4];//fgetc(inStream);
				//printf("player input %i is %i ", i, tempInput.input[i]);
			}
			//printf("\n");

			// Store event
			if(tempInput.input[0] >= 0 && tempInput.input[0] <5)
				g_vInputEvents.push_back(tempInput);
			else
			{
				free(tempInput.input);
			}

			// Get the trailing 0xFF
			if(inputEventBuffer[4 + numPlayers] != EVENT_DELIMITER)//fgetc(inStream) != 0xFF)
			{
				printf("Didnt get 0xFF after Input event\n");
				printf("Time: %x Counter: %i\n",tempInput.dwTime, counter );
				fclose(inStream);
				delete g_pGame;
				g_pGame = NULL;
				return E_FAIL;
			}
			break;
		default:
			break;
		}

	}

	printf("Loaded %i events\n", counter);
	fclose(inStream);

	return S_OK;
}

// This function interacts directly with the CDiceGame 
// pointed to at g_pGame. Every call to g_pGame->GameLoop
// will call RunScript(). This function will create events based on
// how much time has elapsed
HRESULT RunScript()
{
	//printf("RunScript called\n");
	int i,j;
	Event tempEvent;

	//Scan through input events;
	for(i = 0; i< (int)g_vInputEvents.size(); i++)
	{
		//printf("%i %i\n", g_vInputEvents[i].dwTime, g_pGame->m_numUpdates);
		if(g_vInputEvents[i].dwTime == g_pGame->m_numUpdates)
		{
			// Update the players' inputs
			for(j = 0; j<g_pGame->m_numPlayers; j++)
			{
				//printf("%i\n", j);
				g_pGame->m_players[j].dir = (Direction)g_vInputEvents[i].input[j];
			}
			
			// Free the memory we allocated
			free(g_vInputEvents[i].input);
			// erase this event
			g_vInputEvents.erase(g_vInputEvents.begin() + i);
			i--;
			//printf("%i\n", i);
		}
		else // If we're here, then we can stop scanning, since the event list is sorted
			break;
	}

	//Scan through rise events;

	for(i = 0; i< (int)g_vRiseEvents.size(); i++)
	{
		if(g_vRiseEvents[i].dwTime == g_pGame->m_numUpdates)
		{
			//printf("%i ping!\n", g_vRiseEvents.size());
			if(g_pGame->m_gameboard[g_vRiseEvents[i].x][g_vRiseEvents[i].y].state != FREE)
			{
				printf("Runscript Error: Rise event\n Position isnt free at %i, %i\n", g_vRiseEvents[i].x,g_vRiseEvents[i].y);
			}
			g_pGame->m_gameboard[g_vRiseEvents[i].x][g_vRiseEvents[i].y].state = RISING;
				
			// Make riser event
				tempEvent.what = PLAY_ZAP_SOUND;
				tempEvent.when = 0;
				tempEvent.boardX = g_vRiseEvents[i].x;
				tempEvent.boardY = g_vRiseEvents[i].y;
				g_pGame->m_vTempEvents.push_back(tempEvent);

				// Make riser event
				tempEvent.what = RISE;
				tempEvent.when = g_pGame->dwTime+RISE_TIME;
				tempEvent.boardX = g_vRiseEvents[i].x;
				tempEvent.boardY = g_vRiseEvents[i].y;
				tempEvent.arg1 = g_vRiseEvents[i].mode;
				g_pGame->m_vEvents.push_back(tempEvent);
				
				// Make State Change event
				tempEvent.what = CHANGE_STATE;
				tempEvent.when = g_pGame->dwTime+RISE_TIME;
				tempEvent.boardX = g_vRiseEvents[i].x;
				tempEvent.boardY = g_vRiseEvents[i].y;
				tempEvent.arg2 = g_vRiseEvents[i].mode;
				tempEvent.arg1 = OCCUPIED;
				g_pGame->m_vEvents.push_back(tempEvent);
			// Create Riser event
			//tempEvent.what = RISE;
			//tempEvent.when = g_vRiseEvents[i].dwTime;
			//tempEvent.boardX = g_vRiseEvents[i].x;
			//tempEvent.boardY = g_vRiseEvents[i].y;
			//tempEvent.arg1 = g_vRiseEvents[i].mode;
			//g_pGame->m_vEvents.push_back(tempEvent);
			
			// erase this event
			g_vRiseEvents.erase(g_vRiseEvents.begin() + i);
			i--;
		}
		else // If we're here, then we can stop scanning, since the event list is sorted
			break;
	}

	return S_OK;
}