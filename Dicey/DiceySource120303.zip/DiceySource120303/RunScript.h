#include <windows.h>

struct RiseEvent
{
	DWORD dwTime;
	int x;
	int y;
	int mode;
};

struct InputUpdateEvent
{
	DWORD dwTime;
	char *input;
};

HRESULT LoadScript(char *filename);

HRESULT RunScript();