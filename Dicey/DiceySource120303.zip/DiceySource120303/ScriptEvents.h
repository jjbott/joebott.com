// This is just a list of Script events
// NOTE: There cant be more than 256 different events, I'm storing them as a char
enum ScriptEvent { NEW_RISER,   // Create a new sinker event 
				   INPUT_UPDATE  // Update player input
};

#define  EVENT_DELIMITER 0xF0