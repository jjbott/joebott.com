;
#include <vector>
#include <stdio.h>
#include "brain.h"
#include "DiceGame.h"
using namespace std;

extern CDiceGame *g_pGame; // The main CDiceGame
extern CBrain *g_pBrain; // Needed for thread entry point


CBrain::CBrain()
{
	int i,j;

	if(g_pGame != NULL) // if the game doesnt exist, I'm in trouble...
	{
		//vector<Path> **m_gamepaths;
		m_gamepaths = (vector<Path> ***)malloc(g_pGame->m_boardSize * sizeof(vector<Path> **));
		for(i = 0; i < g_pGame->m_boardSize; i++)
		{
			m_gamepaths[i] = (vector<Path> **)malloc(g_pGame->m_boardSize * sizeof(vector<Path> *));
		}

		for(i = 0; i < g_pGame->m_boardSize; i++)
			for(j = 0; j < g_pGame->m_boardSize; j++)
			{
				m_gamepaths[i][j] = new vector<Path>;
			}


			/*
		// Create the array of Mutex handles
		m_mutexHandles = (HANDLE **)malloc(g_pGame->m_boardSize * sizeof(HANDLE *));
		for(i = 0; i < g_pGame->m_boardSize; i++)
		{
			m_mutexHandles[i] = (HANDLE *)malloc(g_pGame->m_boardSize * sizeof(HANDLE));
		}
		for(i = 0; i < g_pGame->m_boardSize; i++)
			for(j = 0; j < g_pGame->m_boardSize; j++)
			{
				m_mutexHandles[i][j] = CreateMutex(NULL, false, NULL);
			}
			*/

		m_game.Init(g_pGame->m_gameType, g_pGame->m_boardSize, g_pGame->m_numPlayers);

		m_wantDump = false;

		m_wantPathInfo = false;

	}
	else
		printf("Big trouble: Brain created while g_pGame doesnt exist!\n");
}

CBrain::~CBrain()
{
	int i,j;

	m_runThread = false;
	Sleep(500); // FIXME! I'm waiting for the thread to exit


	if(g_pGame != NULL) // Again, big trouble if main game doesnt exist
						// This is fixable though. So, FIXME!
	{
		for(i = 0; i < g_pGame->m_boardSize; i++)
			for(j = 0; j < g_pGame->m_boardSize; j++)
			{
				delete m_gamepaths[i][j];
			}
		
		/*for(i = 0; i < g_pGame->m_boardSize; i++)
			for(j = 0; j < g_pGame->m_boardSize; j++)
			{
				WaitForSingleObject(m_mutexHandles[i][j], INFINITE);
				ReleaseMutex(m_mutexHandles[i][j]);
				CloseHandle(m_mutexHandles[i][j]);
			}

		for(int i = 0; i < g_pGame->m_boardSize; i++)
			free(m_mutexHandles[i]);
		free(m_mutexHandles);*/

		for(int i = 0; i < g_pGame->m_boardSize; i++)
			free(m_gamepaths[i]);
		free(m_gamepaths);
	}

}

// The brain thread - will search and build paths for the AI players
void CBrain::PathThread()
{
	//printf("Starting PathThread()\n");
	//CDiceGame game;
	int i,j,k;
	static int lastNumMovable;
	int numMovable = 0; // Just for testing...

	// Make a copy of the main game
	m_game = *g_pGame;

	if(m_wantDump)
	{
		m_wantDump = false;
		DumpPaths();
	}
	
	// FIXME! Right now I'm only looking for rolling paths
	// Sliding paths will be much harder (if I do complex sliding paths),
	// so I'm saving that for later
	for(i = 0; i < m_game.m_boardSize && m_runThread; i++)
		for(j = 0; j < m_game.m_boardSize && m_runThread; j++)
		{
			//WaitForSingleObject(m_mutexHandles[i][j], INFINITE);
			m_sPath.clear(); // Clear the path endpoint list
			/*
			if(IsRollable(i,j)) // Is the die rollable?
			{
				//if(i == 0 && j == 0)
				//	printf("0,0 is rollable\n");
				numMovable++;
				// Check existing paths to see if theyre still good.
				for(k = 0; k < (int)m_gamepaths[i][j]->size(); k++)
				{
					//printf("%i %i %i\n", i, j, m_gamepaths[i][j]->size());
					
					if(IsRollingPathValid(i,j,&(*m_gamepaths[i][j])[k]))
					{
						if(m_sPath.find( ((*m_gamepaths[i][j])[k].final_x<<16)
							            +((*m_gamepaths[i][j])[k].final_y<<8)
										+(*m_gamepaths[i][j])[k].die_state) != m_sPath.end())
						{
							printf("found a duplicate\n");
							m_gamepaths[i][j]->erase(m_gamepaths[i][j]->begin() + k);
							k--;
						}
						else
						{						
							// insert the encoded path endpoint into the set
							m_sPath.insert(  ((*m_gamepaths[i][j])[k].final_x<<16)
											+((*m_gamepaths[i][j])[k].final_y<<8)
											+(*m_gamepaths[i][j])[k].die_state);
							//printf("Inserting %i\n",((*m_gamepaths[i][j])[k].final_x<<16)
							//	            +((*m_gamepaths[i][j])[k].final_y<<8)
							//				+(*m_gamepaths[i][j])[k].die_state);
							//TODO: recompute score, in case it has changed
							(*m_gamepaths[i][j])[k].score = ComputeScore((*m_gamepaths[i][j])[k].final_x,(*m_gamepaths[i][j])[k].final_y,(*m_gamepaths[i][j])[k].die_state/4, (*m_gamepaths[i][j])[k].path);
							(*m_gamepaths[i][j])[k].volatility++; // Increase volatility rating
						}
					}
					else // path no longer valid, erase it from list
					{
						//printf("Killing path\n");
						m_gamepaths[i][j]->erase(m_gamepaths[i][j]->begin() + k);
						k--;
					}
				}
				*/
				m_gamepaths[i][j]->clear();
				//m_sPath.clear();
				FindRollingPaths(i,j);

				//ReleaseMutex(m_mutexHandles[i][j]);
			//}
			//else // not rollable
			//	m_gamepaths[i][j]->clear();
		}

		//if(lastNumMovable!=numMovable)
		//	printf("Num Rollable: %i\n", numMovable);
		lastNumMovable = numMovable;

	
}

bool CBrain::IsRollable(int x, int y)
{

	int nx,ny,i;
	// We're only converned with rollable dice, so if the position isnt
	// OCCUPIED, its not rollable.
	if(m_game.m_gameboard[x][y].state != OCCUPIED)
		return false;

	// Move player 1 to where we want to test. This might be trouble, but we'll see...
	m_game.m_players[0].boardX = x;
	m_game.m_players[0].boardY = y;

	for(i = 0; i < 5; i++)
	{
		nx = x; ny = y;
		switch(i)
		{
		case LEFT:
			nx=x-1;
			break;
		case RIGHT:
			nx=x+1;
			break;
		case UP:
			ny=y-1;
			break;
		case DOWN:
			ny=y+1;
			break;
		default:
			return false; // Something isnt right 
		}
		if(   nx <0 || nx >= m_game.m_boardSize
			||ny <0 || ny >= m_game.m_boardSize)
			continue; //this is a bad direction

		if(m_game.m_gameboard[nx][ny].state == FREE)
			return true;
		else if (m_game.m_gameboard[nx][ny].state == RISING && m_game.m_gameboard[nx][ny].y <= .5)
			return true;
		else if (m_game.m_gameboard[nx][ny].state == SINKING && m_game.m_gameboard[nx][ny].y <= .5)
			return true;
	}

	return false;
}

// This will find all rolling paths leading from x,y that end in a match
// TODO: This will happily roll over sinking dice, and then except to
// match with them. Not sure how I can fix this though... 
void CBrain::FindRollingPaths(int x, int y)
{
	int i,j,nx,ny;
	int oldLength, oldDieState, oldX, oldY; // Some temp vars 
	//int path[MAX_PATH_LEN];
	//int tempPos; // temporary path position (x<<16) + ( y<<8) + direction
	int key; // the path's position key: (x<<16) + ( y<<8) + diestate
	int score;
	Path tempPath; // a temporary path, for filling the vector
	vector<Path> vSearchPaths; // A vector of all the paths that we're working on
							   // Good paths still get put into m_gamepaths[x][y]

	// If this spot isnt occupied, I shouldnt even be here. 
	// But I'll check anyways
	if(m_game.m_gameboard[x][y].state != OCCUPIED)
	{
		// There cant be any paths from here, so clear them
		m_gamepaths[x][y]->clear();
		return;
	}

	for(i = 0; i<MAX_PATH_LEN;i++)
		tempPath.path[i] = (int)NONE;

	score = ComputeScore(x,y,m_game.m_gameboard[x][y].dieState/4,tempPath.path);// oldPath);
	if(score >= (m_game.m_gameboard[x][y].dieState/4 +1) * (m_game.m_gameboard[x][y].dieState/4 +1))
	{ // Score is >= the dievalue squared, so a set would be completed.
	  // Adjust so we can roll athe die back and forth here

		// temporarily make this space FREE, so paths can end here
		m_game.m_gameboard[x][y].state = FREE;
	}

	

	for(i = 0; i < 4; i++)
	{
		nx = x; ny = y;
		switch(i)
		{
		case LEFT:
			nx=x-1;
			break;
		case RIGHT:
			nx=x+1;
			break;
		case UP:
			ny=y-1;
			break;
		case DOWN:
			ny=y+1;
			break;
		default:
			continue; // Something isnt right 
		}
		if(   nx <0 || nx >= m_game.m_boardSize
			||ny <0 || ny >= m_game.m_boardSize)
			continue; //this is a bad direction
		//path[0] = (nx<<16)+(ny<<8)+i;
		tempPath.path[0] = (nx<<16)+(ny<<8)+i;
		tempPath.length = 1;
		tempPath.final_x = nx;
		tempPath.final_y = ny;

		if(m_game.m_gameboard[nx][ny].state == FREE)
		{
			tempPath.die_state = m_game.m_transTable[m_game.m_gameboard[x][y].dieState][i];
			vSearchPaths.push_back(tempPath);
		}
			//FindRollingPathsHelper(x,y,nx, ny, m_game.m_transTable[m_game.m_gameboard[x][y].dieState][i], path, 1);
		else if (m_game.m_gameboard[nx][ny].state == RISING && m_game.m_gameboard[nx][ny].y <= .5)
		{
			tempPath.die_state = m_game.m_transTable[m_game.m_gameboard[x][y].dieState][i];
			vSearchPaths.push_back(tempPath);
		}
			//FindRollingPathsHelper(x,y,nx, ny, m_game.m_transTable[m_game.m_gameboard[x][y].dieState][i], path, 1);
		else if (m_game.m_gameboard[nx][ny].state == SINKING && m_game.m_gameboard[nx][ny].y <= .5)
		{
			tempPath.die_state = m_game.m_transTable[m_game.m_gameboard[x][y].dieState][i];
			vSearchPaths.push_back(tempPath);
		}
			//FindRollingPathsHelper(x,y,nx, ny, m_game.m_transTable[m_game.m_gameboard[x][y].dieState][i], path, 1);
	}

	while(vSearchPaths.size() > 0)
	{
		if(m_wantPathInfo && x == m_dumpX && y == m_dumpY)
			printf("vSearchPaths.size() = %i\n", vSearchPaths.size());

		for(i = 0; i < (int)vSearchPaths.size(); i++)
		{
			for(j = 0; j < MAX_PATH_LEN; j++)
				tempPath.path[j] = vSearchPaths[i].path[j];
			tempPath.die_state = vSearchPaths[i].die_state;
			tempPath.final_x = vSearchPaths[i].final_x;
			tempPath.final_y = vSearchPaths[i].final_y; 
			tempPath.length = vSearchPaths[i].length; 
			
			//tempPath = vSearchPaths[i]; // Get the Path we're working on...

			key= (tempPath.final_x<<16) +(tempPath.final_y<<8) +tempPath.die_state;

			if(m_wantPathInfo && x == m_dumpX && y == m_dumpY)
				printf("set search info: key: %x find %i, end %i\n", key, m_sPath.find(key), m_sPath.end());

			if(m_sPath.find(key) != m_sPath.end())
			{
				if(m_wantPathInfo && x == m_dumpX && y == m_dumpY)
					printf("found key %x\n", key);
				
				vSearchPaths.erase(vSearchPaths.begin() + i);
				i--;
				continue;
				//return; // We've already been here before.
			}
			else
			{
				if(m_wantPathInfo && x == m_dumpX && y == m_dumpY)
					printf("inserting key %x, size is now %i\n", key, m_sPath.size());

				m_sPath.insert(key); // And now we wont come back here.
			}

			score = ComputeScore(tempPath.final_x,tempPath.final_y,tempPath.die_state/4,vSearchPaths[i].path);// oldPath);
			if(score > 0)
			{
				//printf("Found a path, with score of %i!\n", score);
				//tempPath.die_state = dieState; // store die state
				//tempPath.final_x = x;
				//tempPath.final_y = y;
				tempPath.gametime = m_game.dwTime;
				tempPath.score = score;
				tempPath.volatility = 0;
				//for(i = 0; i < MAX_PATH_LEN; i++)
				//{
				//	tempPath.path[i] = oldPath[i];
				//}

				m_gamepaths[x][y]->push_back(tempPath);
				
				if(m_wantPathInfo && x == m_dumpX && y == m_dumpY)
				{
					printf("----pushing path with key: %x Size is %i\n", key, m_gamepaths[x][y]->size());
					printf("----X: %i Y: %i State: %i\n", tempPath.final_x,tempPath.final_y,tempPath.die_state);
				}
			
			}

			if(score >= (tempPath.die_state/4 +1) * (tempPath.die_state/4 +1))
			{ // We completed a set, so this path has to end - the die will tuirn into an unrollable sinker
				vSearchPaths.erase(vSearchPaths.begin() + i);
				i--;
				continue;
			}


			if(tempPath.length>=MAX_PATH_LEN)
			{
				vSearchPaths.erase(vSearchPaths.begin() + i);
				i--;
				continue;
				//return; // We're at maximum depth.
			}

			//for(i = 0; i < MAX_PATH_LEN; i++)
			//	path[i] = oldPath[i];

			oldLength = tempPath.length;
			tempPath.length++;
			oldDieState = tempPath.die_state;
			oldX = tempPath.final_x;
			oldY = tempPath.final_y;

			for(j = 0; j < 4; j++)
			{
				nx = oldX; ny = oldY;
				switch(j)
				{
				case LEFT:
					nx--;
					break;
				case RIGHT:
					nx++;
					break;
				case UP:
					ny--;
					break;
				case DOWN:
					ny++;
					break;
				default:
					continue; // Something isnt right 
				}
				if(   nx <0 || nx >= m_game.m_boardSize
					||ny <0 || ny >= m_game.m_boardSize)
					continue; //this is a bad direction

				tempPath.path[oldLength] = (nx<<16)+(ny<<8)+j;
				tempPath.final_x = nx;
				tempPath.final_y = ny;

				if(m_game.m_gameboard[nx][ny].state == FREE)
				{
					//printf("ping!\n");
					tempPath.die_state = m_game.m_transTable[oldDieState][j];
					vSearchPaths.push_back(tempPath);
				}
					//FindRollingPathsHelper(startX, startY, nx, ny, m_game.m_transTable[dieState][i], path, Depth+1);
				else if (m_game.m_gameboard[nx][ny].state == RISING && m_game.m_gameboard[nx][ny].y <= .5)
				{
					tempPath.die_state = m_game.m_transTable[oldDieState][j];
					vSearchPaths.push_back(tempPath);
				}
				//FindRollingPathsHelper(startX, startY, nx, ny, m_game.m_transTable[dieState][i], path, Depth+1);
				else if (m_game.m_gameboard[nx][ny].state == SINKING && m_game.m_gameboard[nx][ny].y <= .5)
				{
					tempPath.die_state = m_game.m_transTable[oldDieState][j];
					vSearchPaths.push_back(tempPath);
				}
					//FindRollingPathsHelper(startX, startY, nx, ny, m_game.m_transTable[dieState][i], path, Depth+1);
			}

			// We've processed this path, erase it, and reset 'i' so we
			// check this potition again.
			vSearchPaths.erase(vSearchPaths.begin() + i);
			i--;
		}



	}

	// restore this state to OCCUPIED
	m_game.m_gameboard[x][y].state = OCCUPIED;
	
	return; // blah
}

void CBrain::FindRollingPathsHelper(int startX, int startY, int x,int y,int dieState, int *oldPath, int Depth)
{
	int i,nx,ny;
	int score;
	Path tempPath;
	int path[MAX_PATH_LEN];

	int key= (x<<16) +(y<<8) +dieState;

	if(m_wantPathInfo && startX == m_dumpX && startY == m_dumpY)
		printf("set search info: key: %x find %i, end %i\n", key, m_sPath.find(key), m_sPath.end());

	if(m_sPath.find(key) != m_sPath.end())
	{
		if(m_wantPathInfo && startX == m_dumpX && startY == m_dumpY)
			printf("found key %x\n", key);
		return; // We've already been here before.
	}
	else
	{
		if(m_wantPathInfo && startX == m_dumpX && startY == m_dumpY)
			printf("inserting key %x, size is now %i\n", key, m_sPath.size());

		m_sPath.insert(key); // And now we wont come back here.
	}

	score = ComputeScore(x,y,dieState/4,oldPath);
	if(score > 0)
	{
		//printf("Found a path, with score of %i!\n", score);
		tempPath.die_state = dieState; // store die state
		tempPath.final_x = x;
		tempPath.final_y = y;
		tempPath.gametime = m_game.dwTime;
		tempPath.score = score;
		tempPath.volatility = 0;
		for(i = 0; i < MAX_PATH_LEN; i++)
		{
			tempPath.path[i] = oldPath[i];
		}

		m_gamepaths[startX][startY]->push_back(tempPath);
		
		if(m_wantPathInfo && startX == m_dumpX && startY == m_dumpY)
		{
			printf("----pushing path with key: %x Size is %i\n", key, m_gamepaths[startX][startY]->size());
			printf("----X: %i Y: %i State: %i\n", x,y,dieState);
		}
	
	}

	if(Depth>=MAX_PATH_LEN)
		return; // We're at maximum depth.

	for(i = 0; i < MAX_PATH_LEN; i++)
		path[i] = oldPath[i];
	for(i = 0; i < 4; i++)
	{
		nx = x; ny = y;
		switch(i)
		{
		case LEFT:
			nx=x-1;
			break;
		case RIGHT:
			nx=x+1;
			break;
		case UP:
			ny=y-1;
			break;
		case DOWN:
			ny=y+1;
			break;
		default:
			return; // Something isnt right 
		}
		if(   nx <0 || nx >= m_game.m_boardSize
			||ny <0 || ny >= m_game.m_boardSize)
			continue; //this is a bad direction
		path[Depth] = (nx<<16)+(ny<<8)+i;

		if(m_game.m_gameboard[nx][ny].state == FREE)
			FindRollingPathsHelper(startX, startY, nx, ny, m_game.m_transTable[dieState][i], path, Depth+1);
		else if (m_game.m_gameboard[nx][ny].state == RISING && m_game.m_gameboard[nx][ny].y <= .5)
			FindRollingPathsHelper(startX, startY, nx, ny, m_game.m_transTable[dieState][i], path, Depth+1);
		else if (m_game.m_gameboard[nx][ny].state == SINKING && m_game.m_gameboard[nx][ny].y <= .5)
			FindRollingPathsHelper(startX, startY, nx, ny, m_game.m_transTable[dieState][i], path, Depth+1);
	}


}

// This determines if a path - starting at an occupied position,
// will roll that die to a position that makes a match
bool CBrain::IsRollingPathValid(int x, int y, Path *tempPath)
{
	int i, nx, ny;
	Direction tempDir;
	int diestate = m_game.m_gameboard[x][y].dieState;
	if(m_game.m_gameboard[x][y].state != OCCUPIED)
		return false; // I cant move this die if its not occupied!
	for(i = 0; i< MAX_PATH_LEN && (tempDir = (Direction)(tempPath->path[i]&0xff)) != NONE; i++)
	{
		// Check to see if the die can move in the path's direction
		// I'd use the Class' IsMovementValid, but I'd end up destroying
		// my gameboard while I move dice around for testing
		

		// This might be useful for verifying that FindRollingPath isnt producing garbage, 
		// but since I'm encoding positions into my path, I dont need to compute them

		/*
		nx = x; ny = y;
		switch(tempDir)
		{
		case LEFT:
			nx=x-1;
			break;
		case RIGHT:
			nx=x+1;
			break;
		case UP:
			ny=y-1;
			break;
		case DOWN:
			ny=y+1;
			break;
		default:
			return false; // Something isnt right in the path
		}
		*/

		nx = (tempPath->path[i]>>16)&0xff; 
		ny = (tempPath->path[i]>>8)&0xff;
		if(   nx <0 || nx >= m_game.m_boardSize
			||ny <0 || ny >= m_game.m_boardSize)
		{
			printf("Path ran off the board\n");
			return false; // We ran off the board;
		}

		if(m_game.m_gameboard[nx][ny].state == FREE)
		{
			diestate = m_game.m_transTable[m_game.m_gameboard[nx][ny].dieState][tempDir];
			continue; // this step is okay
		}
		else if (m_game.m_gameboard[nx][ny].state == RISING && m_game.m_gameboard[nx][ny].y <= .5)
		{
			diestate = m_game.m_transTable[m_game.m_gameboard[x][y].dieState][tempDir];
			continue; // this step is okay
		}
		else if (m_game.m_gameboard[nx][ny].state == SINKING && m_game.m_gameboard[nx][ny].y <= .5)
		{
			diestate = m_game.m_transTable[m_game.m_gameboard[x][y].dieState][tempDir];
			continue; // this step is okay
		}
		else
			return false;
	}

	// Now nx,ny should be the path's endpoint
	// Lets make sure...
	if(nx != tempPath->final_x || ny != tempPath->final_y)
		return false;


	diestate /=4; // turn the diestate into its value
	if( nx >= 1 && 
	    (m_game.m_gameboard[nx-1][ny].state == OCCUPIED || m_game.m_gameboard[nx-1][ny].state == SINKING) &&
		diestate == m_game.m_gameboard[nx-1][ny].dieState/4)
		return true;
	if( ny >= 1 && 
	    (m_game.m_gameboard[nx][ny-1].state == OCCUPIED || m_game.m_gameboard[nx][ny-1].state == SINKING) &&
		diestate == m_game.m_gameboard[nx][ny-1].dieState/4)
		return true;
	if( nx < m_game.m_boardSize-1 && 
	    (m_game.m_gameboard[nx+1][ny].state == OCCUPIED || m_game.m_gameboard[nx+1][ny].state == SINKING) &&
		diestate == m_game.m_gameboard[nx+1][ny].dieState/4)
		return true;
	if( ny < m_game.m_boardSize-1 && 
	    (m_game.m_gameboard[nx][ny+1].state == OCCUPIED || m_game.m_gameboard[nx][ny+1].state == SINKING) &&
		diestate == m_game.m_gameboard[nx][ny+1].dieState/4)
		return true;

	return false;

}

// Counts the number of matching dice thered be, if there was a die
// at x,y with value of, well, 'value'
// Copied from CDiceGame's CreateSinkers
int CBrain::ComputeScore(int x, int y, int tempValue, int *path) 
{
	int i, j,tempX, tempY;
	int numSunk = 0; 
	int numMatched_Sink = 0;
	int numMatched_Occ = 0;
	int maxChain = 0;

	// The value of the die here
	//int value = (m_game.m_gameboard[x][y].dieState / 4) + 1;
	int score = 0; // The score I get from occ->sinks
	int chainscore = 0;// The score I get from chaining

	int value = tempValue +1; // This function was written for values 1-6 
	                          // instead of 0-5. And, I'm lazy.

	if(value < 4 && m_game.m_gameType == BASIC_HARDCORE)
		return 0;

	if(value == 1)
	{
		// Check if any beighbors are sinking
		// Left
		if((x-1 >=0 && m_game.m_gameboard[x-1][y].state == SINKING) || 
		   (x+1 <m_game.m_boardSize && m_game.m_gameboard[x+1][y].state == SINKING) || 
		   (y-1 >=0 && m_game.m_gameboard[x][y-1].state == SINKING) ||
		   (y+1 <m_game.m_boardSize && m_game.m_gameboard[x][y+1].state == SINKING))
		{

			for(i = 0; i < m_game.m_boardSize; i++)
				for(j = 0; j < m_game.m_boardSize; j++)
				{
					if((m_game.m_gameboard[i][j].dieState / 4) == 0 && m_game.m_gameboard[i][j].state == OCCUPIED
						&& !(x == i && y== j))
					{
						score += 1; // 1 point for every 1 sunk
					}
				}

		}
		
		return score;
	}


	// I need to check neighers for sinkers and as well as occupieds
	// They both work differently. Lets see how confusing I can make this...

	// clear gameboard flags
	for(i = 0; i < m_game.m_boardSize; i++)
		for(j = 0; j < m_game.m_boardSize; j++)
			m_game.m_gameboard[i][j].flag = false;
	// Set our flag, so we're not checked again.
	m_game.m_gameboard[x][y].flag = true;

	// Scan path positions. If there are sinkers along the path,
	// flag them. We've crushed them, so theyre no longer there.
	for(i = 0; i < MAX_PATH_LEN; i++)
	{
		tempX = (path[i]>>16)&0xFF;
		tempY = (path[i]>>8)&0xFF;
		if(m_game.m_gameboard[tempX][tempY].state == SINKING)
			m_game.m_gameboard[tempX][tempY].flag = true;

	}

	// First, make a list of all the matching sinkers. We'll need to steal them
	// Check neighbors to see if theyre sinking, have the same value as us,
	// and are unflagged. If so, run CheckSinkersHelper on them
	// Left
	if(x-1 >=0 && m_game.m_gameboard[x-1][y].state == SINKING && (m_game.m_gameboard[x-1][y].dieState/4)+1 == value && !m_game.m_gameboard[x-1][y].flag)
		numMatched_Sink+=ComputeScoreHelper(x-1, y, SINKING, &maxChain);
	// Right
	if(x+1 <m_game.m_boardSize && m_game.m_gameboard[x+1][y].state == SINKING && (m_game.m_gameboard[x+1][y].dieState/4)+1 == value && !m_game.m_gameboard[x+1][y].flag)
		numMatched_Sink+=ComputeScoreHelper(x+1, y, SINKING, &maxChain);
	// Up
	if(y-1 >=0 && m_game.m_gameboard[x][y-1].state == SINKING && (m_game.m_gameboard[x][y-1].dieState/4)+1 == value && !m_game.m_gameboard[x][y-1].flag)
		numMatched_Sink+=ComputeScoreHelper(x, y-1, SINKING, &maxChain);
	// Left
	if(y+1 <m_game.m_boardSize && m_game.m_gameboard[x][y+1].state == SINKING && (m_game.m_gameboard[x][y+1].dieState/4)+1 == value && !m_game.m_gameboard[x][y+1].flag)
		numMatched_Sink+=ComputeScoreHelper(x, y+1, SINKING, &maxChain);

	// Okay, so we have "numMatched_Sink" sinkers, with a chain value of "maxChain+1"
	
	// Sinkers are taken care of, now check occupied neighbors
	// Check neighbors to see if theyre occupied, have the same value as us,
	// and are unflagged. If so, run CheckSinkers on them
	// Left
	if(x-1 >=0 && m_game.m_gameboard[x-1][y].state == OCCUPIED && (m_game.m_gameboard[x-1][y].dieState/4)+1 == value && !m_game.m_gameboard[x-1][y].flag)
		numMatched_Occ+=ComputeScoreHelper(x-1, y, OCCUPIED);
	// Right
	if(x+1 <m_game.m_boardSize && m_game.m_gameboard[x+1][y].state == OCCUPIED && (m_game.m_gameboard[x+1][y].dieState/4)+1 == value && !m_game.m_gameboard[x+1][y].flag)
		numMatched_Occ+=ComputeScoreHelper(x+1, y, OCCUPIED);
	// Up
	if(y-1 >=0 && m_game.m_gameboard[x][y-1].state == OCCUPIED && (m_game.m_gameboard[x][y-1].dieState/4)+1 == value && !m_game.m_gameboard[x][y-1].flag)
		numMatched_Occ+=ComputeScoreHelper(x, y-1, OCCUPIED);
	// Left
	if(y+1 <m_game.m_boardSize && m_game.m_gameboard[x][y+1].state == OCCUPIED && (m_game.m_gameboard[x][y+1].dieState/4)+1 == value && !m_game.m_gameboard[x][y+1].flag)
		numMatched_Occ+=ComputeScoreHelper(x, y+1, OCCUPIED);

	if((numMatched_Sink + numMatched_Occ) >= value-1) // If we have enough matches...
	{
		score += (numMatched_Occ+1)*value;
		score += (numMatched_Sink+1)*value*(maxChain+1);
		return score;
	}
	else
	{
		if(numMatched_Occ == 0)
			return 0; // I dont have enough to match with sinkers, so dont bother

		return numMatched_Sink + numMatched_Occ; // If we're at least making matches, this
												 // is a good move. So use the number matched
												 // as the score. 
												 // FIXME! Completed matches will *not*
												 // always have a higher score than partials.
												 // Is finishing a set of 2's better than 
	                                             // adding a 5th 6 to a set? Maybe
	}
	
	return 0;
}
// Swiped from CDiceGames CreateSinkersHelper
int CBrain::ComputeScoreHelper(int x, int y, GamePosState state, int *maxChain)
{
	// return on bad position
	if(x < 0 || x >= m_game.m_boardSize || y < 0 || y >= m_game.m_boardSize)
		return 0;

	// The value of the die here
	int value = (m_game.m_gameboard[x][y].dieState / 4) + 1;
	int result = 1;

	m_game.m_gameboard[x][y].flag = true;
	
	//Update maxChain value if needed
	if(maxChain != NULL && m_game.m_gameboard[x][y].chains > *maxChain)
		*maxChain = m_game.m_gameboard[x][y].chains;
	

	// Left
	if(x-1 >=0 && m_game.m_gameboard[x-1][y].state == state && (m_game.m_gameboard[x-1][y].dieState/4)+1 == value && !m_game.m_gameboard[x-1][y].flag)
		result+=ComputeScoreHelper(x-1, y, state);
	// Right
	if(x+1 <m_game.m_boardSize && m_game.m_gameboard[x+1][y].state == state && (m_game.m_gameboard[x+1][y].dieState/4)+1 == value && !m_game.m_gameboard[x+1][y].flag)
		result+=ComputeScoreHelper(x+1, y, state);
	// Up
	if(y-1 >=0 && m_game.m_gameboard[x][y-1].state == state && (m_game.m_gameboard[x][y-1].dieState/4)+1 == value && !m_game.m_gameboard[x][y-1].flag)
		result+=ComputeScoreHelper(x, y-1, state);
	// DOWN
	if(y+1 <m_game.m_boardSize && m_game.m_gameboard[x][y+1].state == state && (m_game.m_gameboard[x][y+1].dieState/4)+1 == value && !m_game.m_gameboard[x][y+1].flag)
		result+=ComputeScoreHelper(x, y+1, state);

	
	return result;
}

// debugging, list the paths at a position
// will only be called from FindPath, so making the main
// program signal that it wants a list is tricky.
void CBrain::DumpPaths()
{
	int i,j;
	//Direction tempDir;

	m_wantDump = false; // Shut off trigger

	printf("Number of paths at %i,%i: %i\n", m_dumpX, m_dumpY, m_gamepaths[m_dumpX][m_dumpY]->size());
	for(i = 0; i < (int)m_gamepaths[m_dumpX][m_dumpY]->size(); i++)
	{
		printf("%i: ", i);
		for(j = 0; j < MAX_PATH_LEN && (*m_gamepaths[m_dumpX][m_dumpY])[i].path[j] != NONE; j++)
		{	
			switch((*m_gamepaths[m_dumpX][m_dumpY])[i].path[j]&0xff)
			{
			case UP:
				printf("U");
				break;
			case DOWN:
				printf("D");
				break;
			case RIGHT:
				printf("R");
				break;
			case LEFT:
				printf("L");
				break;
			}

			//printf("->%i,%i ", ((*m_gamepaths[m_dumpX][m_dumpY])[i].path[j]>>16)&0xff, ((*m_gamepaths[m_dumpX][m_dumpY])[i].path[j]>>8)&0xff);
		}
		printf(":%x\n", ((*m_gamepaths[m_dumpX][m_dumpY])[i].final_x<<16) + ((*m_gamepaths[m_dumpX][m_dumpY])[i].final_y<<8) + (*m_gamepaths[m_dumpX][m_dumpY])[i].die_state);

	}



}

unsigned int __stdcall BrainThreadProc(void*)
{
	while(g_pBrain->m_runThread)
	{
		g_pBrain->PathThread();
		Sleep(100);

	}
	printf("Exiting thread\n");

	return 0;
}
