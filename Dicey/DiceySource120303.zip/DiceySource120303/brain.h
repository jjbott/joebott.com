// brain.h
// Written by Joseph Bott IV 
// Copyright 2003

// The brain files contain functions for AI control. 
// All the brain will do is repeatedly scan the board for movable 
// dice, and find good paths leading from those dice. Using this information,
// it will also track "good path volatility". That is, if a dice can be moved 
// to form a match, but the path is only valid for 1 scan of the board, 
// we dont want the AI to try and take that path. Make sense? Oh well... 
// It will run in a separate thread so it wont slow down the game too much (I hope)

// The AI (impemented in an AI class: ai.cpp and ai.h) then will be
// able to use this information to quickly decide where it wants to go. 

// **this is more for the AI files**
// At each point where the AI needs to decide what to do, depending on its state, it
// will look up its position in the brain's list. Then it will assemble a path using 
// this information. Then while traversing the path, it only needs to make sure that
// the path is still valid. So in the end, we have fast AI. I hope...

#pragma once

#include <windows.h> // for DWORD
#include <vector>
#include <set>
#include "DiceGame.h"
using namespace std;



// MAximum length a path can be.
#define MAX_PATH_LEN 10

// Structure to hold all the information about a path
struct Path
{
	int path[MAX_PATH_LEN]; // the path itself, NONE terminated  :) 
						    // encoded as: (x<<16)+(y<<8)+direction
							// x,y are position that direction will put you
	int score; // The score of the path - how good of a match it makes
	int die_state; // The final die state - so we can search by specific matches,
	               // as well as prevent this specific path from being searched for again
	int final_x, final_y; // the position where the path ends, so we can search based on position
	int volatility; // Basically, how long has this path been around? The AI will prefer 
	                // paths that have been around a few cycles
	int length;     // The length of the path
	DWORD gametime; // The game time that this path was validated first on. Just another tool
	                // for determining path age.
};

class CBrain
{
public:

	CBrain();
	~CBrain();

	vector<Path> ***m_gamepaths; // The monster. This is the brain's storage, a dynamic 
								 // array of vector pointers. Yucky.
	//HANDLE **m_mutexHandles;      // Array of mutex handles, so brain and AI dont fight

	bool m_runThread; // bool to control the FindPath thread
	unsigned int m_dwThreadID; // Handle of the threadID
	set<int, less<int> > m_sPath; // For finding paths, a set of all known path
	                              // endpoints. This is so I dont search anything 
	                              // more than once. Entries are the gameboard x,y 
								  // position and the die's value, encoded in an int.
								  // int = x<<16 + y<<8 + dievalue

	// for debugging. When m_wantDump is true, the
	// thread will list all paths from dumpX,dumpY
	bool m_wantDump;
	int m_dumpX;
	int m_dumpY;
	// Also for debugging. When true, user wants 
	// m_sPath info for dumpX,dumpY
	bool m_wantPathInfo;

	CDiceGame m_game; // The copy of the gameboard we'll be using.

	// The workhorse - this will be the brain's thread.
	void PathThread(); // The function for finding paths on the gameboard
					   // This will run for as long as 'runThread' is true

	void FindRollingPaths(int x, int y); // The function for finding paths at a specific position
	void FindRollingPathsHelper(int startX, int startY, int x,int y,int dieState, int *oldPath, int Depth);			  

	bool IsRollable(int x, int y); // Determines if the dice at x,y is rollable
										   // Uses CDiceGame's IsMovementValid

	bool IsRollingPathValid(int x, int y, Path *tempPath); // Determines if a path is still
												    // good.

	int ComputeScore(int x, int y, int value, int *path); // Counts the number of matching dice thered be, if there was a die
                                              // at x,y with value of, well, 'value'
											  // Also send along a path with encoded postions
											  // so we know what sinkers were crushed
	int ComputeScoreHelper(int x, int y, GamePosState state, int *maxChain = NULL);

	void DumpPaths();
                                   
};

unsigned int __stdcall BrainThreadProc(void*); // The actual thread entry point


