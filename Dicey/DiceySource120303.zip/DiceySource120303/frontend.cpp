#include <windows.h>
#include <process.h>
#include <d3dx9.h>
#include "frontend.h"
#include "DiceGame.h"
#include "CreateScript.h"
#include "RunScript.h"
#include "main.h"
#include "Input.h"
#include "DIKtoStr.h"
#include "AI.h"
#include "brain.h"


#define MAXPLAYERS 5

extern int g_numPlayers;
extern CDiceGame *g_pGame;
extern GameState g_gameState;
extern AI **g_AIplayers;
extern CBrain *g_pBrain;
extern DWORD g_dwBrainThreadID;

extern LPDIRECT3DDEVICE9       g_pd3dDevice;
extern LPD3DXFONT				g_pFont;

// Player configuration data, defined in input.cpp
extern PLAYERCONFIG g_playerConfig[5];
// DI Device info, defined in input.cpp
extern vector<DIDEVICEINFO> g_vDIDevInfo;


int g_numGameTypes = 2; // How many gametypes are there? Corresponds to GameTypes in DiceGame.h

int selection = 0;
//int numPlayers = 0;
int gameType = 0;
int boardSize = 7;
bool recordGame = false;
int selectedPlayer = 0; // selected player, for options menu
int menu = MAIN; // selected menu

bool gettingKey = false; // Flag, set when we're waiting for the user to hit a key




// This will get sent keydown events while we're in the front end
// Break this up into functions for each menu
void FrontEndInput(WPARAM wParam)
{
	int i;
	if(gettingKey)
		return; // Do nothing if we're waiting for a keypress in FrontEndRender()
	if(menu == MAIN)
	{
		switch(wParam)
		{
		case VK_UP:
			selection--;
			break;
		case VK_DOWN:
			selection++;
			break;
		case 13:
			if(selection == GOTOOPTIONS)
			{
				menu = OPTIONS;
				selection = GOTOMAIN;
			}
			else if(selection == GAMETYPE)
				gameType++;
			else if (selection == NUMPLAYERS)
				g_numPlayers++;
			else if (selection == BOARDSIZE)
				boardSize++;
			else if (selection == RECORD_GAME)
				recordGame = !recordGame;
			else if (selection == RUN_SCRIPT1)
			{

				if(FAILED(LoadScript("TestScript")))
				{
					printf("LoadScript failed\n");
					break;
				}
				g_pGame->m_runningScript = true;
				
				// FIXME: Take this out eventually
				//        Only here to potentially fix broken scripts while they play
				g_pGame->m_recordingScript = false;//recordGame;
				//if(g_pGame->m_recordingScript)
				//	AddInitInfo();

				g_gameState = PLAYING;

			}
			else if (selection == START)
			{
				g_pGame = new CDiceGame;
				g_pGame->Init(gameType,boardSize,g_numPlayers);
				g_pGame->m_recordingScript = recordGame;

				// create AI classes
				g_AIplayers = (AI**)malloc(g_numPlayers * sizeof(AI*));
				for(i = 0; i <g_numPlayers; i++)
				{
					g_AIplayers[i] = new AI;
					g_AIplayers[i]->m_playerNum = i;
					//printf("AI #%i refers to player #%i\n", i, g_AIplayers[i]->m_playerNum);
				}

				// Start Brain
				g_pBrain = new CBrain;
				g_pBrain->m_runThread = true;
				_beginthreadex(NULL, 0, BrainThreadProc, NULL, 0, &g_pBrain->m_dwThreadID);
				//CreateThread(NULL, 0, BrainThreadProc, NULL, 0, &g_pBrain->m_dwThreadID);
				// Add init stuff to script	
				if(g_pGame->m_recordingScript)
					AddInitInfo();
				g_gameState = PLAYING;

			}
			break;
		case VK_RIGHT:
			if(selection == GAMETYPE)
				gameType++;
			else if (selection == NUMPLAYERS)
				g_numPlayers++;
			else if (selection == BOARDSIZE)
				boardSize++;
			else if (selection == RECORD_GAME)
				recordGame = !recordGame;
			break;
		case VK_LEFT:
			if(selection == GAMETYPE)
				gameType--;
			else if (selection == NUMPLAYERS)
				g_numPlayers--;
			else if (selection == BOARDSIZE)
				boardSize--;
			else if (selection == RECORD_GAME)
				recordGame = !recordGame;
			break;
		}
		if(selection < 0)
			selection += MAINSELECTIONS;
		if(gameType < 0)
			gameType += g_numGameTypes;
		selection%=MAINSELECTIONS;
		gameType%=g_numGameTypes;
		if(g_numPlayers < 1)
			g_numPlayers = 1;
		if(g_numPlayers > MAXPLAYERS)
			g_numPlayers = MAXPLAYERS;

		if(boardSize < 7)
			boardSize = 7;
		if(boardSize > 20)
			boardSize = 20;
	}
	else if (menu == OPTIONS)
	{
		printf("start ping! %i %i\n", selectedPlayer, g_playerConfig[selectedPlayer].device);
			
		switch(wParam)
		{
		case VK_UP:
			printf("up ping! %i %i\n", selectedPlayer, g_playerConfig[selectedPlayer].device);
		
			selection--;
			break;
		case VK_DOWN:
			printf("down ping! %i %i\n", selectedPlayer, g_playerConfig[selectedPlayer].device);
		
			selection++;
			break;

		case 13:
			printf("13 ping! %i %i\n", selectedPlayer, g_playerConfig[selectedPlayer].device);
		
			if(selection == GOTOMAIN)
			{
				menu = MAIN;
				selection = GAMETYPE;
			}
			else if (selection == PLAYER)
				selectedPlayer++;
			else if (selection == DEVICE)
				g_playerConfig[selectedPlayer].device++;
			else if (selection == CONFIGUP) //FIXME
				gettingKey = true;//Get next presed key
			else if (selection == CONFIGLEFT)
				gettingKey = true;//Get next presed key
			else if (selection == CONFIGDOWN)
				gettingKey = true;//Get next presed key
			else if (selection == CONFIGRIGHT)
				gettingKey = true;//Get next presed key

			break;
		case VK_RIGHT:
			printf("right ping! %i %i\n", selectedPlayer, g_playerConfig[selectedPlayer].device);
		
			if (selection == PLAYER)
				selectedPlayer++;
			else if (selection == DEVICE)
				g_playerConfig[selectedPlayer].device++;
			break;
		case VK_LEFT:
			printf("left ping! %i %i\n", selectedPlayer, g_playerConfig[selectedPlayer].device);
			
			if (selection == PLAYER)
				selectedPlayer--;
			else if (selection == DEVICE)
			{
				
				g_playerConfig[selectedPlayer].device--;
			}
			
			break;
		}
		if(selection < 0)
		{
			if(g_playerConfig[selectedPlayer].device != 0)
				selection = 2;
			else
				selection += OPTSELECTIONS;
		}
		if(selectedPlayer < 0)
			selectedPlayer += MAXPLAYERS;
		if(g_playerConfig[selectedPlayer].device < 0)
		{
			//printf("<0 ping! %i %i\n", selectedPlayer, g_playerConfig[selectedPlayer].device);
			if(g_playerConfig[selectedPlayer].device != -1)
				g_playerConfig[selectedPlayer].device = (int)g_vDIDevInfo.size()-1;
		}
		else if(g_playerConfig[selectedPlayer].device == g_vDIDevInfo.size())
			g_playerConfig[selectedPlayer].device =-1;

		if(selection > 2 && (g_playerConfig[selectedPlayer].device != 0))
			selection = 0;
		else
			selection%=OPTSELECTIONS;
		selectedPlayer%=MAXPLAYERS;
		
		
	}
}

// This will render the front end
void FrontEndRender()
{
	D3DXCOLOR fontColor;
	char buffer[255];
	RECT FontRect;
	unsigned char tempKey; // temp Key, used with GetKey() for config

	if(FAILED(g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,
                         D3DCOLOR_XRGB(0,0,0), 1.0f, 0 )))
	{
		printf("g_pd3dDevice->Clear failed: %i\n", GetLastError());
		return;
	}

	if( SUCCEEDED( g_pd3dDevice->BeginScene() ) )
    {
		if(FAILED(g_pFont->Begin()))
			printf("g_pFont->Begin  failed: %i\n", GetLastError());

		// FIXME: Break this up into functions for each menu

		if(menu == MAIN)
		{

			// Draw gametype
			if(selection == GAMETYPE)
				fontColor = 0xffffffff;
			else
				fontColor = 0xffaaaaaa;
			switch(gameType)
			{
			case BASIC_NORMAL:
				sprintf(buffer, "GameType: Basic - Normal Rules");
				break;
			case BASIC_HARDCORE:
				sprintf(buffer, "GameType: Basic - Hardcore Rules");
				break;
			case 2:
				sprintf(buffer, "GameType: Not Implemented");
				break;
			}

			SetRect(&FontRect, 100, 100, 0, 0);
			if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, fontColor)))
				printf("g_pFont->DrawText failed: %i\n", GetLastError());

			// Number of players
			if(selection == NUMPLAYERS)
				fontColor = 0xffffffff;
			else
				fontColor = 0xffaaaaaa;

			sprintf(buffer, "Number of Players: %i", g_numPlayers);
			SetRect(&FontRect, 100, 130, 0, 0);
			if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, fontColor)))
				printf("g_pFont->DrawText failed: %i\n", GetLastError());

			// Board size
			if(selection == BOARDSIZE)
				fontColor = 0xffffffff;
			else
				fontColor = 0xffaaaaaa;

			sprintf(buffer, "Board Size: %i", boardSize);
			SetRect(&FontRect, 100, 160, 0, 0);
			if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, fontColor)))
				printf("g_pFont->DrawText failed: %i\n", GetLastError());

			// Record Game
			if(selection == RECORD_GAME)
				fontColor = 0xffffffff;
			else
				fontColor = 0xffaaaaaa;
			if(recordGame)
				sprintf(buffer, "Record Game as \"TestScript\"? Yes");
			else
				sprintf(buffer, "Record Game as \"TestScript\"? No");
			SetRect(&FontRect, 100, 190, 0, 0);
			if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, fontColor)))
				printf("g_pFont->DrawText failed: %i\n", GetLastError());

			// RunScript 1
			if(selection == RUN_SCRIPT1)
				fontColor = 0xffffffff;
			else
				fontColor = 0xffaaaaaa;
			sprintf(buffer, "Run \"TestScript\"");
			SetRect(&FontRect, 100, 220, 0, 0);
			if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, fontColor)))
				printf("g_pFont->DrawText failed: %i\n", GetLastError());

			// GOTOPTIONS
			if(selection == GOTOOPTIONS)
				fontColor = 0xffffffff;
			else
				fontColor = 0xffaaaaaa;
			sprintf(buffer, "Configuration Options");
			SetRect(&FontRect, 100, 250, 0, 0);
			if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, fontColor)))
				printf("g_pFont->DrawText failed: %i\n", GetLastError());

			// Start
			if(selection == START)
				fontColor = 0xffffffff;
			else
				fontColor = 0xffaaaaaa;
			sprintf(buffer, "Start");
			SetRect(&FontRect, 100, 280, 0, 0);
			if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, fontColor)))
				printf("g_pFont->DrawText failed: %i\n", GetLastError());
		}
		else if(menu == OPTIONS)
		{
			// GOTOMAIN
			if(selection == GOTOMAIN)
				fontColor = 0xffffffff;
			else
				fontColor = 0xffaaaaaa;
		
			sprintf(buffer, "Main Menu");
			SetRect(&FontRect, 100, 100, 0, 0);
			if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, fontColor)))
				printf("g_pFont->DrawText failed: %i\n", GetLastError());

			// PLAYER
			if(selection == PLAYER)
				fontColor = 0xffffffff;
			else
				fontColor = 0xffaaaaaa;
		
			sprintf(buffer, "Player: %i", selectedPlayer +1);
			SetRect(&FontRect, 100, 130, 0, 0);
			if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, fontColor)))
				printf("g_pFont->DrawText failed: %i\n", GetLastError());

			// Device
			if(selection == DEVICE)
				fontColor = 0xffffffff;
			else
				fontColor = 0xffaaaaaa;
		
			if(g_playerConfig[selectedPlayer].device == -1)
				sprintf(buffer, "Input Device: None");
			else
				sprintf(buffer, "Input Device: %s", g_vDIDevInfo[g_playerConfig[selectedPlayer].device].Enum.tszProductName);
			SetRect(&FontRect, 100, 160, 0, 0);
			if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, fontColor)))
				printf("g_pFont->DrawText failed: %i\n", GetLastError());

			if(g_playerConfig[selectedPlayer].device == 0) // Only display key info if using the keyboard
			{
				// UP
				if(selection == CONFIGUP)
				{
					if(gettingKey)
					{
						tempKey=GetKey();
						if(tempKey != 255)
						{
							g_playerConfig[selectedPlayer].up = tempKey;
							gettingKey = false;
						}
					}

					fontColor = 0xffffffff;
				}
				else
					fontColor = 0xffaaaaaa;
				
				if(selection == CONFIGUP && gettingKey)
				{
					sprintf(buffer, "   Up: Press a key...");
				}
				else
					sprintf(buffer, "   Up: %s", DIKtoStr(g_playerConfig[selectedPlayer].up));
				SetRect(&FontRect, 100, 190, 0, 0);
				if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, fontColor)))
					printf("g_pFont->DrawText failed: %i\n", GetLastError());

				// DOWN
				if(selection == CONFIGDOWN)
				{
					if(gettingKey)
					{
						tempKey=GetKey();
						if(tempKey != 255)
						{
							g_playerConfig[selectedPlayer].down = tempKey;
							gettingKey = false;
						}
					}

					fontColor = 0xffffffff;
				}
				else
					fontColor = 0xffaaaaaa;
				
				if(selection == CONFIGDOWN && gettingKey)
				{
					sprintf(buffer, "   Down: Press a key...");
				}
				else
					sprintf(buffer, "   Down: %s", DIKtoStr(g_playerConfig[selectedPlayer].down));
				
				SetRect(&FontRect, 100, 250, 0, 0);
				if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, fontColor)))
					printf("g_pFont->DrawText failed: %i\n", GetLastError());

				// Left
				if(selection == CONFIGLEFT)
				{
					if(gettingKey)
					{
						tempKey=GetKey();
						if(tempKey != 255)
						{
							g_playerConfig[selectedPlayer].left = tempKey;
							gettingKey = false;
						}
					}

					fontColor = 0xffffffff;
				}
				else
					fontColor = 0xffaaaaaa;
				
				if(selection == CONFIGLEFT && gettingKey)
				{
					sprintf(buffer, "   Left: Press a key...");
				}
				else
					sprintf(buffer, "   Left: %s", DIKtoStr(g_playerConfig[selectedPlayer].left));
				
				SetRect(&FontRect, 100, 220, 0, 0);
				if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, fontColor)))
					printf("g_pFont->DrawText failed: %i\n", GetLastError());

				// Right
				if(selection == CONFIGRIGHT)
				{
					if(gettingKey)
					{
						tempKey=GetKey();
						if(tempKey != 255)
						{
							g_playerConfig[selectedPlayer].right = tempKey;
							gettingKey = false;
						}
					}

					fontColor = 0xffffffff;
				}
				else
					fontColor = 0xffaaaaaa;
				
				if(selection == CONFIGRIGHT && gettingKey)
				{
					sprintf(buffer, "   Right: Press a key...");
				}
				else
					sprintf(buffer, "   Right: %s", DIKtoStr(g_playerConfig[selectedPlayer].right));
				
				SetRect(&FontRect, 100, 280, 0, 0);
				if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, fontColor)))
					printf("g_pFont->DrawText failed: %i\n", GetLastError());


			}
		}

		if(FAILED(g_pFont->End()))
			printf("g_pFont->End  failed: %i\n", GetLastError());

		g_pd3dDevice->EndScene();
        
		//printf("ping6!\n");
    }

	//printf("ping6b!\n");
    // Present the backbuffer contents to the display
    if(FAILED(g_pd3dDevice->Present( NULL, NULL, NULL, NULL )))
	{
		//printf("g_pd3dDevice->Present failed: %i\n", GetLastError());
		return;
	}
	return;
}