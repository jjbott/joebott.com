#pragma once

// Menus
enum {MAIN, OPTIONS};

// Selections
// Main menu
enum {GAMETYPE, NUMPLAYERS, BOARDSIZE, RECORD_GAME, RUN_SCRIPT1, GOTOOPTIONS, START};
// Options menu
enum {GOTOMAIN, PLAYER, DEVICE, CONFIGUP, CONFIGLEFT, CONFIGDOWN, CONFIGRIGHT};

#define MAINSELECTIONS 7
#define OPTSELECTIONS 7

// Game Types
//#define NUMGAMETYPES 3

void FrontEndInput(WPARAM wParam);
void FrontEndRender();