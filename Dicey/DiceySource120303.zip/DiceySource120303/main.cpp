//#pragma once

#include <Windows.h>
#include <mmsystem.h>
#include <d3dx9.h>
#include <dsound.h>
#include<stdio.h>
#include <io.h>
#include <fcntl.h>

//#include "mmgr.h"
#include "DiceGame.h"
#include "frontend.h"
#include "resource.h"
#include "main.h"
#include "CreateScript.h"
#include "RunScript.h"
#include "Input.h"
#include "brain.h"
#include "AI.h"




// A structure for our custom vertex type. We added texture coordinates
struct CUSTOMVERTEX
{
    D3DXVECTOR3 position; // The position
	D3DXVECTOR3 n;
    FLOAT       tu, tv;   // The texture coordinates
};

#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ|D3DFVF_TEX1|D3DFVF_NORMAL)

//extern int g_frontEndSelection;

GameState g_gameState = FRONT_END;

CBrain *g_pBrain = NULL;;


AI **g_AIplayers; // An AI class for each player
               // They wont get used if the player isnt an AI, but it doesnt 
               // take much memory so that might be okay
			   // TODO: Make this nicer, only enough AI classes for AI players

LPDIRECT3D9             g_pD3D       = NULL; // Used to create the D3DDevice
LPDIRECT3DDEVICE9       g_pd3dDevice = NULL; // Our rendering device
LPDIRECT3DVERTEXBUFFER9 g_pVBDie     = NULL; // Buffer to hold Die vertices
LPDIRECT3DINDEXBUFFER9  g_pIBDie     = NULL; // Buffer to hold Die indexes
LPDIRECT3DVERTEXBUFFER9 g_pVBPlayer  = NULL; // Buffer to hold Die vertices
LPDIRECT3DTEXTURE9      g_pDieTexture   = NULL; // Our texture

LPD3DXFONT				g_pFont = NULL; // Our font
RECT					FontRect;

LPDIRECTSOUND8          g_pDS       = NULL; // Used to create the D3DDevice
LPDIRECTSOUNDBUFFER     g_pSBPrimary = NULL; // Primary sound Buffer

#define CLUNK_FILENAME "clunk.wav"
#define CLUNK_BUFFERS 5  // Number of clunk buffers, so I can play more than 1 copies of the sound simultaneously
LPDIRECTSOUNDBUFFER     g_pSBClunk[CLUNK_BUFFERS];//		= NULL; // Sound buffer for clunk sound
#define SLIDE_FILENAME "slide.wav"
#define SLIDE_BUFFERS 5  // Number of slide buffers
LPDIRECTSOUNDBUFFER     g_pSBSlide[SLIDE_BUFFERS];//		= NULL; // Sound buffer for slide sound
#define ZAP_FILENAME "zap.wav"
#define ZAP_BUFFERS 5  // Number of slide buffers
LPDIRECTSOUNDBUFFER     g_pSBZap[ZAP_BUFFERS];//		= NULL; // Sound buffer for slide sound
#define SINK_FILENAME "chime.wav"
#define SINK_BUFFERS 5  // Number of slide buffers
LPDIRECTSOUNDBUFFER     g_pSBSink[SINK_BUFFERS];//		= NULL; // Sound buffer for sinker sound
#define OUCH_FILENAME "ouch.wav"
#define OUCH_BUFFERS 5  // Number of slide buffers
LPDIRECTSOUNDBUFFER     g_pSBOuch[OUCH_BUFFERS];//		= NULL; // Sound buffer for ouch sound

#define GAMEOVER_FILENAME "gameover.wav"
LPDIRECTSOUNDBUFFER     g_pSBGameOver = NULL;

#define LEVELUP_FILENAME "levelup.wav"
LPDIRECTSOUNDBUFFER     g_pSBLevelUp = NULL;

CDiceGame*				g_pGame		= NULL;  // To make class global
											 // TODO: Might be a better way to do this...
FLOAT					g_fAspect		= 1.0f;  // Aspect ratio - stored in global to handle resizes
FLOAT					g_fFOV			= 0.365399f;//D3DX_PI/4.0f;  // Aspect ratio - stored in global to handle resizes
DWORD					g_dwTime		= 0;
int						g_numPlayers  = 0;
BOOL					g_bKey[256];  // buffer for key states;
D3DXVECTOR3				g_vCameraPos(8,13.9f,-13.6f);

bool g_fPaused = false; // Is the game paused?
bool g_fPerspective = true;
float g_orthoSize = 10.0;

HRESULT InitSBArray(LPDIRECTSOUNDBUFFER* pSB, int arraySize, char* fileName)
{
	FILE *waveFile;
	char tempChar;
	DWORD dataLen = 0;
	WAVEFORMATEX waveFormat;
	int i;

	ZeroMemory(&waveFormat, sizeof(WAVEFORMATEX));
	DSBUFFERDESC bufferDesc;
	ZeroMemory(&bufferDesc, sizeof(DSBUFFERDESC));

	waveFile = fopen(fileName,"rb");
	if(waveFile == NULL)
	{
		printf("open wave failed\n");
		//fclose(waveFile);
		return E_FAIL;
	}

	// For now, I'm only going to deal with 44.1khz mono samples, 
	// so I'm going to ignore the header
	
	// Seek to the Data portion
	while(!feof(waveFile))
	{
		// This seems like a weird way to do things..
		if(tempChar = fgetc(waveFile) == 'd')
			if(tempChar = fgetc(waveFile) == 'a')
				if(tempChar = fgetc(waveFile) == 't')
					if(tempChar = fgetc(waveFile) == 'a')
						break;
	}

	//printf("Data len: %i\n", dataLen);

	dataLen = fgetc(waveFile);
	//printf("Data len: %i\n", dataLen);
	dataLen |= fgetc(waveFile)<<8;
	//printf("Data len: %i\n", dataLen);
	dataLen |= fgetc(waveFile)<<16;
	//printf("Data len: %i\n", dataLen);
	dataLen |= fgetc(waveFile)<<24;

	//printf("Data len: %i\n", dataLen);
	if(dataLen <= 0)
	{
		printf("open wave failed\n");
		fclose(waveFile);
		return E_FAIL;
	}

	
	waveFormat.wFormatTag = WAVE_FORMAT_PCM;
	waveFormat.nChannels = 1;
	waveFormat.nSamplesPerSec = 44100;
	waveFormat.nAvgBytesPerSec = 88200;
	waveFormat.nBlockAlign = 2;
	waveFormat.wBitsPerSample = 16;

	
	bufferDesc.dwSize = sizeof(DSBUFFERDESC);
	bufferDesc.dwFlags = DSBCAPS_STATIC|DSBCAPS_CTRLPAN|DSBCAPS_CTRLVOLUME;
	bufferDesc.dwBufferBytes = dataLen;
	bufferDesc.lpwfxFormat = &waveFormat;

	g_pDS->CreateSoundBuffer(&bufferDesc, &pSB[0], NULL);

	//bufferDesc.dwFlags = DSBCAPS_CTRLVOLUME|DSBCAPS_PRIMARYBUFFER;
	//bufferDesc.dwBufferBytes = 88200;
	//g_pDS->CreateSoundBuffer(&bufferDesc, &g_pSBPrimary, NULL);

	//if(pSB[0] != NULL)
		//printf("Sound buffer creation worked! Woo!\n");

	BYTE* soundBuffer1;
	DWORD soundBuffer1Len;
	BYTE* soundBuffer2;
	DWORD soundBuffer2Len;

	if(DS_OK != pSB[0]->Lock(0, dataLen, (LPVOID*)&soundBuffer1, &soundBuffer1Len, (LPVOID*)&soundBuffer2, &soundBuffer2Len,DSBLOCK_ENTIREBUFFER))
	{
		MessageBox(NULL, "sound buffer lock failed", "Dicey.exe", MB_OK);
		fclose(waveFile);
        return E_FAIL;
	}
	else
	{

		for(i = 0; i < (int)soundBuffer1Len && !feof(waveFile);i++)
		{
			soundBuffer1[i] = (BYTE)fgetc(waveFile);
		}
		for(i = 0; i < (int)soundBuffer2Len && !feof(waveFile);i++)
		{
			soundBuffer2[i] = (BYTE)fgetc(waveFile);
		}
		fclose(waveFile);
		if(DS_OK != pSB[0]->Unlock(soundBuffer1, soundBuffer1Len, soundBuffer2, soundBuffer2Len))
		{
			MessageBox(NULL, "sound buffer unlock failed", "Dicey.exe", MB_OK);
			return E_FAIL;
		}
	}

	for(i = 1; i< arraySize; i++)
	{
		g_pDS->DuplicateSoundBuffer(pSB[0],&pSB[i]);
	}
	

	return S_OK;
}



HRESULT InitDS(HWND hWnd)
{
	char buffer[256];
	//int i;
	if(DS_OK != DirectSoundCreate8(NULL, // Defaul sound device
					   &g_pDS, // Pointer to DS
					   NULL)) // Not used
	{
		sprintf(buffer, "Direct3DCreate9() failed: %i", GetLastError());
		MessageBox(NULL, buffer, "Dicey.exe", MB_OK);
        return E_FAIL;
	}
	
	if(DS_OK != g_pDS->SetCooperativeLevel(hWnd, DSSCL_NORMAL))//PRIORITY))
	{
		MessageBox(NULL, "SetCooperativeLevel failed", "Dicey.exe", MB_OK);
        return E_FAIL;
	}

	InitSBArray(g_pSBClunk, CLUNK_BUFFERS, CLUNK_FILENAME);
	InitSBArray(g_pSBSlide, SLIDE_BUFFERS, SLIDE_FILENAME);
	InitSBArray(g_pSBZap, ZAP_BUFFERS, ZAP_FILENAME);
	InitSBArray(&g_pSBGameOver, 0, GAMEOVER_FILENAME);
	InitSBArray(g_pSBSink, SINK_BUFFERS, SINK_FILENAME);
	InitSBArray(&g_pSBLevelUp, 0, LEVELUP_FILENAME);
	InitSBArray(g_pSBOuch, OUCH_BUFFERS, OUCH_FILENAME);
	
	return S_OK;

}

//-----------------------------------------------------------------------------
// Name: InitD3D()
// Desc: Initializes Direct3D
//-----------------------------------------------------------------------------
HRESULT InitD3D( HWND hWnd )
{
    // Create the D3D object.
    if( NULL == ( g_pD3D = Direct3DCreate9( D3D_SDK_VERSION ) ) )
	{
		MessageBox(NULL, "Direct3DCreate9() failed", "Dicey.exe", MB_OK);
        return E_FAIL;
	}

    // Set up the structure used to create the D3DDevice. Since we are now
    // using more complex geometry, we will create a device with a zbuffer.
    D3DPRESENT_PARAMETERS d3dpp;
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;
    d3dpp.EnableAutoDepthStencil = TRUE;
    d3dpp.AutoDepthStencilFormat = D3DFMT_D16;
	d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;


	
    // Create the D3DDevice
    if( FAILED( g_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                      D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                      &d3dpp, &g_pd3dDevice ) ) )
    {
		char buffer[256];
		sprintf(buffer, "CreateDevice() failed: %i", GetLastError());
		MessageBox(NULL, buffer, "Dicey.exe", MB_OK);
        return E_FAIL;
    }

    // Turn off culling
	if(D3D_OK != g_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE))//D3DCULL_NONE );
	{
		char buffer[256];
		sprintf(buffer, "SetRenderState( D3DRS_CULLMODE failed: %i", GetLastError());
		MessageBox(NULL, buffer, "Dicey.exe", MB_OK);
        return E_FAIL;
    }
	
	

	/*if(D3D_OK !=g_pd3dDevice->SetRenderState( D3DRS_AMBIENT, 0x0c0c0c0c))
	  {
		char buffer[256];
		sprintf(buffer, "SetRenderState( D3DRS_AMBIENT failed: %i", GetLastError());
		MessageBox(NULL, buffer, "Dicey.exe", MB_OK);
        return E_FAIL;
    }*/

	/*D3DXVECTOR3 vecDir;
    D3DLIGHT9 light;
    ZeroMemory( &light, sizeof(D3DLIGHT9) );
    light.Type       = D3DLIGHT_DIRECTIONAL;
    light.Diffuse.r  = 1.0f;
    light.Diffuse.g  = 1.0f;
    light.Diffuse.b  = 1.0f;
    vecDir = D3DXVECTOR3(cosf(timeGetTime()/350.0f),
                         1.0f,
                         sinf(timeGetTime()/350.0f) );
    D3DXVec3Normalize( (D3DXVECTOR3*)&light.Direction, &vecDir );
    light.Range       = 1000.0f;
    g_pd3dDevice->SetLight( 0, &light );
    g_pd3dDevice->LightEnable( 0, TRUE );
    g_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );
*/

	D3DLIGHT9 light;
	D3DXVECTOR3 vecLightDirUnnormalized( -2.0f, -6.0f, 3.0f );
    ZeroMemory( &light, sizeof(D3DLIGHT9) );
    light.Type        = D3DLIGHT_DIRECTIONAL;
	//light.Attenuation0 = 1.0f;
    light.Diffuse.r   = 1.0f;
    light.Diffuse.g   = 1.0f;
    light.Diffuse.b   = 1.0f;
    D3DXVec3Normalize((D3DXVECTOR3*)&light.Direction, &vecLightDirUnnormalized );
    //light.Position.x   = -5.0;
    //light.Position.y   = -6.0;
    //light.Position.z   = 5;
    light.Range        = 1000.0f;
        //D3DUtil_InitLight( light, D3DLIGHT_DIRECTIONAL , -5.0f, -6.0f, 5.0f );
    light.Ambient.r = 0.1f;
     light.Ambient.g = 0.1f;
     light.Ambient.b = 0.1f;

     if(g_pd3dDevice->SetLight( 0, &light ) != D3D_OK)
	 {
		 printf("Crap: %i\n", GetLastError());
	 }
     if(g_pd3dDevice->LightEnable( 0, TRUE ) != D3D_OK)
	 {
		 printf("Crap: %i\n", GetLastError()) ;
	 }

	 if(g_pd3dDevice->SetRenderState( D3DRS_NORMALIZENORMALS, TRUE)!= D3D_OK)
	 {
		 printf("Crap: %i\n", GetLastError());
	 }
	 
	if(g_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE)!= D3D_OK)
	 {
		 printf("Crap: %i\n", GetLastError());
	 }

	if(D3D_OK !=g_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE ))
	{
		char buffer[256];
		sprintf(buffer, "SetRenderState( D3DRS_ALPHABLENDENABLE failed: %i", GetLastError());
		MessageBox(NULL, buffer, "Dicey.exe", MB_OK);
        return E_FAIL;
    }

	if(D3D_OK !=g_pd3dDevice->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA ))
	{
		char buffer[256];
		sprintf(buffer, "SetRenderState( D3DRS_SRCBLEND failed: %i", GetLastError());
		MessageBox(NULL, buffer, "Dicey.exe", MB_OK);
        return E_FAIL;
    }

	if(D3D_OK !=g_pd3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA ))
	{
		char buffer[256];
		sprintf(buffer, "SetRenderState( D3DRS_DESTBLEND failed: %i", GetLastError());
		MessageBox(NULL, buffer, "Dicey.exe", MB_OK);
        return E_FAIL;
    }

    // Turn on the zbuffer
    if(D3D_OK !=g_pd3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE ))
	{
		char buffer[256];
		sprintf(buffer, "SetRenderState( D3DRS_ZENABLE failed: %i", GetLastError());
		MessageBox(NULL, buffer, "Dicey.exe", MB_OK);
        return E_FAIL;
    }

	LOGFONT logFont = {24,                  // Height
					   0,                   // Width (default)
					   0,                   // Escapeent angle
					   0,                   // Orientation Angle
					   FW_NORMAL,			// Weight
					   false,               // Italics
					   false,				// Underline
					   false,				// Strikout
					   DEFAULT_CHARSET,		// Char set
					   OUT_DEFAULT_PRECIS,		// Use Truetype font if available
					   CLIP_DEFAULT_PRECIS,	// CLipping precision
					   DEFAULT_QUALITY,     // Quality
					   DEFAULT_PITCH,		// Pitch
                       ""} ;			// Font name

	if(FAILED(D3DXCreateFontIndirect(g_pd3dDevice, &logFont, &g_pFont)))
	{
		printf("D3DXCreateFontIndirect failed: %i\n", GetLastError());
		return E_FAIL;
	}

	


	

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: InitGeometry()
// Desc: Create the textures and vertex buffers
//-----------------------------------------------------------------------------
HRESULT InitGeometry()
{
    // Use D3DX to create a texture from a file based image
    //if( FAILED( D3DXCreateTextureFromFile( g_pd3dDevice, "banana.bmp", &g_pTexture ) ) )
	if( FAILED( D3DXCreateTextureFromResource( g_pd3dDevice, NULL, MAKEINTRESOURCE(IDB_DIETEXTURE), &g_pDieTexture)))
	{
        // If texture is not in current folder, try parent folder
        //if( FAILED( D3DXCreateTextureFromFile( g_pd3dDevice, "..\\banana.bmp", &g_pTexture ) ) )
        //{
		char buffer[256];
		sprintf(buffer, "Couldnt create texture: %i", GetLastError());
            MessageBox(NULL, buffer, "Dicey.exe", MB_OK);
            return E_FAIL;
        //}
    }

    // Create the Die's vertex buffer.
    if( FAILED( g_pd3dDevice->CreateVertexBuffer( 24*sizeof(CUSTOMVERTEX),
                                                  0, D3DFVF_CUSTOMVERTEX,
                                                  D3DPOOL_DEFAULT, &g_pVBDie, NULL ) ) )
    {
        return E_FAIL;
    }

	// Create the Die's index buffer
	// Whoa... How was this even working before? I was creating an 
	// index buffer with a size of 36 BYTES, and filling it with 36 WORDS. Aagh!
	if( FAILED( g_pd3dDevice->CreateIndexBuffer( 72, 0, D3DFMT_INDEX16, D3DPOOL_MANAGED, &g_pIBDie, NULL ) ) )
		return E_FAIL;



    // Fill the die's vertex buffer.
    CUSTOMVERTEX* pVertices;
    if( FAILED( g_pVBDie->Lock( 0, 0, (void**)&pVertices, 0 ) ) )
        return E_FAIL;
	D3DXVECTOR3 p1 = D3DXVECTOR3( 0.5f, 0.5f, 0.5f );
	D3DXVECTOR3 p2 = D3DXVECTOR3( -0.5f, 0.5f, 0.5f );
	D3DXVECTOR3 p3 = D3DXVECTOR3( -0.5f, -0.5f, 0.5f );
	D3DXVECTOR3 p4 = D3DXVECTOR3( 0.5f, -0.5f, 0.5f );
	D3DXVECTOR3 p5 = D3DXVECTOR3( 0.5f, 0.5f, -0.5f );
	D3DXVECTOR3 p6 = D3DXVECTOR3( -0.5f, 0.5f, -0.5f );
	D3DXVECTOR3 p7 = D3DXVECTOR3( -0.5f, -0.5f, -0.5f );
	D3DXVECTOR3 p8 = D3DXVECTOR3( 0.5f, -0.5f, -0.5f );

	D3DXVECTOR3 n1 = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
	D3DXVECTOR3 n2 = D3DXVECTOR3( 1.0f, 0.0f, 0.0f );
	D3DXVECTOR3 n3 = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
	D3DXVECTOR3 n4 = D3DXVECTOR3( 0.0f, -1.0f, 0.0f );
	D3DXVECTOR3 n5 = D3DXVECTOR3( -1.0f, 0.0f, 0.0f );
	D3DXVECTOR3 n6 = D3DXVECTOR3( 0.0f, 0.0f, -1.0f );
  
	// Face 1
	pVertices[0].position = p1;
	pVertices[0].n = n3;
	pVertices[0].tu = 0.5f;
	pVertices[0].tv = 0.0f;
	pVertices[1].position = p2;
	pVertices[1].n = n3;
	pVertices[1].tu = 0.0f;
	pVertices[1].tv = 0.0f;
	pVertices[2].position = p3;
	pVertices[2].n = n3;
	pVertices[2].tu = 0.0f;
	pVertices[2].tv = 0.33333333f;
	pVertices[3].position = p4;
	pVertices[3].n = n3;
	pVertices[3].tu = 0.5f;
	pVertices[3].tv = 0.33333333f;

	// Face 2 - #5
	pVertices[4].position = p5;
	pVertices[4].n = n2;
	pVertices[4].tu = 0.5f;
	pVertices[4].tv = 0.6666666666f;
	pVertices[5].position = p1;
	pVertices[5].n = n2;
	pVertices[5].tu = 0.0f;
	pVertices[5].tv = 0.666666666f;
	pVertices[6].position = p4;
	pVertices[6].n = n2;
	pVertices[6].tu = 0.0f;
	pVertices[6].tv = 1.0f;
	pVertices[7].position = p8;
	pVertices[7].n = n2;
	pVertices[7].tu = 0.5f;
	pVertices[7].tv = 1.0f;

	// Face 3
	pVertices[8].position = p5;
	pVertices[8].n = n1;
	pVertices[8].tu = 0.5f;
	pVertices[8].tv = 0.333333333f;
	pVertices[9].position = p6;
	pVertices[9].n = n1;
	pVertices[9].tu = 0.0f;
	pVertices[9].tv = 0.333333333f;
	pVertices[10].position = p2;
	pVertices[10].n = n1;
	pVertices[10].tu = 0.0f;
	pVertices[10].tv = 0.666666666f;
	pVertices[11].position = p1;
	pVertices[11].n = n1;
	pVertices[11].tu = 0.5f;
	pVertices[11].tv = 0.666666666f;

	// Face 4 #2
	pVertices[12].position = p2;
	pVertices[12].n = n5;
	pVertices[12].tu = 1.0f;
	pVertices[12].tv = 0.0f;
	pVertices[13].position = p6;
	pVertices[13].n = n5;
	pVertices[13].tu = 0.5f;
	pVertices[13].tv = 0.0f;
	pVertices[14].position = p7;
	pVertices[14].n = n5;
	pVertices[14].tu = 0.5f;
	pVertices[14].tv = 0.333333333f;
	pVertices[15].position = p3;
	pVertices[15].n = n5;
	pVertices[15].tu = 1.0f;
	pVertices[15].tv = 0.333333333f;

	// Face 5
	pVertices[16].position = p6;
	pVertices[16].n = n6;
	pVertices[16].tu = 1.0f;
	pVertices[16].tv = 0.66666666f;
	pVertices[17].position = p5;
	pVertices[17].n = n6;
	pVertices[17].tu = 0.5f;
	pVertices[17].tv = 0.66666666f;
	pVertices[18].position = p8;
	pVertices[18].n = n6;
	pVertices[18].tu = 0.5f;
	pVertices[18].tv = 1.0f;
	pVertices[19].position = p7;
	pVertices[19].n = n6;
	pVertices[19].tu = 1.0f;
	pVertices[19].tv = 1.0f;

	// Face 6
	pVertices[20].position = p7;
	pVertices[20].n = n4;
	pVertices[20].tu = 1.0f;
	pVertices[20].tv = 0.33333333f;
	pVertices[21].position = p8;
	pVertices[21].n = n4;
	pVertices[21].tu = 0.5f;
	pVertices[21].tv = 0.33333333f;
	pVertices[22].position = p4;
	pVertices[22].n = n4;
	pVertices[22].tu = 0.5f;
	pVertices[22].tv = 0.666666666f;
	pVertices[23].position = p3;
	pVertices[23].n = n4;
	pVertices[23].tu = 1.0f;
	pVertices[23].tv = 0.666666666f;

    g_pVBDie->Unlock();

	//Fill Die's index buffer
	WORD* pIndices;
	if( FAILED( g_pIBDie->Lock( 0, 72, (void**)&pIndices, 0 ) ) )
	   return E_FAIL;
	
	// Vertex indices for the die
    pIndices[ 0] = 0; pIndices[ 1] =  1; pIndices[ 2] =  3;
    pIndices[ 3] =  3; pIndices[ 4] =  1; pIndices[ 5] =  2;

    pIndices[ 6] =  4; pIndices[ 7] =  5; pIndices[ 8] =  7;
    pIndices[ 9] =  7; pIndices[10] =  5; pIndices[11] =  6;

	pIndices[18] = 12; pIndices[19] = 13; pIndices[20] = 15;
    pIndices[21] = 15; pIndices[22] = 13; pIndices[23] = 14;

    pIndices[24] = 16; pIndices[25] = 17; pIndices[26] = 19;
    pIndices[27] = 19; pIndices[28] = 17; pIndices[29] = 18;

    pIndices[12] =  8; pIndices[13] =  9; pIndices[14] =  11;
    pIndices[15] =  11; pIndices[16] =  9; pIndices[17] =  10;
    

	pIndices[30] = 20; pIndices[31] = 21; pIndices[32] = 23;
    pIndices[33] = 23; pIndices[34] = 21; pIndices[35] = 22;
	g_pIBDie->Unlock();


	// Setup player "model". ha.
	p1 = D3DXVECTOR3(0,0,0);
	p2 = D3DXVECTOR3(.2f,.5,0);
	p3 = D3DXVECTOR3(0,1.0,0);
	p4 = D3DXVECTOR3(-.2f,.5,0.0);
	p5 = D3DXVECTOR3(0,.5,.5);

	n1 = D3DXVECTOR3(0,0,-1);
	n2 = D3DXVECTOR3(.870388279f,.3481553119f,.3481553119f);
	n3 = D3DXVECTOR3(-.870388279f,.3481553119f,.3481553119f);
	n4 = D3DXVECTOR3(-.870388279f,-.3481553119f,.3481553119f);
	n5 = D3DXVECTOR3(.870388279f,-.3481553119f,.3481553119f);

	 // Create the Player's vertex buffer
    if( FAILED( g_pd3dDevice->CreateVertexBuffer( 18*sizeof(CUSTOMVERTEX),
                                                  0, D3DFVF_CUSTOMVERTEX,
                                                  D3DPOOL_DEFAULT, &g_pVBPlayer, NULL ) ) )
	{
		printf("Player CreateVertexBuffer failed: %i\n", GetLastError());
        return E_FAIL;
	}

    if( FAILED( g_pVBPlayer->Lock( 0, 0, (void**)&pVertices, 0 ) ) )
        return E_FAIL;

	pVertices[0].position = p1;
	pVertices[0].n = n1;
	pVertices[2].position = p2;
	pVertices[2].n = n1;
	pVertices[1].position = p4;
	pVertices[1].n = n1;
	pVertices[4].position = p4;
	pVertices[4].n = n1;
	pVertices[3].position = p2;
	pVertices[3].n = n1;
	pVertices[5].position = p3;
	pVertices[5].n = n1;

	pVertices[7].position = p3;
	pVertices[7].n = n2;
	pVertices[6].position = p2;
	pVertices[6].n = n2;
	pVertices[8].position = p5;
	pVertices[8].n = n2;

	pVertices[10].position = p2;
	pVertices[10].n = n5;
	pVertices[9].position = p1;
	pVertices[9].n = n5;
	pVertices[11].position = p5;
	pVertices[11].n = n5;

	pVertices[12].position = p4;
	pVertices[12].n = n4;
	pVertices[13].position = p1;
	pVertices[13].n = n4;
	pVertices[14].position = p5;
	pVertices[14].n = n4;

	pVertices[15].position = p3;
	pVertices[15].n = n3;
	pVertices[16].position = p4;
	pVertices[16].n = n3;
	pVertices[17].position = p5;
	pVertices[17].n = n3;

	g_pVBPlayer->Unlock();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: Cleanup()
// Desc: Releases all previously initialized objects
//-----------------------------------------------------------------------------
VOID Cleanup()
{
	printf("Cleanup()\n");
	int i;

    if( g_pDieTexture != NULL )
        g_pDieTexture->Release();
	g_pDieTexture = NULL;

    if( g_pVBDie != NULL )
        g_pVBDie->Release();
	g_pVBDie = NULL;
	
	if( g_pIBDie != NULL )
        g_pIBDie->Release();
	g_pIBDie = NULL;

    if( g_pd3dDevice != NULL )
		g_pd3dDevice->Release();
	g_pd3dDevice = NULL;

	if(g_pFont!= NULL)
		g_pFont->Release();
	g_pFont = NULL;

    if( g_pD3D != NULL )
        g_pD3D->Release();
	g_pD3D = NULL;

	

	for(i = 0; i < CLUNK_BUFFERS; i++)
	{
		if(g_pSBClunk[i] != NULL)
			g_pSBClunk[i]->Release();
		g_pSBClunk[i] = NULL;
	}
	for(i = 0; i < SLIDE_BUFFERS; i++)
	{
		if(g_pSBSlide[i] != NULL)
			g_pSBSlide[i]->Release();
		g_pSBSlide[i] = NULL;
	}
	for(i = 0; i < ZAP_BUFFERS; i++)
	{
		if(g_pSBZap[i] != NULL)
			g_pSBZap[i]->Release();
		g_pSBZap[i] = NULL;
	}
	if(g_pSBGameOver != NULL)
		g_pSBGameOver->Release();
	g_pSBGameOver = NULL;

	if(g_pDS != NULL)
        g_pDS->Release();
	g_pDS = NULL;

	DICleanup();


	
}
//-----------------------------------------------------------------------------
// Name: SetupMatrices()
// Desc: Sets up the world, view, and projection transform matrices.
//-----------------------------------------------------------------------------
VOID SetupMatrices()
{
    // For our world matrix, we will just leave it as the identity
    D3DXMATRIXA16 matWorld;
    D3DXMatrixIdentity( &matWorld );
    if(g_pd3dDevice->SetTransform( D3DTS_WORLD, &matWorld ) != D3D_OK)
		MessageBox(NULL, "SetTransform( D3DTS_WORLD...) failed","Dicey.exe", MB_OK);

    // Set up our view matrix. A view matrix can be defined given an eye point,
    // a point to lookat, and a direction for which way is up. Here, we set the
    // eye five units back along the z-axis and up three units, look at the
    // origin, and define "up" to be in the y-direction.
    D3DXVECTOR3 vEyePt( 0.0f, 3.0f,-5.0f );
    D3DXVECTOR3 vLookatPt( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec( 0.0f, 1.0f, 0.0f );
    D3DXMATRIXA16 matView;
	D3DXMatrixLookAtLH( &matView,
						&g_vCameraPos,//&D3DXVECTOR3( 5.924799f, 6.815144f, -6.485535f ),
						&D3DXVECTOR3( 0.0f, 0.0f, 0.0f ),
						&D3DXVECTOR3( 0.0f, 1.0f, 0.0f ) );
    //D3DXMatrixLookAtLH( &matView, &vEyePt, &vLookatPt, &vUpVec );
    g_pd3dDevice->SetTransform( D3DTS_VIEW, &matView );

    // For the projection matrix, we set up a perspective transform (which
    // transforms geometry from 3D view space to 2D viewport space, with
    // a perspective divide making objects smaller in the distance). To build
    // a perpsective transform, we need the field of view (1/4 pi is common),
    // the aspect ratio, and the near and far clipping planes (which define at
    // what distances geometry should be no longer be rendered).
	
    D3DXMATRIXA16 matProj;
	if(g_fPerspective)
		D3DXMatrixPerspectiveFovLH( &matProj, g_fFOV, g_fAspect, 1.0f, 100.0f );
	else
        D3DXMatrixOrthoLH( &matProj, g_orthoSize, g_orthoSize/g_fAspect, 0, 100);
    g_pd3dDevice->SetTransform( D3DTS_PROJECTION, &matProj );
}

// Draw the Die at the correct orientation, based on its mode
// Only changes wolrd transform, and does a DrawIndexedPrimitive.
// Calling function is responsible for other setup
HRESULT DrawCube(int mode, D3DXMATRIX *pos)//float x, float y, float z)
{
	D3DXMATRIX   trans,rot,temp;
	D3DXMatrixIdentity(&rot);
	//D3DXMatrixTranslation(&trans,x,y,z);
	switch(mode)
	{
	case 0:
		D3DXMatrixRotationX(&temp, -D3DX_PI/2);
		rot = temp;
		D3DXMatrixRotationY(&temp, D3DX_PI);
		rot *= temp;
		break;
	case 1:
		D3DXMatrixRotationZ(&temp, -D3DX_PI/2);
		rot = temp;
		D3DXMatrixRotationX(&temp, -D3DX_PI/2);
		rot *= temp;
		break;
	case 2:
		D3DXMatrixRotationX(&temp, -D3DX_PI/2);
		rot = temp;
		break;
	case 3:
		D3DXMatrixRotationZ(&temp, D3DX_PI/2);
		rot = temp;
		D3DXMatrixRotationX(&temp, -D3DX_PI/2);
		rot *= temp;
		break;
	case 4:
		D3DXMatrixRotationX(&temp, D3DX_PI/2);
		rot = temp;
		D3DXMatrixRotationZ(&temp, -D3DX_PI/2);
		rot *= temp;
		break;
	case 5:
		D3DXMatrixRotationZ(&temp, -D3DX_PI/2);
		rot = temp;
		break;
	case 6:
		D3DXMatrixRotationX(&temp, -D3DX_PI/2);
		rot = temp;
		D3DXMatrixRotationZ(&temp, -D3DX_PI/2);
		rot *= temp;
		break;
	case 7:
		D3DXMatrixRotationX(&temp, D3DX_PI);
		rot = temp;
		D3DXMatrixRotationZ(&temp, -D3DX_PI/2);
		rot *= temp;
		break;
	case 8:
		D3DXMatrixRotationY(&temp, D3DX_PI);
		rot = temp;
		break;
	case 9:
		D3DXMatrixRotationY(&temp, -D3DX_PI/2);
		rot = temp;
		break;
	case 10:
		break;
	case 11:
		D3DXMatrixRotationY(&temp, D3DX_PI/2);
		rot = temp;
		break;
	case 12:
		D3DXMatrixRotationX(&temp, D3DX_PI);
		rot = temp;
		break;
	case 13:
		D3DXMatrixRotationX(&temp, D3DX_PI);
		rot = temp;
		D3DXMatrixRotationY(&temp, D3DX_PI/2);
		rot *= temp;
		break;
	case 14:
		D3DXMatrixRotationX(&temp, D3DX_PI);
		rot = temp;
		D3DXMatrixRotationY(&temp, D3DX_PI);
		rot *= temp;
		break;
	case 15:
		D3DXMatrixRotationX(&temp, D3DX_PI);
		rot = temp;
		D3DXMatrixRotationY(&temp, -D3DX_PI/2);
		rot *= temp;
		break;
	case 16:
		D3DXMatrixRotationX(&temp, D3DX_PI/2);
		rot = temp;
		D3DXMatrixRotationZ(&temp, D3DX_PI/2);
		rot *= temp;
		break;
	case 17:
		D3DXMatrixRotationX(&temp, D3DX_PI);
		rot = temp;
		D3DXMatrixRotationZ(&temp, D3DX_PI/2);
		rot *= temp;
		break;
	case 18:
		D3DXMatrixRotationX(&temp, -D3DX_PI/2);
		rot = temp;
		D3DXMatrixRotationZ(&temp, D3DX_PI/2);
		rot *= temp;
		break;
	case 19:
		D3DXMatrixRotationZ(&temp, D3DX_PI/2);
		rot = temp;
		break;
	case 20:
		D3DXMatrixRotationX(&temp, D3DX_PI/2);
		rot = temp;
		break;
	case 21:
		D3DXMatrixRotationX(&temp, D3DX_PI/2);
		rot = temp;
		D3DXMatrixRotationY(&temp, D3DX_PI/2);
		rot *= temp;
		break;
	case 22:
		D3DXMatrixRotationX(&temp, D3DX_PI/2);
		rot = temp;
		D3DXMatrixRotationY(&temp, D3DX_PI);
		rot *= temp;
		break;
	case 23:
		D3DXMatrixRotationX(&temp, D3DX_PI/2);
		rot = temp;
		D3DXMatrixRotationY(&temp, -D3DX_PI/2);
		rot *= temp;
		break;
	default:
		break;
	}
		
		
		temp = rot * *pos;
		g_pd3dDevice->SetTransform(D3DTS_WORLD, &temp);

	// Set stream source to the Circle's vertices
		//m_pd3dDevice->SetStreamSource( 0, m_pBoxVB, sizeof(CUSTOMVERTEX) );
		

		//m_pd3dDevice->SetIndices( m_pBoxIB, 0 );

		if(D3D_OK !=g_pd3dDevice->DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 
											0,
											0,
											24,  // number of vertices
                                            0, 
											12)) // number of primitives
		{
			printf("DrawCube failed: %i\n", GetLastError());
		}
		return S_OK;

}

HRESULT MovePlayerStraight(int playerNum, Direction dir, DWORD time, int x, int y, D3DXMATRIX *pos)
{
	D3DXMATRIX temp;
	FLOAT playerY;
	int nx,ny;

	// Figure out next die position
	switch(dir)
	{
	case UP:
		nx = x;
		ny = y -1;
		break;
	case DOWN:
		nx = x;
		ny = y +1;
		break;
	case LEFT:
		nx = x-1;
		ny = y;
		break;
	case RIGHT:
		nx = x+1;
		ny = y;
		break;
	default:
		nx= 0;
		ny = 0;
	}

	// Need to figure out the player's y position
	if(time < SLIDE_TIME/2)
	{
		if(g_pGame->m_players[playerNum].smashed)
			playerY = 0.0f;
		else if(g_pGame->m_gameboard[x][y].state == FREE)
			playerY = 0.0f;
		else if (g_pGame->m_gameboard[x][y].state == OCCUPIED)
			playerY = 1.0f;
		else if (g_pGame->m_gameboard[x][y].state == SLIDE_FROM)
			playerY = 1.0f;
		else if (g_pGame->m_gameboard[x][y].state == SLIDE_TO)
			playerY = 0.0f;
		else if (g_pGame->m_gameboard[x][y].state == ROLL_TO)
			playerY = 0.0f; // Player is on ground, maybe getting smashed
		else
			playerY = g_pGame->m_gameboard[x][y].y;
	}
	else
	{
		if(g_pGame->m_gameboard[nx][ny].state == SLIDE_FROM) // fix sliding anamoly
		{
			//printf("On slider fix..\n");
			playerY = 0.0f;
		}
		else if(g_pGame->m_gameboard[nx][ny].state == FREE)
			playerY = 0.0f;
		else if (g_pGame->m_gameboard[nx][ny].state == OCCUPIED)
			playerY = 1.0f;
		else if (g_pGame->m_gameboard[nx][ny].state == SLIDE_TO)
			playerY = 1.0f;
		else if (g_pGame->m_gameboard[nx][ny].state == ROLL_TO)
			playerY = 0.0f; // PLayer is on ground, about to be smashed. Haha!
		else
			playerY = g_pGame->m_gameboard[nx][ny].y;
	}


	switch(dir)
	{
	case UP:
		D3DXMatrixTranslation(&temp, 0,playerY,(float)time/(float)SLIDE_TIME);
		break;
	case DOWN:
		D3DXMatrixTranslation(&temp, 0,playerY,-(float)time/(float)SLIDE_TIME);
		break;
	case LEFT:
		D3DXMatrixTranslation(&temp, -(float)time/(float)SLIDE_TIME,playerY,0);
		break;
	case RIGHT:
		D3DXMatrixTranslation(&temp, (float)time/(float)SLIDE_TIME,playerY,0);
		break;
	default:
		D3DXMatrixTranslation(&temp, 0,5,0); // This should never be called
		break;
	}

	*pos =  temp* *pos ;

	return S_OK;
}

HRESULT MovePlayerArc(Direction dir, DWORD time, D3DXMATRIX *pos)
{
	D3DXMATRIX temp;
	FLOAT playerY;
	FLOAT x = (float)time/(float)ROLL_TIME;

	// Make the y values an arc based on x
	playerY = 1.0f-(1.656854249f*(x*(x-1.0f)));

	switch(dir)
	{
	case UP:
		D3DXMatrixTranslation(&temp, 0,playerY,(float)time/(float)SLIDE_TIME);
		break;
	case DOWN:
		D3DXMatrixTranslation(&temp, 0,playerY,-(float)time/(float)SLIDE_TIME);
		break;
	case LEFT:
		D3DXMatrixTranslation(&temp, -(float)time/(float)SLIDE_TIME,playerY,0);
		break;
	case RIGHT:
		D3DXMatrixTranslation(&temp, (float)time/(float)SLIDE_TIME,playerY,0);
		break;
	default:
		D3DXMatrixTranslation(&temp, 0,5,0); // This should never be called
		break;
	}

	*pos =  temp* *pos ;

	return S_OK;
}

HRESULT RollMatrix(Direction dir, DWORD time, D3DXMATRIX *pos)
{
	//printf("Rolling. Time: %i \n", time); 
	D3DXMATRIX   trans,rot,temp,temp2;
	D3DXMatrixIdentity(&rot);

	//D3DXMatrixTranslation(&trans,x,y,z);



	switch(dir)
	{
	case UP:
		D3DXMatrixTranslation(&temp,0,0.5,-0.5);
		D3DXMatrixRotationX(&temp2, ((float)time/(float)ROLL_TIME)*(D3DX_PI/2));
		temp *= temp2;
		D3DXMatrixTranslation(&temp2,0,-0.5,0.5);
		temp *= temp2;
		break;
	case DOWN:
		D3DXMatrixTranslation(&temp,0,0.5,0.5);
		D3DXMatrixRotationX(&temp2, -((float)time/(float)ROLL_TIME)*(D3DX_PI/2));
		temp *= temp2;
		D3DXMatrixTranslation(&temp2,0,-0.5,-0.5);
		temp *= temp2;
		break;
	case LEFT:
		D3DXMatrixTranslation(&temp,0.5,0.5,0);
		D3DXMatrixRotationZ(&temp2, ((float)time/(float)ROLL_TIME)*(D3DX_PI/2));
		temp *= temp2;
		D3DXMatrixTranslation(&temp2,-0.5,-0.5,0);
		temp *= temp2;
		break;
	case RIGHT:
		D3DXMatrixTranslation(&temp,-0.5,0.5,0);
		D3DXMatrixRotationZ(&temp2, -((float)time/(float)ROLL_TIME)*(D3DX_PI/2));
		temp *= temp2;
		D3DXMatrixTranslation(&temp2,0.5,-0.5,0);
		temp *= temp2;
		break;
	default:
		break;
	}

	*pos =  temp* *pos ;
	//DrawCube(mode, &temp);

	return S_OK;
}

HRESULT RotatePlayer(Direction dir, D3DXMATRIX *pos)
{
	D3DXMATRIX temp;
	switch(dir)
	{
	case UP:
		D3DXMatrixIdentity(&temp);
		break; // no rotation needed
	case DOWN:
		D3DXMatrixRotationY(&temp, D3DX_PI);
		break;
	case RIGHT:
		D3DXMatrixRotationY(&temp, D3DX_PI/2.0f);
		break;
	case LEFT:
		D3DXMatrixRotationY(&temp, -D3DX_PI/2.0f);
		break;
	}

	*pos = temp * *pos;

	return S_OK;
}

HRESULT SlideMatrix(int dir, DWORD time, D3DXMATRIX *pos)//float x, float y, float z)
{
	//printf("Sliding - time: %i\n", time);
	D3DXMATRIX   temp;
	//D3DXMatrixIdentity(&rot);
	//D3DXMatrixTranslation(&trans,x,y,z);
	switch(dir)
	{
	case UP:
		D3DXMatrixTranslation(&temp,0,0,time/(float)SLIDE_TIME);
		break;
	case DOWN:
		D3DXMatrixTranslation(&temp,0,0,-(time/(float)SLIDE_TIME));
		break;
	case LEFT:
		D3DXMatrixTranslation(&temp,-(time/(float)SLIDE_TIME),0,0);
		break;
	case RIGHT:
		D3DXMatrixTranslation(&temp,time/(float)SLIDE_TIME,0,0);
		break;
	default:
		break;
	}

	*pos = temp * *pos;

	return S_OK;
}

//VOID DrawFrame()
//{
	

	

//}

// This isnt very effienct... But it sets a
// material using a D3DCOLOR. Lookie at all those floating point divides!
HRESULT SetMaterial(D3DCOLOR color)
{
	D3DMATERIAL9 mtrl;
	ZeroMemory( &mtrl, sizeof(D3DMATERIAL9) );
    mtrl.Diffuse.r = mtrl.Ambient.r = ((color & 0xFF0000) >> 16)/255.0f;
    mtrl.Diffuse.g = mtrl.Ambient.g = ((color & 0xFF00) >> 8)/255.0f;
    mtrl.Diffuse.b = mtrl.Ambient.b = (color & 0xFF)/255.0f;
    mtrl.Diffuse.a = mtrl.Ambient.a = ((color & 0xFF000000) >> 24)/255.0f;
	g_pd3dDevice->SetMaterial( &mtrl );

	return S_OK;
}

// Also not very effienct... But it sets a
// material using a D3DCOLOR, replacing the alpha value.
HRESULT SetMaterial(D3DCOLOR color, unsigned char alpha)
{
	D3DMATERIAL9 mtrl;
	ZeroMemory( &mtrl, sizeof(D3DMATERIAL9) );
    mtrl.Diffuse.r = mtrl.Ambient.r = ((color & 0xFF0000) >> 16)/255.0f;
    mtrl.Diffuse.g = mtrl.Ambient.g = ((color & 0xFF00) >> 8)/255.0f;
    mtrl.Diffuse.b = mtrl.Ambient.b = (color & 0xFF)/255.0f;
    mtrl.Diffuse.a = mtrl.Ambient.a = alpha/255.0f;
	g_pd3dDevice->SetMaterial( &mtrl );

	return S_OK;
}

//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Draws the scene
//-----------------------------------------------------------------------------
VOID Render()
{

	int i,j;
	char buffer[256];
	DWORD dwStatus;
	D3DMATERIAL9 mtrl;
	D3DXMATRIX   matIdent;
	D3DXMATRIX	 temp;
	D3DXMATRIX temp2;
	float tempX, tempY, tempZ;
	
	
	// For debugging
	static bool aistate = false;
	if(g_pGame->m_players[0].AI != aistate)
	{
		printf("AI state changed\n");
		aistate = g_pGame->m_players[0].AI;
	}


	D3DXMatrixIdentity(&matIdent);
	// Whip up a material 
	//D3DUtil_InitMaterial( mtrl, 1, 0, 0 );
    ZeroMemory( &mtrl, sizeof(D3DMATERIAL9) );
    mtrl.Diffuse.r = mtrl.Ambient.r = 1;
    mtrl.Diffuse.g = mtrl.Ambient.g = 1;
    mtrl.Diffuse.b = mtrl.Ambient.b = 1;
    mtrl.Diffuse.a = mtrl.Ambient.a = 1;

	SetupMatrices();
	
    // Clear the backbuffer and the zbuffer
    //printf("ping!\n");
	if(FAILED(g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,
                         D3DCOLOR_XRGB(0,0,0), 1.0f, 0 )))
	{
		printf("g_pd3dDevice->Clear failed: %i\n", GetLastError());
		return;
	}


	// Set the material
	if(FAILED(g_pd3dDevice->SetMaterial( &mtrl )))
	{
		printf("g_pd3dDevice->SetMaterial failed: %i\n", GetLastError());
		return;
	}


    // Begin the scene
    if( SUCCEEDED( g_pd3dDevice->BeginScene() ) )
    {
		
       
		if(FAILED(g_pd3dDevice->SetTexture( 0, g_pDieTexture )))
		{
			printf("g_pd3dDevice->Clear failed: %i\n", GetLastError());
			return;
		}
		if(FAILED(g_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,  D3DTOP_MODULATE )))
		{
			printf("g_pd3dDevice->Clear failed: %i\n", GetLastError());
			return;
		}
		if(FAILED(g_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE )))
		{
			printf("g_pd3dDevice->Clear failed: %i\n", GetLastError());
			return;
		}
		if(FAILED(g_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE )))
		{
			printf("g_pd3dDevice->Clear failed: %i\n", GetLastError());
			return;
		}
		if(FAILED(g_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP, D3DTOP_BLENDDIFFUSEALPHA )))
		{
			printf("g_pd3dDevice->Clear failed: %i\n", GetLastError());
			return;
		}

		g_pd3dDevice->SetSamplerState(0, D3DSAMP_MINFILTER,  D3DTEXF_LINEAR  );
		g_pd3dDevice->SetSamplerState(0, D3DSAMP_MAGFILTER,  D3DTEXF_LINEAR   );
		g_pd3dDevice->SetSamplerState(0, D3DSAMP_MIPFILTER,  D3DTEXF_LINEAR   );

		if(D3D_OK != g_pd3dDevice->SetFVF( D3DFVF_CUSTOMVERTEX ))
		{
			printf("g_pd3dDevice->SetFVF failed: %i\n", GetLastError());
			return;
		}
		//g_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
		//g_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
		//printf("ping2b\n");
		// Render the vertex buffer contents
		if(FAILED(g_pd3dDevice->SetStreamSource( 0, g_pVBDie, 0, sizeof(CUSTOMVERTEX) )))
		{
			printf("g_pd3dDevice->Clear failed: %i\n", GetLastError());
			return;
		}
		//printf("ping2b\n");
		if(FAILED(g_pd3dDevice->SetIndices( g_pIBDie)))
		{
			printf("g_pd3dDevice->Clear failed: %i\n", GetLastError());
			return;
		}

		
		
		//printf("ping2b\n");g
		// Looky how lazy I am! I'm using a die for the floor! Ha!
		D3DXMatrixTransformation(&temp, &D3DXVECTOR3(0.0,0.0,0.0),NULL, &D3DXVECTOR3((float)g_pGame->m_boardSize,1.0,(float)g_pGame->m_boardSize), NULL, NULL, &D3DXVECTOR3(0.0,-.5,0.0));
		//printf("ping2b\n");
		DrawCube(23, &temp);

		// After the floor is drawn, display "Paused" if needed
		// and then stop rendering. Dont let the player use pause to plan moves.
		// Dang cheaters.
		if(g_fPaused)
		{
			sprintf(buffer, "PAUSED", g_pGame->m_level);
			SetRect(&FontRect, 350, 10, 0, 0);
			if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, 0xffffffff)))
				printf("g_pFont->DrawText failed: %i\n", GetLastError());

			// End the scene, present it, and return
			g_pd3dDevice->EndScene();
			if(FAILED(g_pd3dDevice->Present( NULL, NULL, NULL, NULL )))
				printf("Present failed: %i\n", GetLastError());
			return;
		}

		// Draw all occupied spaces
		for(i = 0; i < g_pGame->m_boardSize; i++)
		{
			for( j = 0; j < g_pGame->m_boardSize; j++)
			{
				
				if ( g_pGame->m_gameboard[i][j].state == OCCUPIED)
				{
					D3DXMatrixTranslation(&temp, i-((g_pGame->m_boardSize-1)/2.0f),0.5,((g_pGame->m_boardSize-1)/2.0f)-j);
					DrawCube(g_pGame->m_gameboard[i][j].dieState,&temp);
				}
			}
		}
		
		for(i = 0; i < g_pGame->m_numPlayers; i++)
		{
			//printf("player %i is at %i %i with dir of %i\n", i, g_pGame->m_players[i].boardX, g_pGame->m_players[i].boardY, g_pGame->m_players[i].dir);
			

			if(g_pGame->m_players[i].idle)
			{
				//D3DXMatrixTranslation(&temp, g_pGame->m_players[i].boardX-((g_pGame->m_boardSize-1)/2.0f),1.5,((g_pGame->m_boardSize-1)/2.0f)-g_pGame->m_players[i].boardY);
				GamePosState tempState = g_pGame->m_gameboard[g_pGame->m_players[i].boardX][g_pGame->m_players[i].boardY].state;
				if(g_pGame->m_players[i].smashed)
					tempState = FREE;
				
				tempX = g_pGame->m_players[i].boardX-((g_pGame->m_boardSize-1)/2.0f)+g_pGame->m_players[i].offsetX;
				tempZ = ((g_pGame->m_boardSize-1)/2.0f)-g_pGame->m_players[i].boardY+g_pGame->m_players[i].offsetZ;

				switch(tempState)
				{
				case OCCUPIED:					
					tempY = 1.0;

					//D3DXMatrixTransformation(&temp, &D3DXVECTOR3(0,0,0),NULL, &D3DXVECTOR3(.5,.5,.5), NULL, NULL, &D3DXVECTOR3(g_pGame->m_players[i].boardX-((g_pGame->m_boardSize-1)/2.0f)+g_pGame->m_players[i].offsetX,1.25,((g_pGame->m_boardSize-1)/2.0f)-g_pGame->m_players[i].boardY+g_pGame->m_players[i].offsetZ));
					break;
				case FREE:
				case ROLL_TO:
				case SLIDE_TO:
					tempY = 0.0;
					//D3DXMatrixTransformation(&temp, &D3DXVECTOR3(0,0,0),NULL, &D3DXVECTOR3(.5,.5,.5), NULL, NULL, &D3DXVECTOR3(g_pGame->m_players[i].boardX-((g_pGame->m_boardSize-1)/2.0f),.25,((g_pGame->m_boardSize-1)/2.0f)-g_pGame->m_players[i].boardY));
					break;
				case RISING:
				case SINKING:
					tempY = (float)g_pGame->m_gameboard[g_pGame->m_players[i].boardX][g_pGame->m_players[i].boardY].y;
					//D3DXMatrixTransformation(&temp, &D3DXVECTOR3(0.0,0.0,0.0),NULL, &D3DXVECTOR3(.5,.5,.5), NULL, NULL, &D3DXVECTOR3((float)g_pGame->m_players[i].boardX-((g_pGame->m_boardSize-1)/2.0f),(float)g_pGame->m_gameboard[g_pGame->m_players[i].boardX][g_pGame->m_players[i].boardY].y + .25f,((g_pGame->m_boardSize-1)/2.0f)-g_pGame->m_players[i].boardY));
					break;
				default:
					tempX = 0;
					tempY = 3;
					tempZ = 0;
					break;
				}

				D3DXMatrixTransformation(&temp, &D3DXVECTOR3(0.0,0.0,0.0),NULL, &D3DXVECTOR3(.5,.5,.5), NULL, NULL, &D3DXVECTOR3(tempX,tempY,tempZ));
					
				RotatePlayer(g_pGame->m_players[i].facing, &temp);
				SetMaterial(g_pGame->m_players[i].color);
				g_pd3dDevice->SetTransform(D3DTS_WORLD, &temp);

				g_pd3dDevice->SetStreamSource( 0, g_pVBPlayer, 0, sizeof(CUSTOMVERTEX) );
		
				g_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLELIST, 
											0, 
											6); // number of primitives

				g_pd3dDevice->SetStreamSource( 0, g_pVBDie, 0, sizeof(CUSTOMVERTEX) );
				SetMaterial(0xFFFFFFFF);
				//DrawCube(i*4,&temp);
			}
		}
		//printf("ping4!\n");
		for(i = 0; i < (int)g_pGame->m_vEvents.size(); i++)
		{
			switch(g_pGame->m_vEvents[i].what)
			{
			case PL_MV_ARC_IN:
				D3DXMatrixTranslation(&temp, g_pGame->m_vEvents[i].boardX-((g_pGame->m_boardSize-1)/2.0f)+g_pGame->m_players[g_pGame->m_vEvents[i].arg1].offsetX,0,((g_pGame->m_boardSize-1)/2.0f)-g_pGame->m_vEvents[i].boardY+g_pGame->m_players[g_pGame->m_vEvents[i].arg1].offsetZ);
				MovePlayerArc((Direction)g_pGame->m_vEvents[i].arg2, ROLL_TIME - (g_pGame->m_vEvents[i].when - g_pGame->dwTime), &temp);
				RotatePlayer((Direction)g_pGame->m_vEvents[i].arg2, &temp);
				D3DXMatrixScaling(&temp2, .5,.5,.5);
				temp = temp2*temp;
				// Get player's rotation
				g_pd3dDevice->SetTransform(D3DTS_WORLD, &temp);
				SetMaterial(g_pGame->m_players[g_pGame->m_vEvents[i].arg1].color);
				g_pd3dDevice->SetStreamSource( 0, g_pVBPlayer, 0, sizeof(CUSTOMVERTEX) );
		
				g_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLELIST, 
											0, 
											6); // number of primitives

				g_pd3dDevice->SetStreamSource( 0, g_pVBDie, 0, sizeof(CUSTOMVERTEX) );
				SetMaterial(0xFFFFFFFF);
				//DrawCube(g_pGame->m_vEvents[i].arg1*4, &temp);
				break;
			case PL_MV_STR_IN:
				//D3DXMatrixTransformation(&temp, &D3DXVECTOR3(0,0,0),NULL, &D3DXVECTOR3(.5,.5,.5), NULL, NULL, &D3DXVECTOR3(g_pGame->m_players[i].boardX-((g_pGame->m_boardSize-1)/2.0f),.25,((g_pGame->m_boardSize-1)/2.0f)-g_pGame->m_players[i].boardY));
				
				D3DXMatrixTranslation(&temp, g_pGame->m_vEvents[i].boardX-((g_pGame->m_boardSize-1)/2.0f)+g_pGame->m_players[g_pGame->m_vEvents[i].arg1].offsetX,0,((g_pGame->m_boardSize-1)/2.0f)-g_pGame->m_vEvents[i].boardY+g_pGame->m_players[g_pGame->m_vEvents[i].arg1].offsetZ);
				
				MovePlayerStraight(g_pGame->m_vEvents[i].arg1, (Direction)g_pGame->m_vEvents[i].arg2, SLIDE_TIME - (g_pGame->m_vEvents[i].when - g_pGame->dwTime), g_pGame->m_vEvents[i].boardX, g_pGame->m_vEvents[i].boardY, &temp);
				RotatePlayer((Direction)g_pGame->m_vEvents[i].arg2, &temp);
				D3DXMatrixScaling(&temp2, .5,.5,.5);
				temp = temp2*temp;
				// Get player's rotation 
				g_pd3dDevice->SetTransform(D3DTS_WORLD, &temp);
				SetMaterial(g_pGame->m_players[g_pGame->m_vEvents[i].arg1].color);
				g_pd3dDevice->SetStreamSource( 0, g_pVBPlayer, 0, sizeof(CUSTOMVERTEX) );
		
				g_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLELIST, 
											0, 
											6); // number of primitives

				g_pd3dDevice->SetStreamSource( 0, g_pVBDie, 0, sizeof(CUSTOMVERTEX) );
				SetMaterial(0xFFFFFFFF);
				//DrawCube(g_pGame->m_vEvents[i].arg1*4, &temp);
				
				
				break;
			case PL_MV_ARC_OUT:
				D3DXMatrixTranslation(&temp, g_pGame->m_vEvents[i].boardX-((g_pGame->m_boardSize-1)/2.0f)+g_pGame->m_players[g_pGame->m_vEvents[i].arg1].offsetX,0,((g_pGame->m_boardSize-1)/2.0f)-g_pGame->m_vEvents[i].boardY+g_pGame->m_players[g_pGame->m_vEvents[i].arg1].offsetZ);
				MovePlayerArc((Direction)g_pGame->m_vEvents[i].arg2, ROLL_TIME - (g_pGame->m_vEvents[i].when - g_pGame->dwTime), &temp);
				RotatePlayer(g_pGame->m_players[g_pGame->m_vEvents[i].arg1].facing, &temp);
				D3DXMatrixScaling(&temp2, .5,.5,.5);
				temp = temp2*temp;
				// Get player's rotationc
				g_pd3dDevice->SetTransform(D3DTS_WORLD, &temp);
				SetMaterial(g_pGame->m_players[g_pGame->m_vEvents[i].arg1].color);
				g_pd3dDevice->SetStreamSource( 0, g_pVBPlayer, 0, sizeof(CUSTOMVERTEX) );
		
				g_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLELIST, 
											0, 
											6); // number of primitives

				g_pd3dDevice->SetStreamSource( 0, g_pVBDie, 0, sizeof(CUSTOMVERTEX) );
				SetMaterial(0xFFFFFFFF);
				//DrawCube(g_pGame->m_vEvents[i].arg1*4, &temp);
				break;
			case PL_MV_STR_OUT:
				//D3DXMatrixTranslation(&temp, g_pGame->m_vEvents[i].boardX-((g_pGame->m_boardSize-1)/2.0f),0,((g_pGame->m_boardSize-1)/2.0f)-g_pGame->m_vEvents[i].boardY);
				D3DXMatrixTranslation(&temp, g_pGame->m_vEvents[i].boardX-((g_pGame->m_boardSize-1)/2.0f)+g_pGame->m_players[g_pGame->m_vEvents[i].arg1].offsetX,0,((g_pGame->m_boardSize-1)/2.0f)-g_pGame->m_vEvents[i].boardY+g_pGame->m_players[g_pGame->m_vEvents[i].arg1].offsetZ);
				
				MovePlayerStraight(g_pGame->m_vEvents[i].arg1, (Direction)g_pGame->m_vEvents[i].arg2, SLIDE_TIME - (g_pGame->m_vEvents[i].when - g_pGame->dwTime), g_pGame->m_vEvents[i].boardX, g_pGame->m_vEvents[i].boardY, &temp);
				RotatePlayer(g_pGame->m_players[g_pGame->m_vEvents[i].arg1].facing, &temp);
				D3DXMatrixScaling(&temp2, .5,.5,.5);
				temp = temp2*temp;
				// Get player's rotation
				g_pd3dDevice->SetTransform(D3DTS_WORLD, &temp);
				SetMaterial(g_pGame->m_players[g_pGame->m_vEvents[i].arg1].color);
				g_pd3dDevice->SetStreamSource( 0, g_pVBPlayer, 0, sizeof(CUSTOMVERTEX) );
		
				g_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLELIST, 
											0, 
											6); // number of primitives

				g_pd3dDevice->SetStreamSource( 0, g_pVBDie, 0, sizeof(CUSTOMVERTEX) );
				SetMaterial(0xFFFFFFFF);
				//DrawCube(g_pGame->m_vEvents[i].arg1*4, &temp);
				break;
			case SLIDE:
				D3DXMatrixTranslation(&temp, g_pGame->m_vEvents[i].boardX-((g_pGame->m_boardSize-1)/2.0f),0.5,((g_pGame->m_boardSize-1)/2.0f)-g_pGame->m_vEvents[i].boardY);
				SlideMatrix(g_pGame->m_vEvents[i].arg2, SLIDE_TIME - (g_pGame->m_vEvents[i].when - g_pGame->dwTime),&temp); 
				DrawCube(g_pGame->m_gameboard[g_pGame->m_vEvents[i].boardX][g_pGame->m_vEvents[i].boardY].dieState,&temp);
			break;
			case ROLL:
				D3DXMatrixTranslation(&temp, g_pGame->m_vEvents[i].boardX-((g_pGame->m_boardSize-1)/2.0f),0.5,((g_pGame->m_boardSize-1)/2.0f)-g_pGame->m_vEvents[i].boardY);
				RollMatrix((Direction)g_pGame->m_vEvents[i].arg2, ROLL_TIME - (g_pGame->m_vEvents[i].when - g_pGame->dwTime),&temp); 
				DrawCube(g_pGame->m_gameboard[g_pGame->m_vEvents[i].boardX][g_pGame->m_vEvents[i].boardY].dieState,&temp);
				break;
			case SINK:
				// TODO: tint the die the appropriate color
				//printf("Sinking - Event #%i - %i,%i\n", i, g_pGame->m_vEvents[i].boardX, g_pGame->m_vEvents[i].boardY);
				D3DXMatrixTranslation(&temp, g_pGame->m_vEvents[i].boardX-((g_pGame->m_boardSize-1)/2.0f),g_pGame->m_gameboard[g_pGame->m_vEvents[i].boardX][g_pGame->m_vEvents[i].boardY].y-0.5f,((g_pGame->m_boardSize-1)/2.0f)-g_pGame->m_vEvents[i].boardY);
				SetMaterial(g_pGame->m_players[g_pGame->m_vEvents[i].arg2].diecolor);
				/*switch(g_pGame->m_vEvents[i].arg2)
				{
				case 0:
					mtrl.Diffuse.r = mtrl.Ambient.r = 1;
					mtrl.Diffuse.g = mtrl.Ambient.g = .4f;
					mtrl.Diffuse.b = mtrl.Ambient.b = .4f;
					mtrl.Diffuse.a = mtrl.Ambient.a = 1;
					break;
				case 1:
					mtrl.Diffuse.r = mtrl.Ambient.r = .4f;
					mtrl.Diffuse.g = mtrl.Ambient.g = .4f;
					mtrl.Diffuse.b = mtrl.Ambient.b = 1;
					mtrl.Diffuse.a = mtrl.Ambient.a = 1;
					break;
				default:
					break;
				}
				g_pd3dDevice->SetMaterial( &mtrl );*/
				if(g_pGame->m_gameboard[g_pGame->m_vEvents[i].boardX][g_pGame->m_vEvents[i].boardY].y < 0.5)
				{
					//FIXME!! Very inefficient to keep changing the render state
					// Also not very accurate, alphas should probably always be drawn last
					// Probably not a big deal. I hope.
					
					SetMaterial(g_pGame->m_players[g_pGame->m_vEvents[i].arg2].diecolor, 0x80);
					//mtrl.Diffuse.a = mtrl.Ambient.a = .5;
					//g_pd3dDevice->SetMaterial( &mtrl );
					DrawCube(g_pGame->m_gameboard[g_pGame->m_vEvents[i].boardX][g_pGame->m_vEvents[i].boardY].dieState,&temp);
					//g_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE );
				}
				else
					DrawCube(g_pGame->m_gameboard[g_pGame->m_vEvents[i].boardX][g_pGame->m_vEvents[i].boardY].dieState,&temp);
				mtrl.Diffuse.r = mtrl.Ambient.r = 1;
				mtrl.Diffuse.g = mtrl.Ambient.g = 1;
				mtrl.Diffuse.b = mtrl.Ambient.b = 1;
				mtrl.Diffuse.a = mtrl.Ambient.a = 1;

				// Set the material
				g_pd3dDevice->SetMaterial( &mtrl );
				break;
			case RISE:
				// Draw the "Theres a riser here!" flash
				// Yep, I'm using a cube again. :)
				if(RISE_TIME - (g_pGame->m_vEvents[i].when - g_pGame->dwTime) < 100)
				{
					D3DXMatrixTransformation(&temp, &D3DXVECTOR3(0,0,0),NULL, &D3DXVECTOR3(.2f,10,.2f), NULL, NULL, &D3DXVECTOR3(g_pGame->m_vEvents[i].boardX-((g_pGame->m_boardSize-1)/2.0f),5,((g_pGame->m_boardSize-1)/2.0f)-g_pGame->m_vEvents[i].boardY));
					DrawCube(g_pGame->m_vEvents[i].arg1,&temp);

				}
				if(g_pGame->m_gameboard[g_pGame->m_vEvents[i].boardX][g_pGame->m_vEvents[i].boardY].y < 0.5)
				{
					mtrl.Diffuse.a = mtrl.Ambient.a = .5;
					g_pd3dDevice->SetMaterial( &mtrl );
				}
				D3DXMatrixTranslation(&temp, 
					g_pGame->m_vEvents[i].boardX-((g_pGame->m_boardSize-1)/2.0f),
					g_pGame->m_gameboard[g_pGame->m_vEvents[i].boardX][g_pGame->m_vEvents[i].boardY].y -.5f,
					((g_pGame->m_boardSize-1)/2.0f)-g_pGame->m_vEvents[i].boardY);
				DrawCube(g_pGame->m_vEvents[i].arg1,&temp);
				mtrl.Diffuse.a = mtrl.Ambient.a = 1;
				g_pd3dDevice->SetMaterial( &mtrl );
				break;
			case PLAY_ROLL_END_SOUND:
				//DWORD dwStatus;
				for(j=0;j<CLUNK_BUFFERS;j++)
				{
					g_pSBClunk[j]->GetStatus(&dwStatus);
					if(!dwStatus &DSBSTATUS_PLAYING)
					{
						if(DS_OK != g_pSBClunk[j]->Play(0, 0, NULL))
						{
							//MessageBox(NULL, "sound buffer play failed", "Dicey.exe", MB_OK);
							printf("Play failed: %i\n", GetLastError());
							//return E_FAIL;
							//break;
						}
						//printf("playing clunk at %i\n", g_dwTime);
						break;
						
					}
				}
				break;
			case PLAY_SLIDE_SOUND:
				//DWORD dwStatus;
				for(j=0;j<SLIDE_BUFFERS;j++)
				{
					g_pSBSlide[j]->GetStatus(&dwStatus);
					if(!dwStatus &DSBSTATUS_PLAYING)
					{
						if(DS_OK != g_pSBSlide[j]->Play(0, 0, NULL))
						{
							//MessageBox(NULL, "sound buffer play failed", "Dicey.exe", MB_OK);
							printf("Play failed: %i\n", GetLastError());
							//return E_FAIL;
							break;
						}
						break;
					}
				}
				break;
			case PLAY_ZAP_SOUND:
				//DWORD dwStatus;
				for(j=0;j<ZAP_BUFFERS;j++)
				{
					g_pSBZap[j]->GetStatus(&dwStatus);
					if(!dwStatus &DSBSTATUS_PLAYING)
					{
						if(DS_OK != g_pSBZap[j]->Play(0, 0, NULL))
						{
							//MessageBox(NULL, "sound buffer play failed", "Dicey.exe", MB_OK);
							printf("Play failed: %i\n", GetLastError());
							//return E_FAIL;
							break;
						}
						break;
					}
				}
				break;
			case PLAY_GAME_OVER_SOUND:
				if(DS_OK != g_pSBGameOver->Play(0, 0, NULL))
				{
					//MessageBox(NULL, "sound buffer play failed", "Dicey.exe", MB_OK);
					printf("Play failed: %i\n", GetLastError());
					//return E_FAIL;
					break;
				}
				break;
			case PLAY_SINK_SOUND:
				//DWORD dwStatus;
				for(j=0;j<SINK_BUFFERS;j++)
				{
					g_pSBSink[j]->GetStatus(&dwStatus);
					if(!dwStatus &DSBSTATUS_PLAYING)
					{
						if(DS_OK != g_pSBSink[j]->Play(0, 0, NULL))
						{
							//MessageBox(NULL, "sound buffer play failed", "Dicey.exe", MB_OK);
							printf("Play failed: %i\n", GetLastError());
							//return E_FAIL;
							break;
						}
						break;
					}
				}
				break;
			case PLAY_LEVELUP_SOUND:
				if(DS_OK != g_pSBLevelUp->Play(0, 0, NULL))
				{
					//MessageBox(NULL, "sound buffer play failed", "Dicey.exe", MB_OK);
					printf("Play failed: %i\n", GetLastError());
					//return E_FAIL;
					break;
				}
				break;
			case PLAY_OUCH_SOUND:
				//DWORD dwStatus;
				for(j=0;j<OUCH_BUFFERS;j++)
				{
					g_pSBOuch[j]->GetStatus(&dwStatus);
					if(!dwStatus &DSBSTATUS_PLAYING)
					{
						if(DS_OK != g_pSBOuch[j]->Play(0, 0, NULL))
						{
							//MessageBox(NULL, "sound buffer play failed", "Dicey.exe", MB_OK);
							printf("Play failed: %i\n", GetLastError());
							//return E_FAIL;
							break;
						}
						break;
					}
				}
				break;

			}
		}
// End the scene
        g_pd3dDevice->SetTransform(D3DTS_WORLD, &matIdent);
		if(FAILED(g_pFont->Begin()))
			printf("g_pFont->Begin  failed: %i\n", GetLastError());
		for(i = 0; i < g_pGame->m_numPlayers; i++)
		{
			sprintf(buffer, "Player %i score: %i", i, g_pGame->m_players[i].score);
			SetRect(&FontRect, 10, i* 30+30, 0, 0);
			if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, 0xffffffff)))
				printf("g_pFont->DrawText failed: %i\n", GetLastError());
		}
		sprintf(buffer, "num sunk: %i", g_pGame->m_numSunk);
		SetRect(&FontRect, 10, i* 30+30, 0, 0);
		if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, 0xffffffff)))
			printf("g_pFont->DrawText failed: %i\n", GetLastError());
		sprintf(buffer, "Level: %i", g_pGame->m_level);
		SetRect(&FontRect, 10, i* 30+60, 0, 0);
		if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, 0xffffffff)))
			printf("g_pFont->DrawText failed: %i\n", GetLastError());
		//sprintf(buffer, "selection: %i", g_frontEndSelection);
		//SetRect(&FontRect, 10, i* 30+60, 0, 0);
		//if(FAILED(g_pFont->DrawText(buffer, -1,&FontRect , DT_LEFT, 0xffffffff)))
		//	printf("g_pFont->DrawText failed: %i\n", GetLastError());

		
		if(FAILED(g_pFont->End()))
			printf("g_pFont->End  failed: %i\n", GetLastError());

		g_pd3dDevice->EndScene();
        
		//printf("ping6!\n");
    }

	//printf("ping6b!\n");
    // Present the backbuffer contents to the display
    if(FAILED(g_pd3dDevice->Present( NULL, NULL, NULL, NULL )))
	{
		//printf("g_pd3dDevice->Present failed: %i\n", GetLastError());
		return;
	}
	//printf("ping7!\n");
}

// FIXME: This doesnt have anything to do with player input anymore. Change the name
void GetPlayerInput()
{
	//BYTE keyStates[256];
	//ZeroMemory( m_bKey, 256 );
	//GetKeyboardState(keyStates);

	//for(int i = 0; i < 1;i++)//g_numPlayers; i++)
	//{
		//FIXME: I'm checking the same keys for every player, cuz I'm lazy right now
		// I also need to allow for gamepads and stuff in the future

	/*if(g_bKey[VK_UP])
		g_pGame->m_players[0].dir = UP;
	else if(g_bKey[VK_DOWN])
		g_pGame->m_players[0].dir = DOWN;
	else if(g_bKey[VK_LEFT])
		g_pGame->m_players[0].dir = LEFT;
	else if(g_bKey[VK_RIGHT])
		g_pGame->m_players[0].dir = RIGHT;
	else
		g_pGame->m_players[0].dir = NONE;
	//}
	//g_pGame->m_players[1].dir = NONE;

	if(g_numPlayers > 1)
	{
		if(g_bKey['W'])
			g_pGame->m_players[1].dir = UP;
		else if(g_bKey['S'])
			g_pGame->m_players[1].dir = DOWN;
		else if(g_bKey['A'])
			g_pGame->m_players[1].dir = LEFT;
		else if(g_bKey['D'])
			g_pGame->m_players[1].dir = RIGHT;
		else
			g_pGame->m_players[1].dir = NONE;
	}*/

	// Putting camera movement in here.
	if(g_bKey['I'])
	{
		printf("Camera moving to %f,%f,%f\n", g_vCameraPos.x, g_vCameraPos.y, g_vCameraPos.z);
		g_vCameraPos.y += 0.1f;
	}
	if(g_bKey['K'])
	{
		printf("Camera moving to %f,%f,%f\n", g_vCameraPos.x, g_vCameraPos.y, g_vCameraPos.z);
		g_vCameraPos.y -= 0.1f;
	}
	if(g_bKey['J'])
	{
		printf("Camera moving to %f,%f,%f\n", g_vCameraPos.x, g_vCameraPos.y, g_vCameraPos.z);
		g_vCameraPos.x -= 0.1f;
	}
	if(g_bKey['L'])
	{
		printf("Camera moving to %f,%f,%f\n", g_vCameraPos.x, g_vCameraPos.y, g_vCameraPos.z);
		g_vCameraPos.x += 0.1f;
	}
	if(g_bKey['Y'])
	{
		printf("Camera moving to %f,%f,%f\n", g_vCameraPos.x, g_vCameraPos.y, g_vCameraPos.z);
		g_vCameraPos.z += 0.1f;
	}
	if(g_bKey['H'])
	{
		printf("Camera moving to %f,%f,%f\n", g_vCameraPos.x, g_vCameraPos.y, g_vCameraPos.z);
		g_vCameraPos.z -= 0.1f;
	}

	// FOV
	if(g_bKey['M'])
	{
		printf("Camera FOV changing  to %f\n", g_fFOV);
		g_fFOV += 0.01f;
	}
	if(g_bKey['N'])
	{
		printf("Camera moving to %f,%f,%f\n", g_fFOV);
		g_fFOV -= 0.01f;
	}

	
	
	// Ortho soze
	if(g_bKey['V'])
	{
		//printf("Camera moving to %f,%f,%f\n", g_vCameraPos.x, g_vCameraPos.y, g_vCameraPos.z);
		g_orthoSize += 0.01f;
	}
	if(g_bKey['B'])
	{
		//printf("Camera moving to %f,%f,%f\n", g_vCameraPos.x, g_vCameraPos.y, g_vCameraPos.z);
		g_orthoSize -= 0.01f;
	}

	if(g_bKey['Z'])
	{
		g_pBrain->m_dumpX = g_pGame->m_players[0].boardX;
		g_pBrain->m_dumpY = g_pGame->m_players[0].boardY;
		g_pBrain->m_wantPathInfo = true;
	}
	else
		g_pBrain->m_wantPathInfo = false;

	
	if(g_bKey['Q'])
	{
		g_AIplayers[0]->m_wantDump = true;
		if(!g_pGame->m_players[0].AI)
			g_AIplayers[0]->FindClosestRollerPath(g_pGame->m_players[0].boardX,g_pGame->m_players[0].boardY);
	
	}
	else
		g_AIplayers[0]->m_wantDump = false;
	


}

//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: The window's message handler
//-----------------------------------------------------------------------------
LRESULT WINAPI MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	int i;
	RECT rcWindowClient;

    switch( msg )
    {
		// HAndle key input
		case WM_KEYUP:
			g_bKey[wParam] = false;
			
			break;
		case WM_KEYDOWN:
			g_bKey[wParam] = true;
			if(g_gameState == FRONT_END)
				FrontEndInput(wParam);
			if(wParam == 'P')
				g_fPerspective = !g_fPerspective;
			else if (wParam == VK_PAUSE && g_pGame != NULL) // only toggle pause if game is running
				g_fPaused = !g_fPaused;
			else if(wParam == 'X' && g_pBrain!=NULL)
			{
				printf("User wants path dump\n");
				g_pBrain->m_wantDump = true;
				g_pBrain->m_dumpX = g_pGame->m_players[0].boardX;
				g_pBrain->m_dumpY = g_pGame->m_players[0].boardY;
			}
			else if(wParam == 'C' && g_pBrain!=NULL)
			{
				printf("User wants paths cleared\n");
				g_pBrain->m_gamepaths[g_pGame->m_players[0].boardX][g_pGame->m_players[0].boardY]->clear();
				printf("New size: %i\n",g_pBrain->m_gamepaths[g_pGame->m_players[0].boardX][g_pGame->m_players[0].boardY]->size());
			}
			else if(g_pGame != NULL) // temp, for toggling AI. FIXME
			{
				for(i = 49; i < 55; i++)
				{
					if(wParam == i && i-49 < g_pGame->m_numPlayers)
						g_pGame->m_players[i-49].AI = !g_pGame->m_players[i-49].AI;
				}
			}
			
			break;

        case WM_DESTROY:
            Cleanup();
            PostQuitMessage( 0 );
            return 0;
		case WM_SIZE:
			GetClientRect( hWnd, &rcWindowClient );
			g_fAspect = (rcWindowClient.right-rcWindowClient.left)/(FLOAT)(rcWindowClient.bottom-rcWindowClient.top);
			FontRect.top = 0;
			FontRect.left = 0;
			FontRect.bottom = rcWindowClient.bottom-rcWindowClient.top;
			FontRect.right = rcWindowClient.right-rcWindowClient.left;
			
			return 0;
    }

    return DefWindowProc( hWnd, msg, wParam, lParam );
}


//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: The application's entry point
//-----------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
	//Direction playerDirs[5];
	int maxEventSize = 0;
	int i;

	AllocConsole();

	// vars to get stdout/stdin running
	int hCrt;
	FILE *hf;
	//get stdout running
	hCrt = _open_osfhandle( (long) GetStdHandle(STD_OUTPUT_HANDLE), _O_TEXT);
	hf = _fdopen(hCrt, "w");
	*stdout = *hf;
	setvbuf(stdout, NULL, _IONBF, 0);
	//get stdin running
	hCrt = _open_osfhandle( (long) GetStdHandle(STD_INPUT_HANDLE), _O_TEXT);
	hf = _fdopen(hCrt, "r");
	*stdin = *hf;
	setvbuf(stdin, NULL, _IONBF, 0); 
	
	// Set the number of players, just as a starting value for the frontend
	g_numPlayers = 2;

	// Array of player input directions
	//Direction *pPlayerInput;
	//pPlayerInput = (Direction *)malloc(g_numPlayers * sizeof(Direction));

	DWORD dwNewTime = 0;
	DWORD dwStartTime = g_dwTime = timeGetTime();
	int frames = 0;
	

	ZeroMemory(g_bKey, 256);
	
	

    // Register the window class
    WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, MsgProc, 0L, 0L,
                      hInst, NULL, LoadCursor( NULL, IDC_ARROW ), NULL, NULL,
                      "Dicey", NULL };
    if(RegisterClassEx( &wc ) == 0)
	{
		char buffer[256];
		sprintf(buffer, "RegisterClassEx() Failed: %i", GetLastError());
		MessageBox(NULL, buffer, "Dicey.exe", MB_OK);
	}

    // Create the application's window
    HWND hWnd = CreateWindow( "Dicey", "Dicey2",
                              WS_OVERLAPPEDWINDOW, 0, 0, 800, 600,
                              GetDesktopWindow(), NULL, wc.hInstance, NULL );

	if(hWnd == NULL)
	{
		char buffer[256];
		sprintf(buffer, "CreateWindow() Failed: %i", GetLastError());
		MessageBox(NULL, buffer, "Dicey.exe", MB_OK);
	}
	//while(true)
	//{
		// We'll need to be able to destroy our CDiceGame and make new ones, 
		// so I'll need to do some adjusting later
		//CDiceGame Game(0,7,g_numPlayers);
		//g_pGame = &Game;
	//g_pGame = new CDiceGame;
	//g_pGame->Init(0,7,g_numPlayers);
    // Initialize Direct3D
    if(SUCCEEDED(InitD3D(hWnd)) && SUCCEEDED(InitDS(hWnd)) && SUCCEEDED(InitDI(hInst, hWnd)) )
    {
        // Create the scene geometry
        if( SUCCEEDED( InitGeometry() ) )
        {
            // Show the window
            ShowWindow( hWnd, SW_SHOWDEFAULT );
            UpdateWindow( hWnd );

            // Enter the message loop
            MSG msg;
            ZeroMemory( &msg, sizeof(msg) );
            while( msg.message!=WM_QUIT )
            {
                if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) )
                {
                    TranslateMessage( &msg );
                    DispatchMessage( &msg );
                }
                else
				{ 
					if(g_gameState == FRONT_END)
					{
					// Do snazzy front end stuff. 


						//Render the front end
						FrontEndRender();

						// Load a script
						frames++;
						


						// Keep timer going, so I dont screw up timing while sitting at the menu
						g_dwTime = timeGetTime();
						//g_pGame = new CDiceGame;
						//g_pGame->Init(0,7,g_numPlayers);
						
						//g_gameState = PLAYING;
						//printf("%i\n", sizeof(DWORD));
					}
					else if(g_gameState == PLAYING)
					{
						if(g_pGame->gameover)
						{
							Sleep(2000);
							if(g_pGame->m_recordingScript)
								WriteScript("TestScript");
							for(i = 0; i < g_pGame->m_numPlayers; i++)
								delete g_AIplayers[i];
							free(g_AIplayers);

							delete g_pBrain;
							delete g_pGame;

							g_pGame = NULL;
							g_gameState = FRONT_END;

							
							continue;
							//break;
						}
						dwNewTime = timeGetTime();

						//DIGetInput(playerDirs);

						// This doesnt affect player input anymore,
						// So I can use it all I want. Nyah!
						//if(!g_pGame->m_runningScript)
						GetPlayerInput();

						if(!g_fPaused) // If the game isnt paused, run the game loop
							g_pGame->GameLoop(dwNewTime-g_dwTime);//, pPlayerInput);

						Render();
						g_dwTime = dwNewTime;
						frames++;
						if((int)g_pGame->m_vEvents.size() > maxEventSize)
							maxEventSize = (int)g_pGame->m_vEvents.size();
						//printf("frame: %i\n", frames);
					}
					
				}
            }
        }
		else
			MessageBox(NULL, "InitGeometry() failed ", "Dicey.exe", MB_OK);
    }
	else
		MessageBox(NULL, "InitD3D() failed ", "Dicey.exe", MB_OK);


	if(g_pGame != NULL && g_pGame->m_recordingScript)
		WriteScript("TestScript");

	// Make sure to attempt cleaning up game objects
	// If the game did end on its own, objects are still open
	if(g_AIplayers != NULL && g_pGame != NULL)
	{
		for(i = 0; i < g_pGame->m_numPlayers; i++)
			delete g_AIplayers[i];
		free(g_AIplayers);
	}
	if(g_pBrain != NULL)
		delete g_pBrain;
	if(g_pGame != NULL)
		delete g_pGame;
	

	

    UnregisterClass( "Dicey", wc.hInstance );
	//free(pPlayerInput);

	printf("Total frames: %i\nElapsed Time: %fs\nFrames per second: %f\n", frames, (g_dwTime-dwStartTime)/1000.0f, frames/((g_dwTime-dwStartTime)/1000.0f));
	printf("Max Event vector size: %i\n", maxEventSize);
	getchar();
	//getchar();
	//Cleanup();
    return 0;
}

