#pragma once

enum GameState{FRONT_END, PLAYING};

