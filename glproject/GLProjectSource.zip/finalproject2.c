// CS459 Final Project
// Fractal landscapes with collision detection/response
//
// Written by Joe Bott - jbot7926

#include <GL/glut.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define PI 3.14159265358979323846

// Number of vertices per side
#define numVectors 33  // 2^n + 1
                       // Low number for slow SGI comps
					   // Need to set iterationStop to n as well.

// Setting to show fractal generation steps
static int iterationStop = 5;

// Mode defines
#define DISPLAY 1
#define ADJUST 2

// Button defines
#define BUTTON_TITLE 1
#define BUTTON_MINMAX 2
#define BUTTON_MODE 3
#define BUTTON_GEN_NEW 4
#define BUTTON_ROUGH_UP 5
#define BUTTON_ROUGH_DOWN 6
#define BUTTON_AMP_UP 7
#define BUTTON_AMP_DOWN 8
#define BUTTON_WATER_UP 9
#define BUTTON_WATER_DOWN 10
#define BUTTON_BALLS_ONOFF 11
#define BUTTON_TIMESTEP_UP 12
#define BUTTON_TIMESTEP_DOWN 13
#define BUTTON_NULL 0

// Maximum number of balls
#define MAX_BALLS 50

// Wait time for button repeat
#define WAIT_TIME 0.5

// GUI states
#define GUI_MINIMIZED 0
#define GUI_MAXIMIZED 1

// Ball states
#define BALLS_ON 1
#define BALLS_OFF 0

// Button structure
struct button {
   int xPos;  // Position relative to window
   int yPos;
   int width;
   int height;
   char text[50]; // Button caption
};

// Ball structure
struct ball
{
   GLfloat pos[3];  // Position
   GLfloat color[4];
   GLfloat velocity[3];
   GLfloat radius;
   GLfloat timeLeft; // Time left this frame to move
   int deadTimer;  // Counter used to determine if ball is 'dead'
};

// Button Array
struct button buttons[14]; 

// Ball array
struct ball balls[MAX_BALLS];

// Ball state, initially off
static int ballsState = BALLS_OFF;

// Timer for button clicks
static clock_t clickTime = 0;

// Time steps for animation
static GLfloat timeStep = 1;

// Font display list base
static int fontBase;

// Landscape display list ID
static int landscape;

// GUI state, initially maximixed
static int guiState = GUI_MAXIMIZED;

// Selected Button
static int buttonSelected = BUTTON_NULL;

// GUI window position, initally 10,10 (in window coordinates)
static int guiX = 10;
static int guiY = 10;

// GUI window size
static int guiWidth = 150;
static int guiHeight = 280;


// Flag - mouse click on GUI -> 1
//        mouse click off GUI -> 0
static int guiClick = 0;

// Mode, initially display
static int mode = DISPLAY;

// Random number seed
static int seed;

// Number ID of the vertex selected in Adjust mode
// ID = j*5 + i, which corresponds to heightMap[i][j]
static int selectedVector = -1;

// Buffer for feedback rendering
static GLfloat feedbackBuffer[100];

// Gravity value
static GLfloat gravity = 0.02;

// Height map, stores y-values for landscape
static GLfloat heightMap[numVectors][numVectors];

// Normal vector storage. For each square, poly 1's
// normal is normal[2*i][j], and poly 2's normal is
// normal[2*i +1][j]. Why did I do it like that? I dont know...
static GLfloat normals[(numVectors -1)*2][numVectors -1][3];

// Control Points, used to seed the landscape generation
static GLfloat controlPoints[5][5];

// Roughness value for landscape generation.
// Used to determine noise aplitude decay
static float roughness = .5;

// Amplitude of the noise applied to each point
static GLfloat randAmplitude = 10;

// Y value of water line
static GLfloat waterLine = 5;

// Scene rotation amounts
static int sceneXRotation = 0;
static int sceneYRotation = 0;

// Mouse button states
// 0 = button is up
// 1 = button is down
static int leftButtonDown = 0;
static int rightButtonDown = 0;

// Mouse location
static int mouseX = 0;
static int mouseY = 0;

// Window Size
static int windowXSize = 600;
static int windowYSize = 600;

// Field of view
static GLfloat fieldOfView = 45;

/* position of light source */
static GLfloat light0_position[] = {10, 10.0, 10, 0.0};

/* position of viewer */
static GLdouble viewer[] = {-9, 26.6, 24.6}; 

/* vectors to specify material properties */ 
static GLfloat mat_specular[]         = {1.0, 1.0, 1.0, 1.0};
static GLfloat mat_shininess[]        = {50.0};
static GLfloat mat_emission[]         = {1.0, 1.0, 1.0, 1.0};
static GLfloat mat_no_emission[]      = {0.0, 0.0, 0.0, 1.0};
static GLfloat mat_amb_diff_red[]     = {1.0, 0.0, 0.0, 1.0};
static GLfloat mat_amb_diff_green[]     = {0.0, 1.0, 0.0, 1.0};
static GLfloat mat_amb_diff_blue[]     = {0.0, 0.0, 1.0, 1.0};

// Performs the operation result += scalar * vector
void addScalarMult3(GLfloat vector[3], GLfloat scalar, GLfloat result[3])
{
   result[0] += scalar * vector[0];
   result[1] += scalar * vector[1];
   result[2] += scalar * vector[2];
}

// Copies a vector with 3 data items to another
void copyVect3(GLfloat from[3], GLfloat to[3])
{
   to[0] = from[0];
   to[1] = from[1];
   to[2] = from[2];
}

// Determine which polygon in a square the point is on.
// Returns 1 or 2, where...
// _____
// |\ 2|
// | \ | 
// |1_\| 
int pointInPoly(GLfloat point[3], int heightMapX, int heightMapY)
{
   // Convert heightmap coordinates into world coordinates 
   GLfloat worldX= ((20.0*(float)heightMapX)/(float)(numVectors -1))-10;
   GLfloat worldZ= ((20.0*(float)heightMapY)/(float)(numVectors -1))-10;
   // Compute square width
   GLfloat boxSize = (numVectors-1)/20;

   if ((-1 * (point[0]+worldX) + worldZ) <= point[2])
      return 1;
   else
      return 2;
}

// Normalizes the given vector
void normalize(GLfloat v[3])
{
   GLfloat d = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
   if (d == 0.0)
   {
      printf("zero length vector\n");
      exit(-1);
   }

   v[0] /= d;
   v[1] /= d;
   v[2] /= d;
}

// Returns the dot product of 2 vectors
GLfloat dotProduct(GLfloat x[3], GLfloat y[3])
{
   return (x[0] * y[0] + x[1] * y[1] + x[2] * y[2]);
}

// Adds 2 vectors
// Usage x + y = result
void addVect3(GLfloat x[3], GLfloat y[3], GLfloat result[3])
{
   result[0] = x[0] + y[0];
   result[1] = x[1] + y[1];
   result[2] = x[2] + y[2];
}

// Multiplies a vector by a scalar
// Usage x(vector) * y = result
void scalarMult3(GLfloat x[3], GLfloat y, GLfloat result[3])
{
   result[0] = x[0] *y;
   result[1] = x[1] *y;
   result[2] = x[2] *y;
}

// Compute the reflection vector, given the velocity vector and the plane normal
// Stores reseult in reflection vector
// Uses the following formula: R= 2*(-I dot N)*N + I, where
// I = The direction vector, and N = The Normal Vector
void reflect(GLfloat rayDirection[3], GLfloat planeNormal[3], GLfloat reflection[3])
{
   GLfloat tempVect[3], temp;
   scalarMult3(rayDirection, -1.0, tempVect);
   temp = dotProduct(tempVect, planeNormal);
   temp *= 2;
   scalarMult3(planeNormal, temp, tempVect);
   addVect3(tempVect, rayDirection, reflection);
}

// Determine collision time of ball
// 
// Found using basic equations for ray and plane
// ray -> PointOnRay= RayStartPoint + time*RayDirection
// plane -> PlaneNormal dot PointOnPlane = d (constant for all points on plane)
//
// Solved for time - > t = ((PlaneNormal dot PointOnPlane) - (PlaneNormal dot RayStart))
//                         / (PlaneNormal dot RayDirection)
GLfloat getCollisionTime(GLfloat oldPlanePoint[3],
                         GLfloat planeNormal[3],
                         GLfloat rayStart[3],
                         GLfloat rayDirection[3],
                         GLfloat ballRadius)
{
   GLfloat newPlanePoint[3];
   GLfloat d;
   GLfloat temp = dotProduct(planeNormal, rayDirection);

   scalarMult3(planeNormal, ballRadius, newPlanePoint);
   addVect3(oldPlanePoint, newPlanePoint, newPlanePoint);
   d = dotProduct(newPlanePoint, planeNormal);
   if (temp != 0.0) // If 0, ray is paralel to plane
   {
      d -= dotProduct(planeNormal, rayStart);
      return (d / temp);
   }
   return -500;
}

// Print the contents of a vector, for debugging
void printVector(GLfloat vector[3])
{
   printf("%1.3f %1.3f %1.3f\n", vector[0], vector[1], vector[2]);
}

// Determine crossproduct of 2 vectors, given 3 points
// Returns (V1-V2) x (V3 - V2) in VN
void crossProduct4v(GLfloat V1[3], GLfloat V2[3], GLfloat V3[3], GLfloat VN[3])
{
   GLfloat vect1[3] = {V1[0]-V2[0], V1[1]-V2[1], V1[2]-V2[2]};
   GLfloat vect2[3] = {V3[0]-V2[0], V3[1]-V2[1], V3[2]-V2[2]};

   VN[0] = vect1[1]*vect2[2] - vect1[2]*vect2[1];
   VN[1] = vect1[2]*vect2[0] - vect1[0]*vect2[2];
   VN[2] = vect1[0]*vect2[1] - vect1[1]*vect2[0];

   normalize(VN);
}

// all garbage, ignore this crud.
void writemessage()
{
   printf("\n");
   
}

// Handy little function to set the contents of a 3 element vector
void setVector3(GLfloat vector[3], GLfloat x, GLfloat y, GLfloat z)
{
   vector[0] = x;
   vector[1] = y;
   vector[2] = z;
}


// Generate map
// Arguments no longer needed, from first attempt at recursive algorithm
void generateMap(int x1, int x2, int y1, int y2)
{
   
   int boxSize = x2 - x1,        // Size of "box", current size of squares
       halfBoxSize = boxSize/2,
       i, j,                     // Loop counters
       stopper = iterationStop;  // For stopping iterations early, to show algorithm detail
   
   GLfloat rough = roughness;    // 2 variables used to decay noise amplitude
   GLfloat rough2 = rough;

   GLfloat V1[3], V2[3], V3[3], V4[3]; // Vectors used for temp space
   
   // Set control points
   for ( i = 0; i <= 4; i++)
   {
      for ( j = 0; j <= 4; j++)
      {
         heightMap[(numVectors-1)*i/4][(numVectors-1)*j/4] = controlPoints[i][j];
      }
   }

   
   while(boxSize >1 && stopper > 0 )
   {
      // 'Square' step, create midpoint height for every square
      for ( i = x1; i <= x2-boxSize; i += boxSize)
      {
         for ( j = y1; j <= y2-boxSize; j += boxSize)
         {
            if (heightMap[i+halfBoxSize][j+halfBoxSize] == 0)
            {
               heightMap[i+halfBoxSize][j+halfBoxSize] = ((heightMap[i][j] + heightMap[i+boxSize][j] + heightMap[i+boxSize][j+boxSize] + heightMap[i][j+boxSize]) / 4.0);
               if (roughness != 0.0)
                  heightMap[i+halfBoxSize][j+halfBoxSize] += (((randAmplitude/1000)*(rand()%1001))-(.5*randAmplitude))* (rough/rough2);   
            }
         }
      }

      // 'Diamond' step, create midpoint for each newly created diamond
      for ( i = x1; i <= x2-boxSize; i += boxSize)
      {
         for ( j = y1; j <= y2-boxSize; j += boxSize)
         {
            // Left side
            if (heightMap[i][j+halfBoxSize] == 0)
            {
               if ((i - halfBoxSize) < 0) // Make sure to only count left diamond point if it exists
                  heightMap[i][j+halfBoxSize] = (heightMap[i+halfBoxSize][j+halfBoxSize] + heightMap[i][j] + heightMap[i][j+boxSize]) / 3.0;
               else
                  heightMap[i][j+halfBoxSize] = (heightMap[i-halfBoxSize][j+halfBoxSize] + heightMap[i+halfBoxSize][j+halfBoxSize] + heightMap[i][j] + heightMap[i][j+boxSize]) / 4.0;
               if (roughness != 0.0)
                  heightMap[i][j+halfBoxSize] += (((randAmplitude/1000)*(rand()%1001))-(.5*randAmplitude))* (rough/rough2); 
            }

            // Right Side
            // Each side follows same basic format as left side
            if (heightMap[i+boxSize][j+halfBoxSize] == 0)
            {
               if ((i + boxSize + halfBoxSize) >= numVectors)
                  heightMap[i+boxSize][j+halfBoxSize] = (heightMap[i+halfBoxSize][j+halfBoxSize] + heightMap[i+boxSize][j] + heightMap[i+boxSize][j+boxSize]) / 3.0;
               else
                  heightMap[i+boxSize][j+halfBoxSize] = (heightMap[i+ boxSize + halfBoxSize][j+halfBoxSize] + heightMap[i+halfBoxSize][j+halfBoxSize] + heightMap[i+boxSize][j] + heightMap[i+boxSize][j+boxSize]) / 4.0;
               if (roughness != 0.0)
                  heightMap[i+boxSize][j+halfBoxSize] += (((randAmplitude/1000)*(rand()%1001))-(.5*randAmplitude))* (rough/rough2);  
            }

            // Top Side
            if (heightMap[i+halfBoxSize][j] == 0)
            {
               if ((j - halfBoxSize) < 0)
                  heightMap[i+halfBoxSize][j] = (heightMap[i+halfBoxSize][j+halfBoxSize] + heightMap[i][j] + heightMap[i+boxSize][j]) / 3.0;
               else
                  heightMap[i+halfBoxSize][j] = (heightMap[i+ halfBoxSize][j-halfBoxSize] + heightMap[i+halfBoxSize][j+halfBoxSize] + heightMap[i][j] + heightMap[i+boxSize][j]) / 4.0;
               if (roughness != 0.0)
                  heightMap[i+halfBoxSize][j] += (((randAmplitude/1000)*(rand()%1001))-(.5*randAmplitude))* (rough/2);
            }

            // Bottom Side
            if (heightMap[i+halfBoxSize][j+boxSize] == 0)
            {
               if ((j + boxSize + halfBoxSize) >= numVectors)
                  heightMap[i+halfBoxSize][j+boxSize] = (heightMap[i+halfBoxSize][j+halfBoxSize] + heightMap[i][j+boxSize] + heightMap[i+boxSize][j+boxSize]) / 3.0;
               else
                  heightMap[i+halfBoxSize][j+boxSize] = (heightMap[i+ halfBoxSize][j+ boxSize + halfBoxSize] + heightMap[i+halfBoxSize][j+halfBoxSize] + heightMap[i][j+boxSize] + heightMap[i+boxSize][j+boxSize]) / 4.0;
               if (roughness != 0.0)
                  heightMap[i+halfBoxSize][j+boxSize] += (((randAmplitude/1000)*(rand()%1001))-(.5*randAmplitude))* (rough/rough2);
            }
         }
      }

      boxSize /= 2;     // Decrease box size
      halfBoxSize /= 2;
      rough *= rough2; //Decrease randomness as box size gets smaller
      stopper--;       // Decrease iteration stopping value
   }

   // Generate normals
   for (i = 0; i <=(numVectors -2); i++)
   {
      
      for (j = 0; j <= (numVectors -2); j++)
      {  
         setVector3(V1, ((20.0 * i)/(numVectors-1)) - 10, heightMap[i][j], ((20.0 * j)/(numVectors-1)) - 10);
         setVector3(V2, ((20.0 * i)/(numVectors-1)) - 10, heightMap[i][j+1], ((20.0 * (j+1))/(numVectors-1)) - 10);
         setVector3(V3, ((20.0 * (i+1))/(numVectors-1)) - 10, heightMap[i+1][j+1], ((20.0 * (j+1))/(numVectors-1)) - 10);
         setVector3(V4, ((20.0 * (i+1))/(numVectors-1)) - 10, heightMap[i+1][j], ((20.0 * j)/(numVectors-1)) - 10);

         crossProduct4v(V2, V1, V3, normals[i*2][j]);
         crossProduct4v(V1, V4, V3, normals[(i*2)+1][j]);
      }
   }

   // Generate landscape display list
   glNewList(landscape, GL_COMPILE);
   for (i = 0; i <=(numVectors -2); i++)
   {
      
      for (j = 0; j <= (numVectors -2); j++)
      {  
         glBegin(GL_TRIANGLES);

         // Set x and z values so landscape stretches from -10 to 10 in both directions 
         setVector3(V1, ((20.0 * i)/(numVectors-1)) - 10, heightMap[i][j], ((20.0 * j)/(numVectors-1)) - 10);
         setVector3(V2, ((20.0 * i)/(numVectors-1)) - 10, heightMap[i][j+1], ((20.0 * (j+1))/(numVectors-1)) - 10);
         setVector3(V3, ((20.0 * (i+1))/(numVectors-1)) - 10, heightMap[i+1][j+1], ((20.0 * (j+1))/(numVectors-1)) - 10);
         setVector3(V4, ((20.0 * (i+1))/(numVectors-1)) - 10, heightMap[i+1][j], ((20.0 * j)/(numVectors-1)) - 10);

         glNormal3fv(normals[i*2][j]);
         glVertex3fv(V1);
         glVertex3fv(V2);
         glVertex3fv(V3);

         glNormal3fv(normals[(i*2)+1][j]);
         glVertex3fv(V4);
         glVertex3fv(V1);
         glVertex3fv(V3);
         
         glEnd();
      }
      
   }
   glEndList();
   
   return;
}

// Handy little function to set the contents of a 4 element vector
void setVector4(GLfloat vector[], GLfloat x, GLfloat y, GLfloat z, GLfloat w)
{
  vector[0] = x;
  vector[1] = y;
  vector[2] = z;
  vector[3] = w;
}


// Draw the specified button, in window coordinates
void drawButton(int xPos, int yPos, int buttonID)
{
   GLfloat color1[4], color2[4], color3[4], color4[4];
   
   // If this button is selected (mouse button is clicked on it)
   // change colors accordingly, to look depressed
   if (buttonSelected != buttonID)
   {
      setVector4(color1, 1, 1, 1, 1);
      setVector4(color2, .8745, .8745, .8745, 1);
      setVector4(color3, 0, 0, 0, 1);
      setVector4(color4, .498, .498, .498, 1);
   }
   else
   {
      setVector4(color1, 0, 0, 0, 1);
      setVector4(color2, .498, .498, .498, 1);
      setVector4(color3, 1, 1, 1, 1);
      setVector4(color4, .8745, .8745, .8745, 1);
   }

   // Draw top outside line
   glMaterialfv(GL_FRONT, GL_EMISSION, color1);
   glBegin(GL_LINE_STRIP);
      glVertex2d(xPos + buttons[buttonID].xPos, yPos + buttons[buttonID].yPos  + buttons[buttonID].height -1);
      glVertex2d(xPos + buttons[buttonID].xPos, yPos + buttons[buttonID].yPos);
      glVertex2d(xPos + buttons[buttonID].xPos + buttons[buttonID].width, yPos + buttons[buttonID].yPos);
   glEnd();

   // Draw top inside line
   glMaterialfv(GL_FRONT, GL_EMISSION, color2);
   glBegin(GL_LINE_STRIP);
      glVertex2d(xPos + buttons[buttonID].xPos+1, yPos + buttons[buttonID].yPos  + buttons[buttonID].height -2);
      glVertex2d(xPos + buttons[buttonID].xPos+1, yPos + buttons[buttonID].yPos +1);
      glVertex2d(xPos + buttons[buttonID].xPos + buttons[buttonID].width -1, yPos + buttons[buttonID].yPos +1);
   glEnd();

   // Draw bottom inside line
   glMaterialfv(GL_FRONT, GL_EMISSION, color3);
   glBegin(GL_LINE_STRIP);
      glVertex2d(xPos + buttons[buttonID].xPos, yPos + buttons[buttonID].yPos  + buttons[buttonID].height);
      glVertex2d(xPos + buttons[buttonID].xPos + buttons[buttonID].width, yPos + buttons[buttonID].yPos+ buttons[buttonID].height);
      glVertex2d(xPos + buttons[buttonID].xPos + buttons[buttonID].width, yPos + buttons[buttonID].yPos -1);
   glEnd();

   // Draw bottom outside line
   glMaterialfv(GL_FRONT, GL_EMISSION, color4);
   glBegin(GL_LINE_STRIP);
      glVertex2d(xPos + buttons[buttonID].xPos +1 , yPos + buttons[buttonID].yPos  + buttons[buttonID].height -1);
      glVertex2d(xPos + buttons[buttonID].xPos + buttons[buttonID].width -1, yPos + buttons[buttonID].yPos+ buttons[buttonID].height -1);
      glVertex2d(xPos + buttons[buttonID].xPos + buttons[buttonID].width -1, yPos + buttons[buttonID].yPos );
   glEnd();

   // If we're drawing the minimizer button, fill in the middle so title bar doesnt turn it blue
   if (buttonID == BUTTON_MINMAX)
   {
      setVector4(color1, .749, .749, .749 , 1);
      glMaterialfv(GL_FRONT, GL_EMISSION, color1);
      glBegin(GL_QUADS);
         glVertex2d(xPos + buttons[buttonID].xPos +2, yPos + buttons[buttonID].yPos+1);
         glVertex2d(xPos + buttons[buttonID].xPos +2, yPos + buttons[buttonID].yPos + buttons[buttonID].height -2);
         glVertex2d(xPos + buttons[buttonID].xPos + buttons[buttonID].width -1, yPos + buttons[buttonID].yPos + buttons[buttonID].height -2);
         glVertex2d(xPos + buttons[buttonID].xPos + buttons[buttonID].width -1, yPos + buttons[buttonID].yPos+1);
      glEnd();
   }

   // Draw the button text
   if (buttons[buttonID].text[0] != '\0')
   {
      setVector4(color1, 0, 0, 0, 1);
      glMaterialfv(GL_FRONT, GL_EMISSION, color1);
      // Set raster position so text is drawn in the middle of the button
      glRasterPos2i(xPos+buttons[buttonID].xPos + (buttons[buttonID].width/2 -(strlen(buttons[buttonID].text)*9/2)), yPos + buttons[buttonID].yPos +15);
      glCallLists(strlen(buttons[buttonID].text) , GL_BYTE, buttons[buttonID].text);
   }
}

// Function that draws the GUI at the specified window coordinates
void drawGUI(int xPos, int yPos)
{
   GLfloat color[4];

   // Strings for displaying the coresponsding values
   char roughnessString[6] = "0.000";
   char amplitudeString[6] = "000.0";
   char timeStepString[5]  = "0.00";

   // Set viewport, just in case... ::shrug::
   glViewport(0, 0, (GLsizei) windowXSize, (GLsizei) windowYSize);

   // Set up orthographic projection so window coordinates
   // corespond exactly with drawing coordinates. No (windowY - Y) stuff here!
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(0.0,windowXSize, windowYSize, 0.0, -5.0, 5.0);
   glMatrixMode(GL_MODELVIEW);

   /* initialize (modelview) matrix */
   glLoadIdentity(); 

   // Kill Ambient and Diffuse colors from landscape, so they dont get in the way
   setVector4(color, 0, 0, 0, 1);
   glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, color);
      
   // Shut off light
   glDisable(GL_LIGHT0);

   // Make it so the last bit drawn appears over everything else
   glDepthFunc(GL_ALWAYS);
   
   // Draw window title bar
   setVector4(color, 0, 0, .498, 1);
   glMaterialfv(GL_FRONT, GL_EMISSION, color);
   glBegin(GL_QUADS);
      glVertex2d(xPos,yPos);
      glVertex2d(xPos, yPos+15);
      glVertex2d(xPos+guiWidth,yPos+15);
      glVertex2d(xPos+guiWidth,yPos);
   glEnd();
   
   // Draw GUI window title
   setVector4(color, 1, 1, 1, 1);
   glMaterialfv(GL_FRONT, GL_EMISSION, color);
   glRasterPos2i(xPos + 16, yPos + 12);
   glCallLists(strlen("Configuration") , GL_BYTE, "Configuration");

   // Draw the rest only if the window is maximized
   if(guiState == GUI_MAXIMIZED)
   {
      // Draw main grey rectangle portion
      setVector4(color, .749, .749, .749 , 1);
      glMaterialfv(GL_FRONT, GL_EMISSION, color);
      glBegin(GL_QUADS);
         glVertex2d(xPos,yPos+15);
         glVertex2d(xPos, yPos+guiHeight);
         glVertex2d(xPos+guiWidth,yPos+guiHeight);
         glVertex2d(xPos+guiWidth,yPos+15);
      glEnd();

      // Draw text for Mode button
      setVector4(color, 0, 0, 0, 1);
      glMaterialfv(GL_FRONT, GL_EMISSION, color);
      glRasterPos2i(xPos + 12, yPos + 35);
      glCallLists(strlen("Mode:") , GL_BYTE, "Mode:");
      // Draw the Mode button
	   drawButton(xPos, yPos, BUTTON_MODE);
      
      // Draw the rest of the buttons only if we're in display mode
      if(mode == DISPLAY)
	   {
         // Draw the 'Generate New' button
         drawButton(xPos, yPos, BUTTON_GEN_NEW);

         // Stuff roughness value into our string
         roughnessString[0] = '0' + (int)roughness;
         roughnessString[2] = '0' + (int)(roughness *10)%10;
         roughnessString[3] = '0' + (int)(roughness *100)%10;
         roughnessString[4] = '0' + (int)((roughness +0.0005)*1000)%10;
         
         // Draw roughness value and identifier
         setVector4(color, 0, 0, 0, 1);
         glMaterialfv(GL_FRONT, GL_EMISSION, color);
         glRasterPos2i(xPos + 40, yPos + 95);
         glCallLists(strlen("Roughness:") , GL_BYTE, "Roughness:");
         glRasterPos2i(xPos + 60, yPos + 114);
         glCallLists(strlen(roughnessString) , GL_BYTE, roughnessString);

         // Draw roughness manipulation buttons
         drawButton(xPos, yPos, BUTTON_ROUGH_UP);
         drawButton(xPos, yPos, BUTTON_ROUGH_DOWN);
         
         // Cram amplitude vvalue into its string
         if (randAmplitude < 100.0)
            amplitudeString[0] = ' ';
         else
            amplitudeString[0] = '1';
         amplitudeString[1] = '0' + (int)(randAmplitude /10)%10;
         amplitudeString[2] = '0' + (int)randAmplitude %10;
         amplitudeString[4] = '0' + (int)(randAmplitude * 10)%10;

         // Draw amplitude value and indentifier
         setVector4(color, 0, 0, 0, 1);
         glMaterialfv(GL_FRONT, GL_EMISSION, color);
         glRasterPos2i(xPos + 40, yPos + 155);
         glCallLists(strlen("Amplitude:") , GL_BYTE, "Amplitude:");
         glRasterPos2i(xPos + 60, yPos + 174);
         glCallLists(strlen(amplitudeString) , GL_BYTE, amplitudeString);

         // Draw amplitude manipulation buttons
         drawButton(xPos, yPos, BUTTON_AMP_UP);
         drawButton(xPos, yPos, BUTTON_AMP_DOWN);

         // Draw Water line manipulation buttons
         drawButton(xPos, yPos, BUTTON_WATER_UP);
         drawButton(xPos, yPos, BUTTON_WATER_DOWN);

         // Draw water line button identifier
         setVector4(color, 0, 0, 0, 1);
         glMaterialfv(GL_FRONT, GL_EMISSION, color);
         glRasterPos2i(xPos + 40, yPos + 222);
         glCallLists(strlen("Water Level") , GL_BYTE, "Water Level");

         // Draw ball rain toggle button
         drawButton(xPos, yPos, BUTTON_BALLS_ONOFF);

         // Draw nall rain toggle identifier
         setVector4(color, 0, 0, 0, 1);
         glMaterialfv(GL_FRONT, GL_EMISSION, color);
         glRasterPos2i(xPos + 55, yPos + 267);
         glCallLists(strlen("Ball Rain") , GL_BYTE, "Ball Rain");

         // Draw the timestep buttons only if the ball rain in on
         if(ballsState == BALLS_ON)
         {
            // Draw time step buttons
            drawButton(xPos, yPos, BUTTON_TIMESTEP_UP);
            drawButton(xPos, yPos, BUTTON_TIMESTEP_DOWN);
            
            // Draw time step identifier
            setVector4(color, 0, 0, 0, 1);
            glMaterialfv(GL_FRONT, GL_EMISSION, color);
            glRasterPos2i(xPos + 40, yPos + 305);
            glCallLists(strlen("TimeStep") , GL_BYTE, "TimeStep");
           
            // Jab timestep value into its string
            timeStepString[0] = '0' + (int)timeStep;
            timeStepString[2] = '0' + ((int)(timeStep *10))%10;
            timeStepString[3] = '0' + ((int)(timeStep *100))%10;

            // Display timestep value
            glRasterPos2i(xPos + 40, yPos + 325);
            glCallLists(strlen(timeStepString) , GL_BYTE, timeStepString);
         }

      }

   }

   // Draw the minimizer button
   drawButton(guiX, guiY, BUTTON_MINMAX);

   // Fix the depth checking function so the landscape is drawn right
   glDepthFunc(GL_LESS);

}

// Brute force button setup
void setupButtons()
{
   buttons[BUTTON_MINMAX].xPos = 1;
   buttons[BUTTON_MINMAX].yPos = 1;
   buttons[BUTTON_MINMAX].width = 13;
   buttons[BUTTON_MINMAX].height = 13; 
   strcpy(buttons[BUTTON_MINMAX].text, "-");
 
   buttons[BUTTON_TITLE].xPos = 15; 
   buttons[BUTTON_TITLE].yPos = 0;
   buttons[BUTTON_TITLE].width = guiWidth-15;
   buttons[BUTTON_TITLE].height = 15;

   buttons[BUTTON_MODE].xPos = 60;
   buttons[BUTTON_MODE].yPos = 20;
   buttons[BUTTON_MODE].width = 71;
   buttons[BUTTON_MODE].height = 22;
   if (mode = DISPLAY)
      strcpy(buttons[BUTTON_MODE].text,"Display");
   else
      strcpy(buttons[BUTTON_MODE].text,"Adjust");

   buttons[BUTTON_GEN_NEW].xPos = 17;
   buttons[BUTTON_GEN_NEW].yPos = 50;
   buttons[BUTTON_GEN_NEW].width = 116;
   buttons[BUTTON_GEN_NEW].height = 22;
   strcpy(buttons[BUTTON_GEN_NEW].text,"Generate New");

   buttons[BUTTON_ROUGH_UP].xPos = 21;
   buttons[BUTTON_ROUGH_UP].yPos = 79;
   buttons[BUTTON_ROUGH_UP].width = 12;
   buttons[BUTTON_ROUGH_UP].height = 22;
   strcpy(buttons[BUTTON_ROUGH_UP].text,"^");

   buttons[BUTTON_ROUGH_DOWN].xPos = 21;
   buttons[BUTTON_ROUGH_DOWN].yPos = 102;
   buttons[BUTTON_ROUGH_DOWN].width = 12;
   buttons[BUTTON_ROUGH_DOWN].height = 22;
   strcpy(buttons[BUTTON_ROUGH_DOWN].text,"v");

   buttons[BUTTON_AMP_UP].xPos = 21;
   buttons[BUTTON_AMP_UP].yPos = 139;
   buttons[BUTTON_AMP_UP].width = 12;
   buttons[BUTTON_AMP_UP].height = 22;
   strcpy(buttons[BUTTON_AMP_UP].text,"^");

   buttons[BUTTON_AMP_DOWN].xPos = 21;
   buttons[BUTTON_AMP_DOWN].yPos = 162;
   buttons[BUTTON_AMP_DOWN].width = 12;
   buttons[BUTTON_AMP_DOWN].height = 22;
   strcpy(buttons[BUTTON_AMP_DOWN].text,"v");

   buttons[BUTTON_WATER_UP].xPos = 21;
   buttons[BUTTON_WATER_UP].yPos = 199;
   buttons[BUTTON_WATER_UP].width = 12;
   buttons[BUTTON_WATER_UP].height = 22;
   strcpy(buttons[BUTTON_WATER_UP].text,"^");

   buttons[BUTTON_WATER_DOWN].xPos = 21;
   buttons[BUTTON_WATER_DOWN].yPos = 222;
   buttons[BUTTON_WATER_DOWN].width = 12;
   buttons[BUTTON_WATER_DOWN].height = 22;
   strcpy(buttons[BUTTON_WATER_DOWN].text,"v");

   buttons[BUTTON_BALLS_ONOFF].xPos = 15;
   buttons[BUTTON_BALLS_ONOFF].yPos = 252;
   buttons[BUTTON_BALLS_ONOFF].width = 32;
   buttons[BUTTON_BALLS_ONOFF].height = 22;
   if (ballsState == BALLS_ON)
      strcpy(buttons[BUTTON_BALLS_ONOFF].text,"On");
   else
      strcpy(buttons[BUTTON_BALLS_ONOFF].text,"Off");

   buttons[BUTTON_TIMESTEP_UP].xPos = 21;
   buttons[BUTTON_TIMESTEP_UP].yPos = 282;
   buttons[BUTTON_TIMESTEP_UP].width = 12;
   buttons[BUTTON_TIMESTEP_UP].height = 22;
   strcpy(buttons[BUTTON_TIMESTEP_UP].text,"^");

   buttons[BUTTON_TIMESTEP_DOWN].xPos = 21;
   buttons[BUTTON_TIMESTEP_DOWN].yPos = 305;
   buttons[BUTTON_TIMESTEP_DOWN].width = 12;
   buttons[BUTTON_TIMESTEP_DOWN].height = 22;
   strcpy(buttons[BUTTON_TIMESTEP_DOWN].text,"v");
}

void init(void) 
{
   
   static int i,j;
   writemessage(); 

   // Generate random number seed and store it
   seed = (unsigned)time( NULL ); 
   srand( seed );

   glClearColor(0.0, 0.0, 0.0, 0.0);
   glShadeModel(GL_SMOOTH);

   /* initially GL_FILL mode, later GL_LINE to show wireframe */
   glPolygonMode(GL_FRONT,GL_FILL);

   // Cull backfaces to speed things up. Does it help? Not really, but...
   glCullFace(GL_BACK);
   glEnable(GL_CULL_FACE);

   /* Disable two-sided lighting, I dont need it */
   glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_FALSE);

   glEnable(GL_DEPTH_TEST);
   glEnable(GL_LIGHTING);
   glEnable(GL_LIGHT0);

   // Set up buttons
   setupButtons();

   // Get landscape display list ID
   landscape = glGenLists(1);

   /* set up a font in display list */
   fontBase = glGenLists(128);
   for(i=0;i<128;i++) 
   {
      glNewList(fontBase+i, GL_COMPILE);
      glutBitmapCharacter(GLUT_BITMAP_9_BY_15, i);
      glEndList();
   }
   glListBase(fontBase);

   // initialize heightmap
   for (i = 0; i <= numVectors-1; i++)
   {
      for (j = 0; j <= numVectors-1; j++)
      {
         heightMap[i][j] = 0;
      }
   }
  
   // Seed landscape seeds.
   controlPoints[0][0] = 5.0;
   controlPoints[0][4] = 5.0;
   controlPoints[4][0] = 5.0;
   controlPoints[4][4] = 5.0;

   // Generate landscape
   generateMap(0, numVectors-1, 0, numVectors-1);

   
}


void reshape(int w, int h)
{
   windowXSize = w;
   windowYSize = h;
   glViewport(0, 0, (GLsizei) w, (GLsizei) h);

   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   gluPerspective(45.0, ((GLfloat) w) / (GLfloat) h, 2.0, 80.0);

   glMatrixMode(GL_MODELVIEW);

   // Move GUI window if it gets pushed off the screen by a resize
   if (guiY > (windowYSize - 15))
     guiY = windowYSize - 15;
   if (guiX > (windowXSize -guiWidth))
     guiX = windowXSize - guiWidth;

}

// Determine if mouse cursor is on a button
// Return button ID (also button[] index)
int findButton(int x, int y)
{
   int i;
   for (i = 0; i < 49; i++)
   {
      if ((x >= (guiX+buttons[i].xPos)) && (x <= (guiX + buttons[i].xPos + buttons[i].width)) && 
           (y >= (guiY+buttons[i].yPos)) && (y <= (guiY + buttons[i].yPos + buttons[i].height)))
      {
         // Messy way to determine which buttons should be ignored.

         // Always return title and minimizer button hits
         if ((i == BUTTON_MINMAX) || (i == BUTTON_TITLE))
	         return i;
         if(guiState == GUI_MAXIMIZED)
         {
            // If maximized, return hits for the Mode button at least
	         if (i == BUTTON_MODE)
	            return i;
            // If in display mode, return hits for all buttons except timestep
	         if (mode == DISPLAY)
	         {
	            if((i == BUTTON_GEN_NEW) ||
                  (i == BUTTON_ROUGH_UP) ||
                  (i == BUTTON_ROUGH_DOWN) ||
                  (i == BUTTON_AMP_UP) ||
                  (i == BUTTON_AMP_DOWN) ||
                  (i == BUTTON_WATER_UP) ||
                  (i == BUTTON_WATER_DOWN) ||
                  (i == BUTTON_BALLS_ONOFF))
	                  return i;
               // If ball rain is on, then return timestep button hits
               if (ballsState == BALLS_ON)
               {
                  if ((i == BUTTON_TIMESTEP_UP) ||
                     (i == BUTTON_TIMESTEP_DOWN))
                     return i;
               }
	         }
         }
      }
   }

   // No button has been hit, return null
   return BUTTON_NULL;
}

// Determine if a point was picked
// Return point as single int, where point is (int%5, int/5)
// or -1 if none selected/
int pickVector(int x, int y)
{
   int i;
   for( i = 0; i < 60; i+=2)
   {
      if (feedbackBuffer[i] != -1)
      {
         if ((x < (feedbackBuffer[i] + 10)) && (x > (feedbackBuffer[i] - 10)) && (y < (feedbackBuffer[i+1] + 10)) && (y > (feedbackBuffer[i+1] - 10)))
            return 24 - (i/2);
      }
   }

   return -1;
}

// Function to draw only if GUI, if thats all thats needed.
void drawOnlyGUI(int guiX, int guiY)
{
   // Draw only GUI if the balls are also off
   if (ballsState = BALLS_OFF)
   {
      drawGUI(guiX, guiY);
      glFlush();
      glutSwapBuffers();
   }
   else // Otherwise redraw everything
      glutPostRedisplay();
}

// Main display function
void display(void)
{
   static int i, j; // Variable for loop counters

   // Buffer for feedback rendering output
   static GLfloat buffer[40];

   // Clear display and depth buffer
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   
   // Set field of view
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   gluPerspective(fieldOfView, (GLfloat)windowXSize/ (GLfloat)windowYSize, 2.0, 80.0);
   glMatrixMode(GL_MODELVIEW);

   // If mode is adjust, only draw grid, and use feedback buffer
   if (mode == ADJUST)
   {
       
      // initialize (modelview) matrix
      glLoadIdentity(); 

      // Set viewer look at point
      gluLookAt(-6.6, 26.6, 29.8, 0.0, 0.0, 0.0, 
	           0.0, 1.0, 0.0);
      
      // Shut off light
      glDisable(GL_LIGHT0);

      // Rotate scene
      glRotatef( sceneXRotation, 1,0,0);
      glRotatef( sceneYRotation, 0,1,0);

      // Draw grid lines
      // Make each line endpoint either white for unused, green for used
      // and red for currently selected vectors
      glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
      for (i = 0; i < 5; i++)
      {
         glBegin(GL_LINE_STRIP);
         for (j = 0; j < 5; j++)
         {
            if (controlPoints[i][j] == 0)
               glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
            else if ((selectedVector != -1) && (selectedVector%5 == i) && (selectedVector/5 == j))
               glMaterialfv(GL_FRONT, GL_EMISSION, mat_amb_diff_red);
            else
               glMaterialfv(GL_FRONT, GL_EMISSION, mat_amb_diff_green);
             
            glVertex3f((5.0 * i) - 10, controlPoints[i][j], (5.0 * j) - 10);
         }
         glEnd();
      }
      for (j = 0; j < 5; j++)
      {
         glBegin(GL_LINE_STRIP);
         for (i = 0; i < 5; i++)
         {
            if (controlPoints[i][j] == 0)
               glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
            else if ((selectedVector != -1) && (selectedVector%5 == i) && (selectedVector/5 == j))
               glMaterialfv(GL_FRONT, GL_EMISSION, mat_amb_diff_red);
            else
               glMaterialfv(GL_FRONT, GL_EMISSION, mat_amb_diff_green);
            glVertex3f((5.0 * i) - 10, controlPoints[i][j], (5.0 * j) - 10);
         }
         glEnd();
      }

      // Draw spheres with same coloring scheme
      for (j = 0; j < 5; j++)
      {
         for (i = 0; i < 5; i++)
         {
            if (controlPoints[i][j] == 0)
               glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
            else if ((selectedVector != -1) && (selectedVector%5 == i) && (selectedVector/5 == j))
               glMaterialfv(GL_FRONT, GL_EMISSION, mat_amb_diff_red);
            else
               glMaterialfv(GL_FRONT, GL_EMISSION, mat_amb_diff_green);
            glPushMatrix();
               glTranslatef((5.0 * i) - 10, controlPoints[i][j], (5.0 * j) - 10);
               glutSolidSphere(0.25, 10, 8);
            glPopMatrix();
         }
      }

      // Reset buffer used to determine with points are drawn with -1
      for(i = 0; i < 100; i++)
         feedbackBuffer[i] = -1;

      // Draw points for feedback buffer
      for (j = 4; j >= 0; j -= 1)
      {
         for (i = 4; i >= 0; i -= 1)
         {
            // Reset position 0 of feedback buffer
            buffer[0] = 0;
            // Set up feedback buffer
            glFeedbackBuffer(40, GL_2D, buffer);
            // Change rendering mode to Feedback
      	   glRenderMode(GL_FEEDBACK);

            // Draw the point
            glBegin(GL_POINTS);
               glVertex3f((5.0 * i) - 10, controlPoints[i][j], (5.0 * j) - 10);
            glEnd();

            // Switch back to render
            // Done this way so its easier to determine if the point was clipped or not
	         glRenderMode(GL_RENDER);
            
            // If buffer[0] contains a value, then point was drawn
            // Will *not* be feedback value, but header info tellin me it was a 
            // point drawn. I dont care about the specific value, 
            // I *know* a point was drawn. :)
            if (buffer[0] != 0)
            {
               // If the point was drawn, copy screen coordinates generated into
               // the coresponding feedbackBuffer location
               feedbackBuffer[2*((4-j)*5+(4-i))] = buffer[1];
               // flip y value (and adjust a little)
               feedbackBuffer[2*((4-j)*5+(4-i))+1] = (windowYSize -5) - buffer[2];
            }
            else
            { 
               // Make sure coresponding feedbackBuffer locations are set to -1
               // Probably not needed, but there ya have it.
               feedbackBuffer[2*((4-j)*5+(4-i))] = -1;
               feedbackBuffer[2*((4-j)*5+(4-i))+1] = -1;
            }
         }      
      }
   }
   else if (mode == DISPLAY)
   {

      /* initialize (modelview) matrix */
      glLoadIdentity(); 

      /* Set viewer position */
      gluLookAt(-6.6, 26.6, 29.8, 0.0, 0.0, 0.0, 
	              0.0, 1.0, 0.0);

      // Turn my light back on
      glEnable(GL_LIGHT0);

      /* Set light source position */
      glLightfv(GL_LIGHT0, GL_POSITION, light0_position);

      // Rotate scene
      glRotatef( sceneXRotation, 1,0,0);
      glRotatef( sceneYRotation, 0,1,0);

      // Make sure landscpae doenst emit light
      glMaterialfv(GL_FRONT, GL_EMISSION, mat_no_emission);

      // Set up landscape material
      glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
      glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, mat_amb_diff_green);
 
      // Draw landscape
      glCallList(landscape);
   
      // Draw the water
      glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
      glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, mat_amb_diff_blue);
      glBegin(GL_QUADS);
         glNormal3f(0, 1, 0);
         glVertex3f(-10, waterLine, -10 );
         glVertex3f(-10, waterLine, 10);
         glVertex3f(10, waterLine,10);
         glVertex3f(10, waterLine, -10);
      glEnd();

      // If ball rain is on, draw them
      if (ballsState == BALLS_ON)
      {

         for (i = 0; i < MAX_BALLS; i++)
         {
            // Only worry about ball is its radius is greater than 0
            // Using radius as my "ball disabler"
            if(balls[i].radius > 0)
            {
               // Draw the ball
	            glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, balls[i].color); 
	            glPushMatrix();
	            glTranslatef(balls[i].pos[0],balls[i].pos[1],balls[i].pos[2]);
	            glutSolidSphere(balls[i].radius, 5, 5);
	            glPopMatrix();	
            }
            else
            {
               // If ball is shut off, generate a new one
	            setVector3(balls[i].pos, 0, 20, 0);
               setVector3(balls[i].velocity, (float)(rand()%11)/20.0-.25,(float)(rand()%11)/10.0-.5,(float)(rand()%11)/20.0-.25);
               balls[i].radius = 0.2;
               balls[i].deadTimer = 0;
               setVector4(balls[i].color, (float)(rand()%101)/100.0, (float)(rand()%101)/100.0, (float)(rand()%101)/100.0, 1);
            }
         }
      }
   }

   // Draw the GUI window
   drawGUI(guiX,guiY);

   glFlush();
   glutSwapBuffers();
   
}

// Function used to rotate the scene, adjust control points, and move the window
void motion(int x, int y)
{
   int testButton;
  
   if (guiClick == 0)
   {
      // Do main window stuff, only if mouse wasnt clicked on the GUI

      if (mode == ADJUST)
      {
         if (leftButtonDown == 1)
         {
            if (selectedVector != -1)
            {
               // In adjust mode, if left button is down and a vector is selected
               // adjust the coresponding control poin
               controlPoints[selectedVector%5][selectedVector/5] -= (.1 * (y - mouseY));

               mouseX = x;
               mouseY = y;

               glutPostRedisplay();
            }
            else
            {
               // If a vector isnt selected, rotate scene

               // Add mouse motion to scene rotation values
               sceneYRotation += x - mouseX;
               sceneXRotation += y - mouseY;

               // Store new mouse position
               mouseX = x;
               mouseY = y;

               glutPostRedisplay();
            }
         }
         else if ((rightButtonDown == 1) && (selectedVector == -1))
         {
            // In adjust mode, if the right button is down but no 
            // vector is selected, adjust field of view

            // Add mouse motion in the Y direction to the Field of View
            fieldOfView += y - mouseY;

            mouseX = x;
            mouseY = y;

            // Set new field of view
            glMatrixMode(GL_PROJECTION);
            glLoadIdentity();
            gluPerspective(fieldOfView, (GLfloat)windowXSize/ (GLfloat)windowYSize, 2.0, 80.0);
            glMatrixMode(GL_MODELVIEW);

            glutPostRedisplay();
         }
      }
      else if (mode == DISPLAY)
      {
         if (leftButtonDown == 1)
         {
            // In display mode, if left button is dowm rotate the scene

            // Add mouse motion to scene rotation values
            sceneYRotation += x - mouseX;
            sceneXRotation += y - mouseY;

            // Store new mouse position
            mouseX = x;
            mouseY = y;

            glutPostRedisplay(); 
         }
         if (rightButtonDown == 1)
         {
            // In display mode, if right button is down adjust the FOV

            // Add mouse motion in the Y direction to the Field of View
            fieldOfView += y - mouseY;

            // Store new mouse position
            mouseX = x;
            mouseY = y;

            // Set new field of view
            glMatrixMode(GL_PROJECTION);
            glLoadIdentity();
            gluPerspective(fieldOfView, (GLfloat)windowXSize/ (GLfloat)windowYSize, 2.0, 80.0);
            glMatrixMode(GL_MODELVIEW);

            glutPostRedisplay();
         }
      }
   }
   else
   {
      // If button has been clicked in the GUI window
      if (buttonSelected == BUTTON_TITLE)
      {
         // ...move the window if the title bar was slected
         guiX += x-mouseX;
         guiY += y-mouseY;
         mouseY = y;
         mouseX= x;
         if (guiY < 0)
	         guiY = 0;
         if (guiX < 0)
	         guiX = 0;
         if (guiY > (windowYSize - 15))
	         guiY = windowYSize - 15;
         if (guiX > (windowXSize -guiWidth))
	         guiX = windowXSize - guiWidth;
         glutPostRedisplay();
      }
      else
      {
         // Otherwise, if the pointer moves off a button with a 
         // mouse button down, change selectedButton to NULL
         testButton = findButton(x,y);
         if(testButton != buttonSelected)
         {
	         buttonSelected = BUTTON_NULL;
            glutPostRedisplay();

         }
      }
   }
}

// Main mouse function
// Handles much of the GUI functionality, as well as
// vertex picking in adjust mode
void mouse(int button, int state, int x, int y) 
{
   int i,j; //for loop counters

   switch (button) 
   {
      case GLUT_LEFT_BUTTON:
         if (state == GLUT_DOWN)
         {
            // If the left button is down, update the mouse state
            leftButtonDown = 1;
            mouseX = x;
            mouseY = y;
	         guiClick = 0;

            // Check if it was clicked within the GUI window
	         if ((x >= guiX) && ( x <= (guiX + guiWidth)) && (y>= guiY) && (y<=(guiY+guiHeight)))
	         {
               // See if a button was selected
	            buttonSelected = findButton(x, y);
	            if (buttonSelected != BUTTON_NULL)
               {
                  // If so, set the guiClick flag
		            guiClick = 1;

                  switch (buttonSelected)
                  {
                     // Act accordingly for each button
                     // Should be mostly self explanitory
                  case BUTTON_ROUGH_UP:
                     clickTime = clock(); // Sets timer for auto-repeat
                     roughness += 0.001;
                     if (roughness >= 1.0)
                        roughness = 1;
                     break;
                  case BUTTON_ROUGH_DOWN:
                     clickTime = clock();
                     roughness -= 0.001;
                     if (roughness <= 0.0)
                        roughness = 0;
                     break;
                  case BUTTON_AMP_DOWN:
                     clickTime = clock();
                     randAmplitude -= 0.1;
                     if (randAmplitude <= 0.0)
                        randAmplitude = 0;
                     break;
                  case BUTTON_AMP_UP:
                     clickTime = clock();
                     randAmplitude += 0.1;
                     if (randAmplitude >= 100.0)
                        randAmplitude = 100;
                     break;
                  case BUTTON_WATER_UP:
                     clickTime = clock();
                     waterLine += 0.05;
                     break;
                  case BUTTON_WATER_DOWN:
                     clickTime = clock();
                     waterLine -= 0.05;
                     break;
                  case BUTTON_TIMESTEP_DOWN:
                     clickTime = clock();
                     timeStep -= 0.01;
                     break;
                  case BUTTON_TIMESTEP_UP:
                     clickTime = clock();
                     timeStep += 0.01;
                     break;
                  }
                  glutPostRedisplay();
                  
               }
               
               // If not button was hit, but the mouse click was still within the current GUI
               // window size, still set guiClick flag (so scene isnt rotated through GUI)
      	      if ((guiState == GUI_MAXIMIZED) || (guiState == GUI_MINIMIZED) && (y <= (guiY +15)))
		            guiClick = 1;
	
	
	         }
	         else
	         {
               // If click was outside of GUI area, reset guiClick flag
               // and set selected button to NULL.
	            guiClick= 0;
	            buttonSelected = BUTTON_NULL;

               // If we're in adjust mode, check if click is on a vertex
	            if(mode == ADJUST)
		         {  
		            selectedVector = pickVector(x, y); // See if point was picked
								       
		         }
	         }
         }
         else
         {
            // If left button just came up, update it's state
            leftButtonDown = 0;

            // If a button was selected, act accordingly
	         if (selectedVector != BUTTON_NULL)
	         {
	            switch(buttonSelected)
               {
	            case BUTTON_MINMAX: // Change GUI state
		            if(guiState == GUI_MINIMIZED)
		               guiState = GUI_MAXIMIZED;
		            else
	                  guiState = GUI_MINIMIZED;
	               glutPostRedisplay();
		            break;

	            case BUTTON_MODE: // Change mode, update button caption
		            if(mode == ADJUST) 
		            {
		               mode = DISPLAY; 
                     strcpy(buttons[BUTTON_MODE].text, "Display");
                     
                     // Regen terrain when done adjusting
		               srand( seed );
		               for (i = 0; i <= numVectors-1; i++)
		               {
			               for (j = 0; j <= numVectors-1; j++)
			               {
			                  heightMap[i][j] = 0;
			               }
		               }
		               generateMap(0, numVectors-1, 0, numVectors-1);

                     // Update GUI window height
                     if (ballsState == BALLS_ON)
                        guiHeight = 335;
                     else
                        guiHeight = 280;
		            }
		            else
                  {
		               mode = ADJUST;
                     // Adjust button caption
                     strcpy(buttons[BUTTON_MODE].text, "Adjust");
                     // Update window height
                     guiHeight = 50;
                  }
		            glutPostRedisplay();
	               break;
	            case BUTTON_GEN_NEW:
                  // Get new seed value, clear and regen the landscape
	               seed = (unsigned)time( NULL );
		            srand( seed );
		            for (i = 0; i <= numVectors-1; i++)
		            {
		               for (j = 0; j <= numVectors-1; j++)
		               {
			               heightMap[i][j] = 0;
		               }
		            }
 
		            generateMap(0, numVectors-1, 0, numVectors-1);

		            glutPostRedisplay();
		            break;
               case BUTTON_ROUGH_UP:
               case BUTTON_ROUGH_DOWN:
               case BUTTON_AMP_UP:
               case BUTTON_AMP_DOWN:
                  // clear and regen the landscape, using old seed
                  srand( seed );
		            for (i = 0; i <= numVectors-1; i++)
		            {
		               for (j = 0; j <= numVectors-1; j++)
		               {
			               heightMap[i][j] = 0;
		               }
		            }
 
		            generateMap(0, numVectors-1, 0, numVectors-1);

               case BUTTON_WATER_UP:
               case BUTTON_WATER_DOWN:
		            glutPostRedisplay();
		            break;
               case BUTTON_BALLS_ONOFF: // Update ball rain state
                  if (ballsState == BALLS_ON)
                  {
                     strcpy(buttons[BUTTON_BALLS_ONOFF].text,"Off");
                     ballsState = BALLS_OFF;
                     guiHeight = 280;
                  }
                  else
                  {
                     for (i = 0; i < MAX_BALLS; i++)
                        balls[i].radius = 0;
                     strcpy(buttons[BUTTON_BALLS_ONOFF].text,"On");
                     ballsState = BALLS_ON;
                     guiHeight = 335;
                  }
	            }

	         }
            // Reset selected vector and button 
            selectedVector = -1;
	         buttonSelected = BUTTON_NULL;
            glutPostRedisplay();

         }
         break;
      case GLUT_MIDDLE_BUTTON:
      case GLUT_RIGHT_BUTTON:
         if (state == GLUT_DOWN)
         {
            rightButtonDown = 1;
            mouseX = x;
            mouseY = y;
	         if ((x >= guiX) && ( x <= (guiX + guiWidth)) && (y>= guiY) && (y<=(guiY+guiHeight)))
	         {
               // If clicked in GUI window, set guiClick flag
               // so scene isnt zoomed through window
	            guiClick = 1;
	         }
	         else
	         {
	            guiClick= 0;
	            if(mode == ADJUST)
		         {
                  // If mode is Adjust...
		            selectedVector = pickVector(x, y); // See if point was picked
		            if (selectedVector != -1) // If so, disable
		            {
		               controlPoints[selectedVector%5][selectedVector/5] = 0;
		               glutPostRedisplay();
		            }
		         }
	         }
         }
         else
         {
            // If right button is up, update states
            rightButtonDown = 0;
            selectedVector = -1;
            glutPostRedisplay();
         }
         break;
      default:
         break;
   }
}

// Main keyboard function.
// All copies of GUI functions, used in development.
// Used mainly now for showing algorithm detail with i/I
void keyboard(unsigned char key, int x, int y)
{
   static int filled=1;
   int i, j;

   switch (key) {
      case 27:
         exit(0);
	      break; 

      case 'm': // Mode switch
	      mode = (mode +1);
	      if (mode == 3)
	         mode = 1;
         glutPostRedisplay();
	      break;

      /* "w" for switching between GL_FILL and GL_LINE */
      case 'w':
	      if (filled) 
         {
	         filled = 0;
	         glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
	      }
	      else 
         {
	         filled = 1;
	         glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
	      }; 
         glutPostRedisplay();
         break;

      case 'n': // Generate new landscape
         seed = (unsigned)time( NULL );
         srand( seed );
         for (i = 0; i <= numVectors-1; i++)
         {
            for (j = 0; j <= numVectors-1; j++)
            {
               heightMap[i][j] = 0;
            }
         }

         generateMap(0, numVectors-1, 0, numVectors-1);

         glutPostRedisplay();
         break;

      // Raise/lower water line
      case 'l':                
         waterLine += .05;
         glutPostRedisplay();
         break;
      case 'L':                 
         waterLine -= .05;
         glutPostRedisplay();
         break;

      // Increase/Decrease roughness
      case 'r':                
         roughness += 0.01;
	      
         if(roughness > 1)
            roughness = 1;
         break;
      case 'R':                 
         roughness -= .01;
	      
         if (roughness < 0)
            roughness = 0.;
         break;

      // Increase/decrease the number of algorithm iterations to go through
      // then regen landscape
      case 'i':
         iterationStop++;
                  srand( seed );
         for (i = 0; i <= numVectors-1; i++)
         {
            for (j = 0; j <= numVectors-1; j++)
            {
               heightMap[i][j] = 0;
            }
         }
         generateMap(0, numVectors-1, 0, numVectors-1);
         glutPostRedisplay();

         break;
      case 'I':
         iterationStop--;
                  srand( seed );
         for (i = 0; i <= numVectors-1; i++)
         {
            for (j = 0; j <= numVectors-1; j++)
            {
               heightMap[i][j] = 0;
            }
         }
         generateMap(0, numVectors-1, 0, numVectors-1);
         glutPostRedisplay();

         break;
      default:
         break;
   }
}
   
// Big ugly Idle function
// Used for collision detection and response, and
// GUI button auto repeat
void idle(void)
{
   int i, // Loop counter
       k, // Used to store max lateral distande between map points
       mapi, mapj,       // Used to mark balls path over landscape
       endMapi, endMapj, 
       polyNum, // Polygon number storage 
       mapIndex, // Index for mapList
       redrawFlag = 0; //Flag so theres no unneeded redraws

   GLfloat collisionTime, // Time of balls collision with curent plane
           fIndex;
   GLfloat reflection[3],    // Reflection vector
           tempBallPoint[3], // Temp ball position
           tempWorldPoint[3];// Temp world position (for map coord convertion)

   GLfloat d, // d value for plane equation
           ballY; // Y value of ball, used to determin if its under the plane

   int mapList[numVectors][2]; // List of heightMap locations, used so each position 
                               // ball travels over is checked

   // If a button is selected and enough time has passed...
   if ((buttonSelected != BUTTON_NULL) &&(((clock() - clickTime)/CLOCKS_PER_SEC) > WAIT_TIME))
   {
      // Increase/decrease correct value until button is released
      switch(buttonSelected)
      {
      case BUTTON_ROUGH_UP:
         roughness += 0.002;
         if (roughness >= 1.0)
            roughness = 1;
         drawOnlyGUI(guiX, guiY);
         break;
      case BUTTON_ROUGH_DOWN:
         roughness -= 0.002;
         if (roughness <= 0.0)
            roughness = 0;
         drawOnlyGUI(guiX, guiY);
         break;
      case BUTTON_AMP_UP:       
         randAmplitude += 0.2;
         if (randAmplitude >= 100.0)
            randAmplitude = 100;
         drawOnlyGUI(guiX, guiY);
         break;
      case BUTTON_AMP_DOWN:       
         randAmplitude -= 0.2;
         if (randAmplitude <=0.0)
            randAmplitude = 0;
         drawOnlyGUI(guiX, guiY);
         break;
      case BUTTON_WATER_UP:       
         waterLine += 0.2;
         glutPostRedisplay();
         break;
      case BUTTON_WATER_DOWN:       
         waterLine -= 0.2;
         glutPostRedisplay();
         break;
      case BUTTON_TIMESTEP_UP:
         timeStep += .01;
         break;
      case BUTTON_TIMESTEP_DOWN:
         timeStep -= .01;
         break;

      }
   }

   // Collision checking bit
   for (i = 0; i < MAX_BALLS; i++)
   {
      // For every "active" ball
      if(balls[i].radius > 0)
      {
         // Set the redraw flag
	      redrawFlag = 1;

         // If the ball is underwater, dampen velocity and make it float
         if (balls[i].pos[0] >=-10 && balls[i].pos[0] <=10 && balls[i].pos[2] >=-10 && balls[i].pos[2] <=10 && balls[i].pos[1] <= waterLine)
         {
            balls[i].velocity[0] *=0.8;
            balls[i].velocity[2] *=0.8;
            balls[i].velocity[1] *=0.8;
            balls[i].velocity[1] +=0.05*(waterLine - balls[i].pos[1]+.2)*timeStep;
            if (balls[i].velocity[1] > 0.07)
               balls[i].velocity[1] = .07*(waterLine - balls[i].pos[1]+.2);
         }
         else // Otherwise just add gravity
            balls[i].velocity[1] -= timeStep*gravity;

         // Set balls timeLeft to timeStep, that how long it has to move this frame
         balls[i].timeLeft = timeStep;
        
         
         
         do
         {
            // Set collisionTime to a bad value that will be ignored if no collision
            collisionTime =timeStep +1;
            // Reset polygon number
            polyNum = 0;

            // Copy balls postion to temp space
            copyVect3(balls[i].pos, tempBallPoint);
            // Move temp position to potential endpoint
            addScalarMult3(balls[i].velocity, timeStep, tempBallPoint);

            // Get balls heightMap coordinates
            mapi = (int)((numVectors-1)*(10 + balls[i].pos[0]))/20;
            mapj = (int)((numVectors-1)*(10 + balls[i].pos[2]))/20;

            // If ball is within heightMap
            if ((mapi >= 0) && (mapi < numVectors-1) && (mapj >= 0) && (mapj < numVectors-1))
            {
               // Set temp world point to the coresponding heightmap point
               setVector3(tempWorldPoint, ((20.0 * mapi)/(numVectors-1)) - 10, heightMap[mapi][mapj], ((20.0 * mapj)/(numVectors-1)) - 10);
               
               // See which polygon the ball is over/under
               polyNum = pointInPoly(balls[i].pos, mapi, mapj);

               // Compute polygon's d value
               d = dotProduct(tempWorldPoint, normals[(2*mapi)+polyNum-1][mapj]);
               
               // Big ugly formula to find where ball should be if directly on poly's surface
               ballY = (d - (normals[(2*mapi)+polyNum-1][mapj][0] * balls[i].pos[0]) - (normals[(2*mapi)+polyNum-1][mapj][2] * balls[i].pos[2]))/normals[(2*mapi)+polyNum-1][mapj][1];
               
               // If the ball is under this point, move it up
               if (balls[i].pos[1] < ballY)
                  balls[i].pos[1] = ballY;
            }
                  
            // convert balls endpoint to map coords
            endMapi = (int)((numVectors-1)*(10 + tempBallPoint[0]))/20;
            endMapj = (int)((numVectors-1)*(10 + tempBallPoint[2]))/20;

            // Set mapIndex so filling of list starts at 1
            mapIndex = 1;
            // Set maplist[0] to beginning point
            mapList[0][0] = mapi;
            mapList[0][1] = mapj;

            // If balls stays within current square,
            // set next list item to sentinel value
            if (mapi == endMapi && mapj == endMapj)
            {
               mapList[1][0] = -1;
            }
            else
            {
               // fill mapList with locations the ball passes over

               // Set k to maximum lateral distance between endpoints
               if (abs(mapi-endMapi) >= abs(mapj-endMapj))
                  k = abs(mapi-endMapi);
               else
                  k = abs(mapj-endMapj);

               // Move ball down its path, in steps of 1/k
               for (fIndex = 0; fIndex <= 1; fIndex += 1.0/(float)k)
               {
                  // Copy ball position to temp space
                  copyVect3(balls[i].pos, tempBallPoint);
                  // Move temp postion along path, using index as time
                  addScalarMult3(balls[i].velocity, fIndex * timeStep, tempBallPoint);

                  // Convert new ball position to map coords
                  endMapi = (int)((numVectors-1)*(10 + tempBallPoint[0]))/20;
                  endMapj = (int)((numVectors-1)*(10 + tempBallPoint[2]))/20;

                  // If we havent already stored this map location, store it
                  // and advance mapIndex
                  if (mapList[mapIndex-1][0] != endMapi || mapList[mapIndex-1][1] != endMapj)
                  {
                     mapList[mapIndex][0] = endMapi;
                     mapList[mapIndex][1] = endMapj;
                     mapIndex++;
                  }
               }
               // Set sentinel
               mapList[mapIndex][0] = -1;
            }

            // Check each map location for a collision, exit for loop is one is found
            for(mapIndex = 0; (mapList[mapIndex][0] >= 0) && ((collisionTime <= 0) || (collisionTime > balls[i].timeLeft)) ; mapIndex++)
            {
               // Make sure map location is within heightMap bounds
               if ((mapList[mapIndex][0] >= 0) && (mapList[mapIndex][0] < numVectors-1) && (mapList[mapIndex][1] >= 0) && (mapList[mapIndex][1] < numVectors-1))
               {
                  // Set temp world point to worl point of map location
                  setVector3(tempWorldPoint, ((20.0 * mapList[mapIndex][0])/(numVectors-1)) - 10, heightMap[mapList[mapIndex][0]][mapList[mapIndex][1]], ((20.0 * mapList[mapIndex][1])/(numVectors-1)) - 10);
            
                  // See which poly the ball is over
                  polyNum = pointInPoly(balls[i].pos, mapList[mapIndex][0], mapList[mapIndex][1]);
                  
                  // Get the collision time
                  collisionTime = getCollisionTime(tempWorldPoint, normals[(mapList[mapIndex][0]*2)+ polyNum-1][mapList[mapIndex][1]], balls[i].pos, balls[i].velocity, 0);//balls[i].radius);
              
               }
            }
            
            // If a collision was found in the correct time space
            if (collisionTime > 0 && collisionTime <= balls[i].timeLeft)
            {
               // Move the ball to collision point
               addScalarMult3(balls[i].velocity, collisionTime, balls[i].pos);
               // Update the time the ball has left to move
               balls[i].timeLeft -= collisionTime;
               // Reflect the balls velocity vector
               reflect(balls[i].velocity, normals[(mapList[mapIndex-1][0]*2)+ polyNum-1][mapList[mapIndex-1][1]], reflection);
               // Dampen the new velocity
               scalarMult3(reflection, 0.75, balls[i].velocity);
            }
         } // Keep doing the previous while there are no more collisions to worry about
         while (collisionTime > 0 && collisionTime <= balls[i].timeLeft);

         // Move the ball its final amount
         addScalarMult3(balls[i].velocity, balls[i].timeLeft, balls[i].pos);
         
         // If ball falls down to far, 'kill' it
	      if (balls[i].pos[1] < -30)
            balls[i].radius = 0;

         // If the velocity of the ball is consistently small, 'kill' it
         if ((pow(balls[i].velocity[0],2) +pow(balls[i].velocity[1],2) +pow(balls[i].velocity[2],2)) < 0.0001)
            balls[i].deadTimer++;
         if(balls[i].deadTimer > 20)
            balls[i].radius = 0;

      }
      
   }

   // Redraw if needed
   if (redrawFlag == 1)
       glutPostRedisplay();
}

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(windowXSize, windowYSize); 
   glutInitWindowPosition(100, 100);
   glutCreateWindow(argv[0]);
   init();
   glutDisplayFunc(display); 
   glutReshapeFunc(reshape); 
   glutMouseFunc(mouse);
   glutKeyboardFunc(keyboard);
   glutMotionFunc(motion);
   glutIdleFunc(idle);
   glutMainLoop();
   return 0;
}

