/********************************
 *
 *   SnkyAmp.cpp
 *
 *   SneakyAmp v1.0
 *   Written by Joe Bott
 *   email: jbott@wi.rr.com
 *   Copyright 2000
 *
 ********************************/



#include <afx.h>
#include <windowsx.h>

#include <process.h>
#include <time.h>
#include <vector>

#include "gen.h"
#include "resource.h"
#include "khk.h"

BOOL WINAPI _DllMainCRTStartup(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}

#define ENABLE_PREV 1
#define ENABLE_PLAY 2
#define ENABLE_STOP 4
#define ENABLE_NEXT 8
#define ENABLE_EJECT 16

#define BEGIN_COM "winamp"
#define END_COM "\"\""
#define MP3_PATH "d:\\mp3s"
#define MAX_FILES 10;
#define IPC_PLAYFILE 100

// Little struct for string options
struct stropt {
	CString Description;
	CString Edit;
	CString Default;
	int ID;
} StringOptions[19];

// Struct for int options
struct intopt {
	CString Description;
	int Edit;
	int Default;
	int ID;
} IntOptions[8];

// Prototypes
BOOL CALLBACK ConfigProc(HWND hwndDlg,UINT uMsg,WPARAM wParam,LPARAM lParam);
void config();
void quit();
int init();
void config_write();
void config_read();
void FileSearch(const CString);
void SetDirectoryStructure(const CString);

const int MAX_NAME_SIZE = MAX_PATH;
typedef std::vector<CString *> FILEVECTOR;

// Globals

// Vector for filenames
FILEVECTOR filenames;
// Vector for directories
FILEVECTOR directories;
// Application name, thats easy. Why is it a global? I dunno.
char szAppName[] = "Sneaky Amp";
// Input string
CString input = "";
// Search key string
CString searchkey = "";
// Array of strings that hold each 'directory' type keyword
CString dirkeylist[24];
// Array of all the other keywords
CString keylist[24];

int first_start = 1, // First time running
    hhook = NULL;    // Key hook something or other. Its been a while, sorry.


// Plugin variable, what gets sent to Winamp initially
// Stores the 3 function pointers
winampGeneralPurposePlugin plugin =
{
	GPPHDR_VER,
	"",
	init,
	config,
	quit,
};



// Creates configuration dialog box. Woo.
void config()
{
	DialogBox(plugin.hDllInstance,MAKEINTRESOURCE(IDD_DIALOG1),plugin.hwndParent,ConfigProc);
}

// Function executed on Winamp exit
void quit()
{
   // Delete file vectors, restoring allocated memory
	while(!directories.empty())
	{
		CString *t = directories.front();
		directories.erase(directories.begin());
		delete t;
	}
	
	while(!filenames.empty())
	{
		CString *t = filenames.front();
		filenames.erase(filenames.begin());
		delete t;
	}

   // Unset Keyboard hook. 
	if (hhook != 0)
		UnSetKeyboardHook();

   // Save options
	config_write();

   // Heck if I know.
	IntOptions[0].Edit =0;
}

// Window callback, sucks messages from Winamp
WNDPROC lpWndProcOld;
LRESULT CALLBACK WndProc(HWND hwndWinamp, UINT message, WPARAM wParam, LPARAM lParam)
{
	int etest = 0,
		btest = 0;
	CString bgn_com, end_com;
	int keyindex = 0,dirkeyindex = 0;

	if (message == WM_COMMAND)
	{
		if(LOWORD(wParam) == WM_USER + 999)
		{

			input += (CHAR) lParam;
			
			if (IntOptions[4].Edit == 1)
				end_com = (CHAR) 13;
			else
				end_com = StringOptions[1].Edit;

			if (IntOptions[2].Edit == 1)
				bgn_com = (CHAR) 13;
			else
				bgn_com = StringOptions[0].Edit;

			etest = input.Find(end_com);

	      btest = input.Find(bgn_com);
	      if (etest != -1)
	      {
		      if ((btest != -1) && (btest != etest))
		      {
			      input = input.Left(input.GetLength() - end_com.GetLength());

			      while (btest != -1)
			      {
				      //input = input.substr(0, input.length() - strlen(END_COM));
				      input = input.Right(input.GetLength() - bgn_com.GetLength() - btest);
				      btest = input.Find(bgn_com);
			      }
				   int find = input.Find(' ');

			      keyindex = 0;
			      dirkeyindex = 0;
			      keylist[0] = "";
			      dirkeylist[0] = "";
			      while (input.GetLength() > 0)
			      {
				      int find = input.Find(' ');

				      if (find != -1)
				      {
					      if (find == 0)
						      input = input.Right(input.GetLength() -1);
					      else
					      {
						      if (input.Find(StringOptions[18].Edit) == 0)
						      {
							      dirkeylist[dirkeyindex] = input.Left(find);
							      input = input.Right(input.GetLength() - find - 1);
							      dirkeylist[dirkeyindex] = dirkeylist[dirkeyindex].Right(dirkeylist[dirkeyindex].GetLength() - StringOptions[18].Edit.GetLength());
							      if (dirkeylist[dirkeyindex].GetLength() > 0)
								      dirkeyindex++;
							      if (dirkeyindex >= 23)
								      dirkeyindex = 23;
							      dirkeylist[dirkeyindex] = "";
						
						      }
						      else
						      {
							      keylist[keyindex]=input.Left(find);
							      input = input.Right(input.GetLength() - find - 1);
							      if (keylist[keyindex].GetLength() > 0)
								      keyindex++;
							      if (keyindex >= 23)
								      keyindex = 23;
							      keylist[keyindex] = "";
						      }
					      }
				      }
				      else
				      {
					      if (input.Find(StringOptions[18].Edit) == 0)
					      {
						      if (dirkeyindex <= 22)
						      {
							      dirkeylist[dirkeyindex] = input;
							      dirkeylist[dirkeyindex] = dirkeylist[dirkeyindex].Right(dirkeylist[dirkeyindex].GetLength() - StringOptions[18].Edit.GetLength());
							      dirkeylist[dirkeyindex + 1] = "";
						      }
						      else
						      {
							      dirkeylist[23] = "";
						      }
					      }
					      else
					      {
						      if (keyindex <= 22)
						      {
							      keylist[keyindex] = input;
							      keylist[keyindex + 1] = "";
						      }
						      else
						      {
							      keylist[23] = "";
						      }
					      }
					      input.Empty();
				      }
			      }

		         keylist[0].MakeLower();
		         if (keylist[0] == "")
		         {
			         input.Empty();
			         return (0);
		         }
		         if (StringOptions[2].Edit.Find(keylist[0]) != -1)
		         {
			         if (keylist[1] == "")
				         PostMessage(plugin.hwndParent,WM_COMMAND,40045, 0);
			         else
			         {
				         int random = 0;
				         searchkey = "*";
				         keyindex = 1;
				         while ((keylist[keyindex].GetLength() > 0) && (keyindex < 24))
				         {	
					         if (StringOptions[16].Edit.Find(keylist[keyindex]) != -1)
					         {
						         random = atoi(keylist[keyindex + 1]);
						         if (random == 0)
						         {
							         searchkey += keylist[keyindex];
							         searchkey +="*";
							         keyindex++;
						         }
						         else
						         {
							         keyindex += 2;
						         }
					         }
					         else
					         {
						         searchkey += keylist[keyindex];
						         searchkey +="*";
						         keyindex++;
					         }
				         }
				         if (IntOptions[5].Edit == 1)
					         searchkey += ".mp3";
		
				         FileSearch(searchkey);

				         int i = 0;
				         if (random == 0)
				         {
					         while((i<filenames.size()) && (i < IntOptions[7].Edit))//(i < max_files))
					         {
						         if (i == 0)
						         {
							         PostMessage(hwndWinamp,WM_COMMAND,40047, 0);
							         SendMessage(hwndWinamp,WM_USER, 0, 101); 
							         COPYDATASTRUCT cds;
							         cds.dwData = IPC_PLAYFILE;
							         cds.lpData = (void *) filenames.at(i)->GetBuffer(MAX_PATH);
							         filenames.at(i)->ReleaseBuffer();
							         cds.cbData = strlen((char *) cds.lpData)+1; // include space for null		

							         SendMessage(hwndWinamp,WM_COPYDATA,(WPARAM)NULL,(LPARAM)&cds);	
							         PostMessage(plugin.hwndParent,WM_COMMAND,40045, 0);
							
						         }
						         else
						         {
							         COPYDATASTRUCT cds;
							         cds.dwData = IPC_PLAYFILE;
						            cds.lpData = (void *) filenames.at(i)->GetBuffer(MAX_PATH);
							         filenames.at(i)->ReleaseBuffer();
							         cds.cbData = strlen((char *) cds.lpData)+1; // include space for null

							         SendMessage(hwndWinamp,WM_COPYDATA,(WPARAM)NULL,(LPARAM)&cds);
							
						         }
						         i++;
					         }
				         }
				         else
				         {
					         srand( (unsigned)time( NULL ) );
					         CString *t;
					         int x = 0;
					         while ((random > 0) && !(filenames.empty()) && (i < IntOptions[7].Edit))
					         {
						         if (i == 0)
						         {
							         x = rand()%(filenames.size());// + 1);
							         PostMessage(hwndWinamp,WM_COMMAND,40047, 0);
							         SendMessage(hwndWinamp,WM_USER, 0, 101); 
							         COPYDATASTRUCT cds;
							         cds.dwData = IPC_PLAYFILE;
							         cds.lpData = (void *) filenames.at(x)->GetBuffer(MAX_PATH);
							         filenames.at(x)->ReleaseBuffer();
							         cds.cbData = strlen((char *) cds.lpData)+1; // include space for null		

							         SendMessage(hwndWinamp,WM_COPYDATA,(WPARAM)NULL,(LPARAM)&cds);	
							         PostMessage(plugin.hwndParent,WM_COMMAND,40045, 0);

							         t = filenames.at(x);
							         filenames.erase(filenames.begin() + x);
							         delete t;

							         random--;
							         i++;
						         }
						         else
						         {
							         x = rand()%(filenames.size());// + 1);
							         COPYDATASTRUCT cds;
							         cds.dwData = IPC_PLAYFILE;
							         cds.lpData = (void *) filenames.at(x)->GetBuffer(MAX_PATH);
							         filenames.at(x)->ReleaseBuffer();
							         cds.cbData = strlen((char *) cds.lpData)+1; // include space for null
							         SendMessage(hwndWinamp,WM_COPYDATA,(WPARAM)NULL,(LPARAM)&cds);

							         t = filenames.at(x);
							         filenames.erase(filenames.begin() + x);
							         delete t;

							         random--;
							         i++;
						         }
					         }

				         }

			         }
		         }
		         else if (StringOptions[4].Edit.Find(keylist[0]) != -1)
			         PostMessage(hwndWinamp,WM_COMMAND,40047, 0);
		         else if (StringOptions[8].Edit.Find(keylist[0]) != -1)
			         PostMessage(hwndWinamp,WM_COMMAND,40048, 0);
		         else if (StringOptions[7].Edit.Find(keylist[0]) != -1)
			         PostMessage(hwndWinamp,WM_COMMAND,40044, 0);
		         else if (StringOptions[5].Edit.Find(keylist[0]) != -1)
		         	PostMessage(hwndWinamp,WM_COMMAND,40046, 0);
		         else if (StringOptions[9].Edit.Find(keylist[0]) != -1)
		         {
		         	if (keylist[1] != "")
		         	{
		         		int data = atoi(keylist[1]);
		         		if ((data >= 0) && (data <=255))
		         		SendMessage(plugin.hwndParent,WM_USER, data, 122);
		         	}
		         } 
		         else if (StringOptions[10].Edit.Find(keylist[0]) != -1)
		         {
			         if (keylist[1] != "")
			         {
			         	int data = atoi(keylist[1]);
		         		if ((data >= -128) && (data <=128))
		         		SendMessage(plugin.hwndParent,WM_USER, data, 123);
		         	}
		         }
	         	else if (StringOptions[6].Edit.Find(keylist[0]) != -1)
		         {
		         	int data = SendMessage(plugin.hwndParent,WM_USER,0,105);
			         if (data != -1)
			         {
		         		if (keylist[1] != "")
			         	{
			         		data = data + (atoi(keylist[1]) * 1000);
				         	SendMessage(plugin.hwndParent,WM_USER,data,106);
				         }
				         else
				         {
				         	data = data + (IntOptions[6].Edit * 1000);
				         	SendMessage(plugin.hwndParent,WM_USER,data,106);
				         }
			         }
		         }
		         else if (StringOptions[11].Edit.Find(keylist[0]) != -1)
		         {
			         int data = SendMessage(plugin.hwndParent,WM_USER,0,105);
			         if (data != -1)
			         {
				         if (keylist[1] != "")
				         {
					         data = data - (atoi(keylist[1]) * 1000);
					         SendMessage(plugin.hwndParent,WM_USER,data,106);
				         }
				         else
				         {
					         data = data - (IntOptions[6].Edit * 1000);
					         SendMessage(plugin.hwndParent,WM_USER,data,106);
				         }
			         }
		         }
		         else if (StringOptions[12].Edit.Find(keylist[0]) != -1)
		         {
			         int data = SendMessage(plugin.hwndParent,WM_USER,0,250);
			         if (keylist[1] == "")
			         {
				         PostMessage(hwndWinamp,WM_COMMAND,40023, 0);
			         }
			         else if (StringOptions[14].Edit.Find(keylist[1]) != -1) 
			         {
			         	if (data == 0)
			         		PostMessage(hwndWinamp,WM_COMMAND,40023, 0);
			         }
			         else if (StringOptions[15].Edit.Find(keylist[1]) != -1) 
			         {
			         	if (data == 1)
			         		PostMessage(hwndWinamp,WM_COMMAND,40023, 0);
			         }
		         }
		         else if (StringOptions[13].Edit.Find(keylist[0]) != -1)
		         {
			         int data = SendMessage(plugin.hwndParent,WM_USER,0,251);
			         if (keylist[1] == "")
			         {
			         	PostMessage(hwndWinamp,WM_COMMAND,40022, 0);
			         }
			         else if (StringOptions[14].Edit.Find(keylist[1]) != -1) 
			         {
			         	if (data == 0)
			         		PostMessage(hwndWinamp,WM_COMMAND,40022, 0);
			         }
			         else if (StringOptions[15].Edit.Find(keylist[1]) != -1) 
			         {
			         	if (data == 1)
			         		PostMessage(hwndWinamp,WM_COMMAND,40022, 0);
			         }
		         }
		         else if (StringOptions[3].Edit.Find(keylist[0]) != -1)
		         {
		         	if (keylist[1] != "")
		         	{
		         		int random = 0;
		         		searchkey = "*";
		         		keyindex = 1;
		         		while (keylist[keyindex].GetLength() > 0)
			         	{	
			         		if (StringOptions[16].Edit.Find(keylist[keyindex]) != -1)
			         		{
			         			random = atoi(keylist[keyindex + 1]);
				         		if (random == 0)
				         		{
							         searchkey += keylist[keyindex];
				          			searchkey +="*";
							         keyindex++;
						         }
						         else
						         {
						         	keyindex += 2;
						         }
					         }
					         else
					         {
						         searchkey += keylist[keyindex];
						         searchkey +="*";
						         keyindex++;
					         }
				         }
				         searchkey += ".mp3";
				         FileSearch(searchkey);		
         
				         int i = 0;
				         if (random == 0)
				         {
				         	while((i<filenames.size()) && (i < IntOptions[7].Edit))
					         {
					         	COPYDATASTRUCT cds;
						         cds.dwData = IPC_PLAYFILE;
						         cds.lpData = (void *) filenames.at(i)->GetBuffer(MAX_PATH);
						         filenames.at(i)->ReleaseBuffer();
						         cds.cbData = strlen((char *) cds.lpData)+1; // include space for null
						         SendMessage(hwndWinamp,WM_COPYDATA,(WPARAM)NULL,(LPARAM)&cds);
						
						         i++;
					         }
				         }         
				         else
				         {
					         srand( (unsigned)time( NULL ) );
					         CString *t;
					         int x;
					         while ((random > 0) && !(filenames.empty()) && (i < IntOptions[7].Edit))
					         {
						         x = rand()%(filenames.size());// + 1);
						         COPYDATASTRUCT cds;
						         cds.dwData = IPC_PLAYFILE;
						         cds.lpData = (void *) filenames.at(x)->GetBuffer(MAX_PATH);
						         filenames.at(x)->ReleaseBuffer();
						         cds.cbData = strlen((char *) cds.lpData)+1; // include space for null
						         SendMessage(hwndWinamp,WM_COPYDATA,(WPARAM)NULL,(LPARAM)&cds);

						         t = filenames.at(x);
						         filenames.erase(filenames.begin() + x);
						         delete t;

						         random--;
						         i++;
					         }
				         }

			         }
		         }


		      }
		      else
		      {
			      input.Empty();
		      }
	      }

			return (0);
		}
	}
	return CallWindowProc(lpWndProcOld,hwndWinamp,message,wParam,lParam);
}

int init()
{
	StringOptions[0].Default = BEGIN_COM;
	StringOptions[0].Description = "Begin Command";
	StringOptions[0].ID = IDC_BCEDIT;
	StringOptions[1].Default = END_COM;
	StringOptions[1].Description = "End Command";
	StringOptions[1].ID = IDC_ECEDIT;
	StringOptions[2].Default = "play";
	StringOptions[2].Description = "Play Command";
	StringOptions[2].ID = IDC_PLAYEDIT;
	StringOptions[3].Default = "add";
	StringOptions[3].Description = "Add Command";
	StringOptions[3].ID = IDC_ADDEDIT;
	StringOptions[4].Default = "stop";
	StringOptions[4].Description = "Stop Command";
	StringOptions[4].ID = IDC_STOPEDIT;
	StringOptions[5].Default = "pause";
	StringOptions[5].Description = "Pause Command";
	StringOptions[5].ID = IDC_PAUSEEDIT;
	StringOptions[6].Default = "forward";
	StringOptions[6].Description = "Forward Command";
	StringOptions[6].ID = IDC_FORWARDEDIT;
	StringOptions[7].Default = "prev";
	StringOptions[7].Description = "Previous Command";
	StringOptions[7].ID = IDC_PREVIOUSEDIT;
	StringOptions[8].Default = "next";
	StringOptions[8].Description = "Next Command";
	StringOptions[8].ID = IDC_NEXTEDIT;
	StringOptions[9].Default = "volume";
	StringOptions[9].Description = "Volume Command";
	StringOptions[9].ID = IDC_VOLUMEEDIT;
	StringOptions[10].Default = "balance";
	StringOptions[10].Description = "Balance Command";
	StringOptions[10].ID = IDC_BALANCEEDIT;
	StringOptions[11].Default = "rewind";
	StringOptions[11].Description = "Rewind Command";
	StringOptions[11].ID = IDC_REWINDEDIT;
	StringOptions[12].Default = "shuffle";
	StringOptions[12].Description = "Shuffle Command";
	StringOptions[12].ID = IDC_SHUFFLEEDIT;
	StringOptions[13].Default = "repeat";
	StringOptions[13].Description = "Repeat Command";
	StringOptions[13].ID = IDC_REPEATEDIT;
	StringOptions[14].Default = "on";
	StringOptions[14].Description = "On Command";
	StringOptions[14].ID = IDC_ONEDIT;
	StringOptions[15].Default = "off";
	StringOptions[15].Description = "Off Command";
	StringOptions[15].ID = IDC_OFFEDIT;
	StringOptions[16].Default = "random";
	StringOptions[16].Description = "Random Command";
	StringOptions[16].ID = IDC_RANDOMEDIT;
	StringOptions[17].Default = "c:\\";// = MP3_PATH;
	StringOptions[17].Description = "MP3 Path";
	StringOptions[17].ID = IDC_MP3LOCEDIT;
	StringOptions[18].Default = "-";
	StringOptions[18].Description = "Dir Prefix";
	StringOptions[18].ID = IDC_DIRPREFIXEDIT;
	
	IntOptions[0].Default = 0;
	IntOptions[0].Description = "Enabled";
	IntOptions[0].ID = IDC_ENABLECHECK;
	IntOptions[1].Default = 1;
	IntOptions[1].Description = "BCEdit";
	IntOptions[1].ID = IDC_BCEDITRADIO;
	IntOptions[2].Default = 0;
	IntOptions[2].Description = "BCEnter";
	IntOptions[2].ID = IDC_BCENTERRADIO;
	IntOptions[3].Default = 1;
	IntOptions[3].Description = "ECEdit";
	IntOptions[3].ID = IDC_ECEDITRADIO;
	IntOptions[4].Default = 0;
	IntOptions[4].Description = "ECEnter";
	IntOptions[4].ID = IDC_ECENTERRADIO;
	IntOptions[5].Default = 1;
	IntOptions[5].Description = "Assume MP3";
	IntOptions[5].ID = IDC_MP3CHECK;
	IntOptions[6].Default = 10;
	IntOptions[6].Description = "Default Offset";
	IntOptions[6].ID = IDC_DEFAULTFORREWEDIT;
	IntOptions[7].Default = 50;
	IntOptions[7].Description = "Max Files";
	IntOptions[7].ID = IDC_MAXFILEEDIT;

	{
		static char c[512];
		char filename[512],*p;
		GetModuleFileName(plugin.hDllInstance,filename,sizeof(filename));
		p = filename+lstrlen(filename);
		while (p >= filename && *p != '\\') p--;
		wsprintf((plugin.description=c),"%s Plug-In v1.0 (%s)",szAppName,p+1);
	}

	config_read();


	lpWndProcOld = (WNDPROC) SetWindowLong(plugin.hwndParent, GWL_WNDPROC,(LONG) WndProc);
	
	SetHWnd(plugin.hwndParent);
	if (IntOptions[0].Edit == 1)
		hhook =  SetKeyboardHook();
	
	if (StringOptions[17].Edit != "") SetDirectoryStructure(StringOptions[17].Edit);

	return 0;
}

BOOL CALLBACK AboutProc(HWND hwndDlg,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	if ((uMsg == WM_COMMAND) && (LOWORD(wParam) == IDOK))
		EndDialog(hwndDlg,0);
	return false;
}



BOOL CALLBACK ConfigProc(HWND hwndDlg,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	switch (uMsg)
	{
		case WM_INITDIALOG:
			{
				char string[32];
				for (int i = 0; i < 6; i++)
				{
					CheckDlgButton(hwndDlg,IntOptions[i].ID,(IntOptions[i].Edit?BST_CHECKED:BST_UNCHECKED));
				}

				for (i = 0; i < 19; i++)
				{
					SetDlgItemText(hwndDlg,StringOptions[i].ID, StringOptions[i].Edit);
				}

				for (i = 6; i < 9; i++)
				{
					wsprintf(string,"%d",IntOptions[i].Edit);
					SetDlgItemText(hwndDlg,IntOptions[i].ID, string);
				}

			}
		return FALSE;
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDC_ABOUT:
					{
						DialogBox(plugin.hDllInstance,MAKEINTRESOURCE(IDD_ABOUT),plugin.hwndParent,AboutProc);
						return false;
					}

				case IDC_APPLY:
				case IDOK:
					{
						CString temppath1, temppath2;
						char string[30];
						GetCurrentDirectory(MAX_PATH, temppath1.GetBufferSetLength(MAX_PATH));
						temppath1.ReleaseBuffer();
						GetDlgItemText(hwndDlg,IDC_MP3LOCEDIT,temppath2.GetBufferSetLength(MAX_PATH), MAX_PATH);
						temppath2.ReleaseBuffer();
						if (SetCurrentDirectory(temppath2))
						{
							StringOptions[17].Edit = temppath2;
							SetDirectoryStructure(StringOptions[17].Edit);
							if (IsDlgButtonChecked(hwndDlg,IDC_ENABLECHECK))
							{
								if (IntOptions[0].Edit == 0)
								{
									SetHWnd(plugin.hwndParent);
									hhook =  SetKeyboardHook();
								}
								
								IntOptions[0].Edit = 1;
							}
							else
							{
								if (IntOptions[0].Edit ==1)
								{
									UnSetKeyboardHook();
								}
								IntOptions[0].Edit = 0;
							}
							GetDlgItemText(hwndDlg,IDC_ECEDIT,StringOptions[1].Edit.GetBufferSetLength(MAX_PATH), MAX_PATH);
							StringOptions[1].Edit.ReleaseBuffer();
							if (IsDlgButtonChecked(hwndDlg, IDC_ECENTERRADIO))
							{
				
								IntOptions[3].Edit = 0;
								IntOptions[4].Edit = 1;
							}
							else
							{
								IntOptions[3].Edit = 1;
								IntOptions[4].Edit = 0;
							}
							
							GetDlgItemText(hwndDlg,IDC_BCEDIT,StringOptions[0].Edit.GetBufferSetLength(MAX_PATH), MAX_PATH);
							StringOptions[0].Edit.ReleaseBuffer();
							if (IsDlgButtonChecked(hwndDlg, IDC_BCENTERRADIO))
							{
								//bgn_com = (CHAR) 13;
								IntOptions[1].Edit = 0;
								IntOptions[2].Edit = 1;
							}
							else
							{
								IntOptions[1].Edit = 1;
								IntOptions[2].Edit = 0;
							}

							if (((IntOptions[4].Edit & IntOptions[2].Edit) == 1) ||
							   (((IntOptions[1].Edit & IntOptions[3].Edit) == 1) && (StringOptions[0].Edit == StringOptions[1].Edit)))
							{
								MessageBox(hwndDlg, "Begin and End command can not be the same", "Error", MB_OK | MB_ICONEXCLAMATION | MB_DEFBUTTON1);
								return FALSE;
							}


							if (IsDlgButtonChecked(hwndDlg, IDC_MP3CHECK))
								IntOptions[5].Edit = 1;
							else
								IntOptions[5].Edit = 0;

							GetDlgItemText(hwndDlg,IDC_MAXFILEEDIT,string, 30);
							IntOptions[7].Edit = atoi(string);
							GetDlgItemText(hwndDlg,IDC_DEFAULTFORREWEDIT,string, 30);
							IntOptions[6].Edit = atoi(string);
							
							for (int i = 2; i < 17; i++)
							{
								GetDlgItemText(hwndDlg,StringOptions[i].ID,(StringOptions[i].Edit).GetBufferSetLength(MAX_PATH), MAX_PATH);
								(StringOptions[i].Edit).ReleaseBuffer();
							}
							
							GetDlgItemText(hwndDlg,IDC_DIRPREFIXEDIT,(StringOptions[18].Edit).GetBufferSetLength(MAX_PATH), MAX_PATH);
							(StringOptions[18].Edit).ReleaseBuffer();


						}
						else
						{
							MessageBox(hwndDlg, "Invalid MP3 Path", "Error", MB_OK | MB_ICONEXCLAMATION | MB_DEFBUTTON1);
							return FALSE;
						}
						SetCurrentDirectory(temppath1);
					}
				case IDCANCEL:
					if (LOWORD(wParam) != IDC_APPLY) EndDialog(hwndDlg,0);
				return FALSE;
			}
	}
	return FALSE;
}

void config_read()
{
	char ini_file[MAX_PATH], *p;
	GetModuleFileName(plugin.hDllInstance,ini_file,sizeof(ini_file));
	p=ini_file+lstrlen(ini_file);
	while (p >= ini_file && *p != '\\') p--;
	if (++p >= ini_file) *p = 0;
	lstrcat(ini_file,"plugin.ini");

	first_start = GetPrivateProfileInt(szAppName,"First Start",1,ini_file);
	if (first_start == 1)
	{
		IntOptions[0].Edit = 0;
		first_start = 0;
		for (int i = 0; i < 19; i++)
		{
			StringOptions[i].Edit = StringOptions[i].Default;
		}
		for (i = 0; i < 8; i++)
		{
			IntOptions[i].Edit = IntOptions[i].Default;
		}
	}
	else
	{
		for (int i = 0;i < 8; i++)
		{
			IntOptions[i].Edit = GetPrivateProfileInt(szAppName,IntOptions[i].Description,IntOptions[i].Default,ini_file);
		}

	   if ((IntOptions[1].Edit + IntOptions[2].Edit) == 0)
	   {
		   IntOptions[1].Edit = 1;
		   IntOptions[2].Edit = 0;
	   }
	   if ((IntOptions[3].Edit + IntOptions[4].Edit) == 0)
	   {
		   IntOptions[3].Edit = 1;
		   IntOptions[4].Edit = 0;
	   }

	   for (i = 0; i < 19; i++)
	   {
		   GetPrivateProfileString(szAppName, StringOptions[i].Description, StringOptions[i].Default, (StringOptions[i].Edit).GetBufferSetLength(MAX_PATH) , MAX_PATH, ini_file);
		   (StringOptions[i].Edit).ReleaseBuffer();
	   }

	}
}

void config_write()
{
	char ini_file[MAX_PATH], *p;
	char string[32];
	CString test1,test2;
	GetModuleFileName(plugin.hDllInstance,ini_file,sizeof(ini_file));
	p=ini_file+lstrlen(ini_file);
	while (p >= ini_file && *p != '\\') p--;
	if (++p >= ini_file) *p = 0;
	lstrcat(ini_file,"plugin.ini");
	
	for (int i = 0; i < 19; i++)
	{
		test1 = (StringOptions[i].Edit).Left(1);
		test2 = (StringOptions[i].Edit).Right(1);
		if (((StringOptions[i].Edit).GetLength() > 1) && (test1 == test2) && ((test1 =="'") || (test1 == "\"")))
		{
			StringOptions[i].Edit = test1 + StringOptions[i].Edit + test1;
		}
		WritePrivateProfileString(szAppName, StringOptions[i].Description, (StringOptions[i].Edit).GetBufferSetLength(MAX_PATH), ini_file);
		(StringOptions[i].Edit).ReleaseBuffer();
	}

	for (i = 0; i < 8; i++)
	{
		wsprintf(string,"%d",IntOptions[i].Edit);
		WritePrivateProfileString(szAppName,IntOptions[i].Description,string,ini_file);
	}
	wsprintf(string,"%d",first_start);
	WritePrivateProfileString(szAppName,"First Start",string,ini_file);

}

void FileSearch(const CString searchkey)
{

	HANDLE hFind;
	CString u, *t;
	bool usedir = true;
	int find1 = 0, find2 = 0, dirkeyindex = 0;
	WIN32_FIND_DATA FindFileData;
	int a = 0,
		size = directories.size();
	
	while(!filenames.empty())
	{
		t = filenames.front();
		filenames.erase(filenames.begin());
		delete t;
	}

	while(a < size)
	{

		u = *directories.at(a);
		usedir = true;
		find1 = 0;
		find2 = 0;
		dirkeyindex = 0;
		while (dirkeylist[dirkeyindex] != "")
		{
		
			dirkeylist[dirkeyindex].MakeLower();
			if ((u.Find(dirkeylist[dirkeyindex]) == -1) || (dirkeyindex > 23))
			{
				usedir = false;
			}
			dirkeyindex++;
		}
		
		if (usedir == true)
		{
			if(SetCurrentDirectory( u ) != 0)
			{
				hFind = FindFirstFile( searchkey, &FindFileData );
				if (hFind != INVALID_HANDLE_VALUE)
				{
					if ((FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != FILE_ATTRIBUTE_DIRECTORY)
					{
						CString *x = new CString;
					
						*x = u;
						if (x->Right(1) != "\\")
						{
							*x += "\\";
						}
						
							
						*x += FindFileData.cFileName;
	
						filenames.push_back(x);
					}				
					while (FindNextFile( hFind, &FindFileData ) != 0)
					{	
						if ((FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != FILE_ATTRIBUTE_DIRECTORY)
						{	

							CString *x = new CString;
							
							*x = u;
							if (x->Right(1) != "\\")
									*x+="\\";
			
							*x += FindFileData.cFileName;
		
							filenames.push_back(x);
						}
					}
				}
			}
		}
		a++;

	}
}

void SetDirectoryStructure(const CString path) {
	
	std::vector<CString *> tempvect;
	HANDLE hFind;
	WIN32_FIND_DATA FindFileData;
	int a = 0;

	CString *t = new CString;
	CString u;
	
	*t = path;
	tempvect.push_back(t);
	while(!directories.empty())
	{
		
		CString *t = directories.front();
		directories.erase(directories.begin());
		delete t;
	}

	while(a < tempvect.size())
	{

		u = *tempvect.at(a);
		if (SetCurrentDirectory( u ) != 0)
		{

			hFind = FindFirstFile( "*", &FindFileData );
			if (hFind != INVALID_HANDLE_VALUE)
			{
				

			
				if ((FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
				{
					if ((strcmp(FindFileData.cFileName, ".") != 0) && (strcmp(FindFileData.cFileName, "..") != 0))
					{
						
						CString *x = new CString;
						
						*x = u;
						if (x->Right(1) != "\\")
						{
							
							*x += "\\";
						}
				
						*x+= FindFileData.cFileName;
						
						x->MakeLower();
						tempvect.push_back(x);
					}
				}
				
				while(FindNextFile( hFind, &FindFileData ) !=0)
				{		
					if ((FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
					{
						if ((strcmp(FindFileData.cFileName, ".") != 0) && (strcmp(FindFileData.cFileName, "..") != 0))
						{
							
							CString *x = new CString;
							
							*x = u;
							if (x->Right(1) != "\\")
							{
								
								*x += "\\";
							}
					
							*x += FindFileData.cFileName;
						
							
							x->MakeLower();
							tempvect.push_back(x);
						}
					}
				}
			}
		}
		a++;
	}
	
	while(!directories.empty())
	{
		t = directories.front();
		directories.erase(directories.begin());
		delete t;
	}

	while(!tempvect.empty())
	{
		
		CString *x = new CString;
		t = tempvect.front();
		
		*x = *t;
		tempvect.erase(tempvect.begin());
		delete t;
		directories.push_back(x);

	}

}


extern "C" __declspec( dllexport ) winampGeneralPurposePlugin * winampGetGeneralPurposePlugin()
{
	return &plugin;
}


