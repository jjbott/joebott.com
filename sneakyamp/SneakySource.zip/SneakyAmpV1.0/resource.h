//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDC_APPLY                       3
#define IDD_DIALOG1                     101
#define IDD_ABOUT                       120
#define IDB_BITMAP1                     122
#define IDC_BCEDITRADIO                 1007
#define IDC_BCENTERRADIO                1008
#define IDC_BCEDIT                      1009
#define IDC_ECEDITRADIO                 1010
#define IDC_ECENTERRADIO                1011
#define IDC_ECEDIT                      1012
#define IDC_MP3CHECK                    1013
#define IDC_MP3LOCEDIT                  1014
#define IDC_PLAYEDIT                    1015
#define IDC_FORWARDEDIT                 1017
#define IDC_ADDEDIT                     1018
#define IDC_STOPEDIT                    1019
#define IDC_PAUSEEDIT                   1022
#define IDC_PREVIOUSEDIT                1024
#define IDC_NEXTEDIT                    1025
#define IDC_VOLUMEEDIT                  1026
#define IDC_BALANCEEDIT                 1027
#define IDC_REWINDEDIT                  1028
#define IDC_MAXFILEEDIT                 1029
#define IDC_DEFAULTFORREWEDIT           1030
#define IDC_ABOUT                       1031
#define IDC_ENABLECHECK                 1032
#define IDC_DIRPREFIXEDIT               1033
#define IDC_SHUFFLEEDIT                 1034
#define IDC_REPEATEDIT                  1035
#define IDC_ONEDIT                      1036
#define IDC_OFFEDIT                     1037
#define IDC_RANDOMEDIT                  1038

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        123
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1037
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
