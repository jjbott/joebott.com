/****************************************
 *
 * khk.cpp
 * SneakyAmp's keyboard hook DLL
 *
 * Written by Joe Bott - Copyright 2000
 *
 ****************************************/


#include "stdafx.h"
#include "khk.h"
#include <string>

#pragma comment(linker, "/SECTION:.SHARED,RWS")
#pragma data_seg(".SHARED")
   static HHOOK g_hKeyboardHook=NULL;
   static HWND hwnd = NULL;
   static HANDLE HookDll=NULL;
   static bool shiftstate;
#pragma data_seg()


WPARAM x = WM_USER + 999;


BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	HookDll = hInst;
	return TRUE;
}

_declspec(dllexport) LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam)
{

	if (nCode < 0)
		return CallNextHookEx( g_hKeyboardHook, nCode, wParam, lParam);
	if (nCode == HC_ACTION)
	{

		if (wParam == VK_SHIFT)
		{
			
			if(lParam&KEY_UP)
			{
				shiftstate = false;
			} 
			else
			{
				shiftstate = true;
			}
		}


		if (!(lParam&KEY_UP))
		{

			if (((TCHAR) wParam >= 48) && ((TCHAR) wParam <= 57) && (shiftstate == false))
			{
				PostMessage(hwnd, WM_COMMAND,x, (INT)(TCHAR) wParam);//input += (TCHAR) wParam;
			}
			else if (((TCHAR) wParam >= 65) && ((TCHAR) wParam <= 90))
			{
				if (shiftstate == true)
				{
					PostMessage(hwnd, WM_COMMAND,x, (INT)(TCHAR) wParam);
					//input += (TCHAR) wParam;
				}
				else
				{
					PostMessage(hwnd, WM_COMMAND,x, (INT)tolower((TCHAR) wParam)); 
					//input += "c";//(int)tolower((TCHAR) wParam);
					//input += "";
				}
			}
			else
			{

				switch (wParam)
				{
				case VK_COMMA:
					if (shiftstate==true)
					{
						PostMessage(hwnd, WM_COMMAND,x, (INT)60);
						//input += "<";
					}
					else
					{
						PostMessage(hwnd, WM_COMMAND,x, (INT)44);
						//input += ",";
					}
					break;
				case VK_PERIOD:
					if (shiftstate==true)
						PostMessage(hwnd, WM_COMMAND,x, (INT)62);//input += ">";
					else
						PostMessage(hwnd, WM_COMMAND,x, (INT)46);//input += ".";
					break;
				case VK_QUESTION:
					if (shiftstate==true)
						PostMessage(hwnd, WM_COMMAND,x, (INT)63);//input += "?";
					else
						PostMessage(hwnd, WM_COMMAND,x, (INT)47);//input += "/";
					break;
				case VK_SEMICOLON:
					if (shiftstate==true)
						PostMessage(hwnd, WM_COMMAND,x, (INT)58);//input += ":";
					else
						PostMessage(hwnd, WM_COMMAND,x, (INT)59);//input += ";";
					break;
				case VK_QUOTE:
					if (shiftstate==true)
						PostMessage(hwnd, WM_COMMAND,x, (INT)34);//input += "\"";
					else
						PostMessage(hwnd, WM_COMMAND,x, (INT)39);//input += "'";
					break;
				case VK_LEFTBRACKET:
					if (shiftstate==true)
						PostMessage(hwnd, WM_COMMAND,x, (INT)123);//input += "{";
					else
						PostMessage(hwnd, WM_COMMAND,x, (INT)91);//input += "[";
					break;
				case VK_RIGHTBRACKET:
					if (shiftstate==true)
						PostMessage(hwnd, WM_COMMAND,x, (INT)125);//input += "}";
					else
						PostMessage(hwnd, WM_COMMAND,x, (INT)93);//input += "]";
					break;
				case VK_SLASH:
					if (shiftstate==true)
						PostMessage(hwnd, WM_COMMAND,x, (INT)124);//input += "|";
					else
						PostMessage(hwnd, WM_COMMAND,x, (INT)92);//input += "\\";
					break;
				case VK_EQUALS:
					if (shiftstate==true)
						PostMessage(hwnd, WM_COMMAND,x, (INT)43);//input += "+";
					else
						PostMessage(hwnd, WM_COMMAND,x, (INT)61);//input += "=";
					break;
				case VK_MINUS:
					if (shiftstate==true)
						PostMessage(hwnd, WM_COMMAND,x, (INT)95);//input += "_";
					else
						PostMessage(hwnd, WM_COMMAND,x, (INT)45);//input += "-";
					break;
				case VK_TILDE:
					if (shiftstate==true)
						PostMessage(hwnd, WM_COMMAND,x, (INT)126);//input += "~";
					else
						PostMessage(hwnd, WM_COMMAND,x, (INT)96);//input += "`";
					break;
				case VK_0:
					PostMessage(hwnd, WM_COMMAND,x, (INT)41);//input += ")";
					break;
				case VK_1:
					PostMessage(hwnd, WM_COMMAND,x, (INT)33);//input += "!";
					break;
				case VK_2:
					PostMessage(hwnd, WM_COMMAND,x, (INT)64);//input += "@";
					break;
				case VK_3:
					PostMessage(hwnd, WM_COMMAND,x, (INT)35);//input += "#";
					break;
				case VK_4:
					PostMessage(hwnd, WM_COMMAND,x, (INT)36);//input += "$";
					break;
				case VK_5:
					PostMessage(hwnd, WM_COMMAND,x, (INT)37);//input += "%";
					break;
				case VK_6:
					PostMessage(hwnd, WM_COMMAND,x, (INT)94);//input += "^";
					break;
				case VK_7:
					PostMessage(hwnd, WM_COMMAND,x, (INT)38);//input += "&";
					break;
				case VK_8:
					PostMessage(hwnd, WM_COMMAND,x, (INT)42);//input += "*";
					break;
				case VK_9:
					PostMessage(hwnd, WM_COMMAND,x, (INT)40);//input += "(";
					break;
				case VK_SPACE:
					PostMessage(hwnd, WM_COMMAND,x, (INT)32);//input += " ";
					break;
				case VK_ENTER:
					PostMessage(hwnd, WM_COMMAND,x, (INT)13);//input += " ";
					break;
				default:
					break;
				}
			}
			
		}


		return CallNextHookEx( g_hKeyboardHook, nCode, wParam, lParam);
	}
	
	return CallNextHookEx( g_hKeyboardHook, nCode, wParam, lParam);


}




_declspec(dllexport) int SetKeyboardHook()
{   
	g_hKeyboardHook = SetWindowsHookEx(WH_KEYBOARD, (HOOKPROC)KeyboardProc, (HINSTANCE)HookDll, NULL);   
	if(!g_hKeyboardHook)   
	{      
		MessageBox(NULL, "hook failed", "oops", NULL);   
	}   
	return 0;
}  

_declspec(dllexport) int UnSetKeyboardHook()
{   
	if(g_hKeyboardHook)   
	{      
		UnhookWindowsHookEx(g_hKeyboardHook);   
	}   
	return 0;
}


_declspec(dllexport) bool SetHWnd(HWND x)
{
	hwnd = x;
	return true;
}